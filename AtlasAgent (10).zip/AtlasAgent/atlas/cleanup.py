"""Geçici betik temizliği — iş %100 bittiyse sil, bitmediyse koru, asla biriktirme.

Takip edilenler (yalnızca ATLAS'ın bu turda OLUŞTURDUĞU dosyalar):
 - write_file(temporary=true) ile yazılan tek seferlik yardımcı betikler
 - adı geçici olduğunu söyleyen yeni betikler (tmp_*.py, temp_*.ps1, deneme_*.bat, *_tmp.py …)
 - <proje>/.atlas/tmp/ altına yazılan her şey
 - IDA'da çalıştırılan geçici betiklerin geçmiş kopyaları (.atlas/ida/scripts/_gecmis)
Tur sonunda iş tamamen bittiyse bunlar ve önceki yarım işlerden kalanlar silinir. Bitmediyse (hata, durdurma,
adım sınırı, derlenmemiş kod, açık plan adımı, kullanıcıya soru) korunur ve bekleyenler listesine yazılır; sonraki
başarılı turda ya da en geç `cleanup_max_days` gün sonra silinir. Silmeden önce içerik özeti karşılaştırılır:
kullanıcı dosyayı sonradan değiştirdiyse dokunulmaz. Kalıcı (save_as ile kaydedilen) IDA betiklerine dokunulmaz.
"""
import hashlib
import json
import re
import time
from pathlib import Path

from .config import CFG, DATA

SCRIPT_EXT = {".py", ".pyw", ".ps1", ".psm1", ".bat", ".cmd", ".sh", ".js", ".vbs", ".idc", ".lua", ".ahk", ".rb", ".pl"}
TEMP_NAME_RE = re.compile(r"^(tmp|temp|scratch|deneme|gecici|geçici|_atlas)[_\-.]|[_\-](tmp|temp|scratch)\.[^.]+$", re.I)


def _sha(p: Path) -> str:
    try:
        return hashlib.sha1(p.read_bytes()).hexdigest()
    except OSError:
        return ""


def _settings():
    a = CFG["agent"]
    return bool(a.get("auto_cleanup", True)), max(1, int(a.get("cleanup_max_days", 3) or 3)), \
        max(1, int(a.get("backups_keep", 5) or 5))


def _base(root) -> Path:
    return (Path(root) / ".atlas") if root else DATA


def _manifest_path(root) -> Path:
    return _base(root) / "tmp_manifest.json"


def _load(root):
    p = _manifest_path(root)
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
    except Exception:
        return []


def _store(root, items):
    p = _manifest_path(root)
    try:
        if items:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(items, indent=1, ensure_ascii=False), encoding="utf-8")
        elif p.exists():
            p.unlink()
    except OSError:
        pass


def is_temp_script(p: Path, root=None) -> bool:
    """Ad/konum kuralına göre geçici betik mi? (temporary=true verilmese bile)"""
    if root:
        try:
            if Path(p).resolve().is_relative_to((Path(root) / ".atlas" / "tmp").resolve()):
                return True
        except (OSError, ValueError):
            pass
    return Path(p).suffix.lower() in SCRIPT_EXT and bool(TEMP_NAME_RE.search(Path(p).name))


class TempTracker:
    """Bir turda oluşturulan geçici dosyalar."""

    def __init__(self, root=None, conv=None):
        self.root = Path(root).resolve() if root else None
        self.conv = conv
        self.items = {}   # yol → {"path", "sha", "kind", "at", "conv"}

    def add(self, path, kind="betik"):
        p = Path(path).resolve()
        if not self._safe(p):
            return False
        self.items[str(p)] = {"path": str(p), "sha": _sha(p), "kind": kind, "at": time.time(), "conv": self.conv}
        return True

    def refresh(self, path):
        """Takip edilen dosya bu turda yeniden yazıldı/düzenlendi → özeti güncelle."""
        k = str(Path(path).resolve())
        if k in self.items:
            self.items[k]["sha"] = _sha(Path(k))

    def tracked(self, path) -> bool:
        return str(Path(path).resolve()) in self.items

    def _safe(self, p: Path) -> bool:
        """Yalnızca proje klasörü ya da ATLAS veri klasörü içindeki dosyalar silinebilir."""
        for base in (self.root, DATA.resolve()):
            if base:
                try:
                    if p.is_relative_to(base) and p != base:
                        return True
                except ValueError:
                    pass
        return False


def _delete(items, safe_fn):
    removed, kept_changed = [], []
    for it in items:
        p = Path(it["path"])
        if not p.exists():
            continue
        if not safe_fn(p):
            continue
        if it.get("sha") and _sha(p) != it["sha"]:
            kept_changed.append(p.name)   # kullanıcı/başka işlem değiştirmiş → dokunma
            continue
        try:
            p.unlink()
            removed.append(p.name)
        except OSError:
            continue
        _prune_empty(p.parent)
    return removed, kept_changed


def _prune_empty(d: Path):
    """Temizlikten sonra boş kalan geçici klasörleri kaldır (.atlas/tmp, _gecmis…)."""
    for _ in range(3):
        try:
            if d.name in ("tmp", "_gecmis") or d.parent.name == "tmp":
                if d.is_dir() and not any(d.iterdir()):
                    d.rmdir()
                    d = d.parent
                    continue
        except OSError:
            pass
        break


def pending_for(root, conv):
    return [it for it in _load(root) if it.get("conv") == conv]


def finish(tracker: TempTracker, success: bool):
    """Tur sonu. success=True → bu turun ve bekleyen eski geçici dosyaları sil. False → beklemeye al.
    Dönen: {"removed": [...], "kept": [...], "changed": [...]}"""
    on, _, _ = _settings()
    root = tracker.root
    pending = _load(root)
    cur = list(tracker.items.values())
    if not on:
        return {"removed": [], "kept": [], "changed": []}
    if success:
        # yalnızca BU sohbetin bekleyenleri: başka sohbetteki yarım iş "devam et" ile sürdürülebilir
        mine = [it for it in pending if it.get("conv") == tracker.conv]
        removed, changed = _delete(cur + mine, tracker._safe)
        _store(root, [it for it in pending if it not in mine and Path(it["path"]).exists()])
        return {"removed": removed, "kept": [], "changed": changed}
    known = {it["path"] for it in pending}
    pending += [it for it in cur if it["path"] not in known]
    pending = [it for it in pending if Path(it["path"]).exists()]
    _store(root, pending)
    return {"removed": [], "kept": [Path(it["path"]).name for it in cur if Path(it["path"]).exists()], "changed": []}


def expire(root=None):
    """Tur başında: bekleme süresi dolan geçici dosyaları sil (iş hiç bitmese bile birikmesin)."""
    on, days, _ = _settings()
    if not on:
        return []
    pending = _load(root)
    if not pending:
        return []
    limit = time.time() - days * 86400
    old = [it for it in pending if it.get("at", 0) < limit]
    if not old:
        return []
    tr = TempTracker(root)
    removed, _ = _delete(old, tr._safe)
    _store(root, [it for it in pending if it not in old and Path(it["path"]).exists()])
    return removed


def prune_backups(root=None):
    """.atlas/backups: her dosya için son N yedek kalır, 14 günden eskiler silinir (geri alma veritabanından yapılır)."""
    _, _, keep = _settings()
    d = _base(root) / "backups"
    if not d.is_dir():
        return 0
    groups = {}
    for f in d.glob("*.bak"):
        m = re.match(r"^(.*)\.\d{8}-\d{6}\.bak$", f.name)
        groups.setdefault(m.group(1) if m else f.name, []).append(f)
    limit, n = time.time() - 14 * 86400, 0
    for files in groups.values():
        files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        for i, f in enumerate(files):
            if i >= keep or f.stat().st_mtime < limit:
                try:
                    f.unlink()
                    n += 1
                except OSError:
                    pass
    return n


def task_complete(*, hit_max, final_forced, tools_muted, dirty_cpp, auto_verify, plan, trace, answer, stopped=False):
    """İş %100 bitti mi? Bitmediyse nedenini döndürür ("" = bitti)."""
    if stopped:
        return "durduruldu"
    if hit_max or final_forced:
        return "adım sınırı"
    if tools_muted:
        return "araç hataları"
    if dirty_cpp and auto_verify:
        return "değişen kod derlenip doğrulanmadı"
    if plan and any(it.get("status") != "done" for it in plan):
        return "planda bitmemiş adım var"
    for t in reversed(trace or []):   # son çalıştırma/derleme başarılı olmalı
        if t.get("name") in ("run_command", "run_python", "compile_cpp", "ida"):
            r = str(t.get("result", ""))
            if t["name"] == "compile_cpp":
                failed = "✔ Derleme başarılı" not in r
            else:
                failed = r.startswith("HATA") or bool(re.match(r"\[çıkış kodu: (?!0\b)-?\d+", r))
            if failed:
                return "son çalıştırma hata verdi"
            break
    a = (answer or "").strip()
    if "nihai cevabı üretemedi" in a[:120]:
        return "model cevap üretemedi"
    if a.endswith("?") or a == "(boş cevap)":
        return "kullanıcıdan cevap bekleniyor" if a.endswith("?") else "boş cevap"
    return ""
