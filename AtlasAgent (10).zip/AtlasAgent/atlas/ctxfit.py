"""Bağlamı (num_ctx) VRAM'e göre otomatik ayarlama.

Yöntem: Ollama'nın KENDİ bellek yerleşim kararı ölçülür. Model aday bağlamla yüklenir, /api/ps'teki size/size_vram
ile tamamen GPU'da olup olmadığına bakılır; ikili arama ile tamamen sığan en büyük bağlam bulunur. Metadata'dan
tahmin yerine ölçüm kullanıldığı için Qwen3.6/Qwen3.8 hibrit (DeltaNet + attention) yapıları, KV önbellek tipi, flash
attention ve görsel kodlayıcı gibi etkenler kendiliğinden hesaba katılır.

Politika:
 - Tamamen sığan bağlam >= auto_ctx_min ise → o değer (bir adım güvenlik payıyla) kullanılır: %100 GPU, en hızlı.
 - Daha azına bile sığmıyorsa (ör. 30B coder, 8 GB kart) → model ayarındaki num_ctx olduğu gibi kalır.
Sonuçlar data/ctxfit.json'a yazılır; model / KV tipi / flash attention / num_gpu / num_batch değişirse yeniden ölçülür.
"""
import asyncio
import json
import logging
import os
import shutil
import subprocess
import time

from .config import CFG, DATA, shares_main

log = logging.getLogger("atlas.ctxfit")
PATH = DATA / "ctxfit.json"
STEP = 2048
ROLES = ("main", "vision", "coder", "reviewer")
NO_WINDOW = 0x08000000 if os.name == "nt" else 0


def settings():
    p = CFG["performance"]
    return {"auto": bool(p.get("auto_ctx", True)),
            "min": max(2048, int(p.get("auto_ctx_min", 12288) or 12288)),
            "max": max(4096, int(p.get("auto_ctx_max", 32768) or 32768)),
            "margin": max(0, int(p.get("auto_ctx_margin", 1) or 0))}


def signature(role):
    """Bellek yerleşimini etkileyen ayarlar — değişirse eski ölçüm geçersiz."""
    m, p, o = CFG["models"][role], CFG["performance"], CFG.get("ollama_server", {}) or {}
    s = settings()
    return "|".join(str(x) for x in (m.get("name"), m.get("num_gpu"), p.get("num_batch"), o.get("kv_cache_type"),
                                      o.get("flash_attention"), o.get("gpu_overhead_mb"), o.get("num_parallel"),
                                      s["min"], s["max"], s["margin"]))


def gpu_info():
    """NVIDIA kartın toplam/kullanılan belleği (MB). nvidia-smi yoksa None. Pencere açmadan çalışır."""
    exe = shutil.which("nvidia-smi")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "--query-gpu=name,memory.used,memory.total", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=4, creationflags=NO_WINDOW)
        n, used, total = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")]
        return {"name": n, "mem_used": int(used), "mem_total": int(total)}
    except Exception:
        return None


def _same(a, b):
    a, b = (a or "").strip(), (b or "").strip()
    return a == b or a == b + ":latest" or b == a + ":latest"


class CtxFit:
    def __init__(self, ollama, options_fn, gpu_fn=gpu_info, path=PATH):
        self.ollama, self.options_fn, self.gpu_fn, self.path = ollama, options_fn, gpu_fn, path
        self.lock = asyncio.Lock()
        self.state = {"running": False, "role": None, "msg": ""}
        try:
            self.data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        except Exception:
            self.data = {}

    # ------------------------------------------------------------------ okuma
    def result(self, role):
        r = self.data.get(role)
        return r if r and r.get("sig") == signature(role) else None

    def effective(self, role) -> int:
        """Ajanın kullanacağı num_ctx: geçerli ölçüm varsa ve model sığıyorsa ölçülen değer, yoksa ayardaki değer."""
        if shares_main(role):   # görsel = ana model → ana modelin ölçümü geçerli
            role = "main"
        base = int(CFG["models"][role].get("num_ctx", 8192) or 8192)
        if role not in ROLES or not settings()["auto"]:
            return base
        r = self.result(role)
        return int(r["ctx"]) if r and r.get("fits") and r.get("ctx") else base

    def needs(self, role) -> bool:
        return settings()["auto"] and role in ROLES and not shares_main(role) and self.result(role) is None

    def summary(self):
        out = {"settings": settings(), "running": self.state["running"], "role": self.state["role"],
               "msg": self.state["msg"], "roles": {}}
        for role in ROLES:
            raw = self.data.get(role) or {}
            out["roles"][role] = {"model": CFG["models"][role]["name"], "base": int(CFG["models"][role].get("num_ctx") or 0),
                                  "effective": self.effective(role), "measured": bool(raw),
                                  "stale": bool(raw) and raw.get("sig") != signature(role),
                                  **{k: raw.get(k) for k in ("fits", "ctx", "max_fit", "gpu_pct", "reason", "at",
                                                             "seconds", "vram_total_mb")}}
        return out

    def _save(self):
        try:
            self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            log.warning("ctxfit kaydedilemedi: %s", e)

    # ------------------------------------------------------------------ ölçüm
    async def _probe(self, name, ctx, opts):
        """Modeli `ctx` bağlamıyla yükle → (size, size_vram). Ollama farklı num_ctx görünce modeli yeniden yükler."""
        await self.ollama.load(name, dict(opts, num_ctx=int(ctx), num_predict=1), "5m")
        for _ in range(15):
            for p in await self.ollama.ps():
                if _same(p.get("name"), name) or _same(p.get("model"), name):
                    return int(p.get("size") or 0), int(p.get("size_vram") or 0)
            await asyncio.sleep(0.3)
        raise RuntimeError("model yüklendi ama /api/ps listesinde görünmüyor")

    async def _max_ctx(self, name):
        try:
            info = await self.ollama.show(name)
            for k, v in (info.get("model_info") or {}).items():
                if k.endswith(".context_length") and isinstance(v, int) and v > 0:
                    return v
        except Exception:
            pass
        return 0

    async def calibrate(self, role, progress=None):
        """Tek rol için ölç ve kaydet. Model kurulu değilse None döner (kaydedilmez, sonra yeniden denenir)."""
        say = progress or (lambda *_: None)
        m, s = CFG["models"][role], settings()
        name = m["name"]
        t0 = time.time()
        tag = next((t for t in await self.ollama.tags() if _same(t.get("name"), name)), None)
        if not tag:
            say(role, f"{name} kurulu değil — atlandı.")
            return None
        gpu = await asyncio.to_thread(self.gpu_fn) if self.gpu_fn else None
        rec = {"sig": signature(role), "model": name, "at": time.time(), "probes": [],
               "vram_total_mb": gpu and gpu.get("mem_total")}
        lo, hi = s["min"], s["max"]
        mx = await self._max_ctx(name)
        if mx:
            hi = max(STEP, min(hi, mx))
            lo = min(lo, hi)
        size_b = int(tag.get("size") or 0)
        if gpu and size_b > gpu["mem_total"] * 1024 * 1024 * 0.97:
            rec.update(fits=False, ctx=None, max_fit=None, gpu_pct=round(gpu["mem_total"] * 1024 * 1024 / size_b * 100),
                       reason="model dosyası VRAM'den büyük", seconds=round(time.time() - t0, 1))
            say(role, f"{name}: model VRAM'den büyük, tam sığamaz — bağlam ayardaki gibi ({m.get('num_ctx')}) kalır.")
            self.data[role] = rec
            self._save()
            return rec
        opts = {k: v for k, v in self.options_fn(role).items() if k not in ("num_predict", "num_ctx")}
        # başka modeller GPU'daysa ölçümü bozar → boşalt (8 GB'ta zaten aynı anda tek LLM sığar)
        for p in await self.ollama.ps():
            if not _same(p.get("name"), name) and (p.get("size_vram") or 0) > 0:
                await self.ollama.unload(p["name"])
        pct_at = {}

        async def fits(ctx):
            say(role, f"{name}: {ctx} bağlam deneniyor…")
            size, vram = await self._probe(name, ctx, opts)
            pct = round(vram / size * 100) if size else 0
            pct_at[ctx] = pct
            rec["probes"].append([ctx, pct])
            return size > 0 and vram >= size * 0.995

        best = None
        if await fits(hi):
            best = hi
        elif await fits(lo):
            a, b = lo, hi   # a sığar, b sığmaz
            while b - a > STEP:
                mid = (a + b) // 2 // STEP * STEP
                if mid <= a:
                    break
                if await fits(mid):
                    a = mid
                else:
                    b = mid
            best = a
        if best is None:
            rec.update(fits=False, ctx=None, max_fit=None, gpu_pct=pct_at.get(lo), reason=f"{lo} bağlamda bile tam sığmıyor")
            say(role, f"{name}: {lo} bağlamda bile %{pct_at.get(lo)} GPU — bağlam ayardaki gibi ({m.get('num_ctx')}) kalır.")
        else:
            ctx = best if best >= hi else max(lo, best - s["margin"] * STEP)   # tavana ulaşmadıysa güvenlik payı
            rec.update(fits=True, ctx=ctx, max_fit=best, gpu_pct=100, reason="")
            say(role, f"{name}: %100 GPU ile en fazla {best} → {ctx} bağlam kullanılacak.")
        # bitiş: modeli kullanılacak bağlamla bırak (ilk mesajda yeniden yükleme olmasın)
        final = rec.get("ctx") or int(m.get("num_ctx") or 8192)
        try:
            await self.ollama.load(name, dict(opts, num_ctx=final, num_predict=1), CFG["performance"]["keep_alive"])
        except Exception:
            pass
        rec["seconds"] = round(time.time() - t0, 1)
        self.data[role] = rec
        self._save()
        return rec

    async def calibrate_all(self, roles=None, progress=None, warm="main"):
        """Sırayla ölç; ısıtılacak (genelde ana) model en sona bırakılır ki ölçümden sonra VRAM'de o kalsın."""
        roles = [r for r in (roles or ROLES) if r in ROLES and not shares_main(r)]
        roles.sort(key=lambda r: r == warm)
        out = {}
        async with self.lock:
            self.state.update(running=True)
            try:
                for role in roles:
                    self.state.update(role=role, msg=f"{CFG['models'][role]['name']} ölçülüyor…")

                    def say(r, msg):
                        self.state["msg"] = msg
                        log.info("ctxfit[%s] %s", r, msg)
                        if progress:
                            progress(r, msg)
                    try:
                        out[role] = await self.calibrate(role, say)
                    except Exception as e:
                        log.warning("ctxfit[%s] başarısız: %s", role, e)
                        say(role, f"ölçüm başarısız: {e}")
                        out[role] = {"error": str(e)}
            finally:
                self.state.update(running=False, role=None, msg="")
        return out
