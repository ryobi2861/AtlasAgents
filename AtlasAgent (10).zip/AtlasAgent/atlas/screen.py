"""Ekran yakalama: tam ekran (mss) ve Windows bölge seçimi (Ekran Alıntısı → pano)."""
import hashlib
import os
import subprocess
import sys
import time
import uuid

from .config import IMAGES

IS_WIN = sys.platform == "win32"


def _save_png(img) -> str:
    name = f"{uuid.uuid4().hex}.png"
    img.save(IMAGES / name, "PNG", optimize=False)
    return name


def capture_full(monitor: int = 0) -> str:
    """monitor=0: imlecin bulunduğu / birincil ekran. Dönüş: data/images içindeki dosya adı."""
    import mss
    from PIL import Image
    with mss.mss() as sct:
        mons = sct.monitors  # [0]=tüm ekranlar, [1..]=tek tek
        idx = monitor if 0 < monitor < len(mons) else 1
        if monitor == 0 and IS_WIN:
            try:  # imlecin olduğu ekranı bul
                import ctypes

                class P(ctypes.Structure):
                    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
                pt = P()
                ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                for i, m in enumerate(mons[1:], 1):
                    if m["left"] <= pt.x < m["left"] + m["width"] and m["top"] <= pt.y < m["top"] + m["height"]:
                        idx = i
                        break
            except Exception:
                pass
        shot = sct.grab(mons[idx])
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    # Görsel model için makul boyut (4K ekranlarda gereksiz token/VRAM harcamasın)
    if img.width > 2560:
        r = 2560 / img.width
        img = img.resize((2560, int(img.height * r)))
    return _save_png(img)


def _clip_hash():
    from PIL import ImageGrab
    try:
        im = ImageGrab.grabclipboard()
    except Exception:
        return None, None
    if im is None or not hasattr(im, "tobytes"):
        return None, None
    return hashlib.md5(im.tobytes()[:2_000_000]).hexdigest(), im


def capture_region(timeout: float = 45.0):
    """Windows Ekran Alıntısı aracını açar, kullanıcının seçtiği bölgeyi panodan alır."""
    if not IS_WIN:
        return capture_full()
    before, _ = _clip_hash()
    try:
        os.startfile("ms-screenclip:")
    except Exception:
        subprocess.Popen("explorer ms-screenclip:", shell=True, creationflags=0x08000000 if sys.platform == "win32" else 0)
    t0 = time.time()
    time.sleep(0.8)
    while time.time() - t0 < timeout:
        h, im = _clip_hash()
        if h and h != before:
            return _save_png(im.convert("RGB"))
        time.sleep(0.3)
    return None


def clipboard_image():
    h, im = _clip_hash()
    return _save_png(im.convert("RGB")) if im is not None else None
