"""Kod sürümü parmak izi ve güncelleme sonrası yeniden başlatma yardımcıları.

Sorun: pencereyi kapatmak ATLAS'ı tepsiye gizler; güncelleme zip'i açılıp BASLAT.bat çalıştırılınca tek-örnek kilidi
yüzünden ESKİ süreç öne gelir ve diskteki yeni kod hiç yüklenmez. Çözüm:
 - Her süreç açılışta kendi kod parmak izini (RUNNING) data/running_build.txt'ye yazar.
 - İkinci örnek açılınca diskteki kod çalışandan farklıysa eski örneğe "kapan" bayrağı bırakır, kapanmazsa
   (bayrağı tanımayan eski sürüm) yalnızca bu klasördeki ATLAS sürecini sonlandırır ve yeni kodla açılır.
 - Çalışan uygulama diskteki kodun değiştiğini fark ederse arayüzde "yeniden başlat" uyarısı gösterir.
"""
import hashlib
import os
import sys
import time
from pathlib import Path

from .config import BASE, DATA, FROZEN

RUNNING_FILE = DATA / "running_build.txt"
RESTART_FLAG = DATA / "restart.flag"


def _files():
    if FROZEN:
        return [Path(sys.executable)]
    out = [BASE / "desktop.py", BASE / "launcher.py", BASE / "static" / "index.html"]
    out += sorted((BASE / "atlas").glob("*.py"))
    return out


def fingerprint() -> str:
    """Kod dosyalarının boyut + değişiklik zamanı özeti (hızlı; içerik okumaz)."""
    h = hashlib.sha1()
    for p in _files():
        try:
            st = p.stat()
            h.update(f"{p.name}|{st.st_size}|{int(st.st_mtime)}\n".encode())
        except OSError:
            h.update(f"{p.name}|-\n".encode())
    return h.hexdigest()[:12]


RUNNING = fingerprint()   # bu sürecin yüklediği kod


def update_available() -> bool:
    return fingerprint() != RUNNING


def write_running():
    try:
        RUNNING_FILE.write_text(f"{RUNNING}\n{os.getpid()}\n", encoding="utf-8")
    except OSError:
        pass


def read_running():
    """(parmak izi, pid) — dosya yoksa (None, None): bayrağı tanımayan eski sürüm çalışıyor demektir."""
    try:
        lines = RUNNING_FILE.read_text(encoding="utf-8").split()
        return lines[0], int(lines[1]) if len(lines) > 1 else None
    except (OSError, ValueError, IndexError):
        return None, None


def _same_path(a, b) -> bool:
    try:
        return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))
    except Exception:
        return False


def _is_atlas_script(arg, proc) -> bool:
    """Argüman bir ATLAS kurulumunun desktop.py/launcher.py dosyası mı (yanında atlas/agent.py olan)?"""
    name = os.path.basename(str(arg)).lower()
    if name not in ("desktop.py", "launcher.py"):
        return False
    path = Path(arg)
    if not path.is_absolute():
        try:
            path = Path(proc.cwd()) / path
        except Exception:
            path = BASE / path
    return (path.parent / "atlas" / "agent.py").exists()


def old_instances(own_pid=None):
    """Çalışan ATLAS masaüstü süreçleri (kendimiz hariç). Yalnızca yanında atlas/agent.py bulunan desktop.py/launcher.py
    çalıştıran Python süreçleri — başka programlara dokunmaz."""
    try:
        import psutil
    except ImportError:
        return []
    own_pid = own_pid or os.getpid()
    out = []
    for p in psutil.process_iter(["pid", "name", "cmdline", "exe"]):
        try:
            if p.info["pid"] == own_pid:
                continue
            cmd = p.info.get("cmdline") or []
            if FROZEN:
                if p.info.get("exe") and _same_path(p.info["exe"], sys.executable):
                    out.append(p)
                continue
            if "python" not in (p.info.get("name") or "").lower():
                continue
            if "--setup" in cmd:
                continue
            if any(_is_atlas_script(arg, p) for arg in cmd[1:]):
                out.append(p)
        except Exception:
            continue
    return out


def stop_old_instances(timeout=6.0) -> int:
    procs = old_instances()
    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    deadline = time.time() + timeout
    for p in procs:
        try:
            p.wait(max(0.1, deadline - time.time()))
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
    return len(procs)
