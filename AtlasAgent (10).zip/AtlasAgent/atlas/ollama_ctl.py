"""Ollama sunucu denetimi: başlat / durdur / yeniden başlat, süreçler, ortam ayarları, log.

ATLAS, Ollama'yı kendi optimize ortam değişkenleriyle başlatır (Flash Attention, q8 KV önbelleği…).
Hangi ayarlarla başlatıldığı PID dosyasına özet (hash) olarak yazılır; ayarlar değişince panel
"yeniden başlatma gerekli" der.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

from .config import CFG, DATA

IS_WIN = sys.platform == "win32"
NOWIN = 0x08000000 if IS_WIN else 0
PID_FILE = DATA / "ollama.pid"
LOG_FILE = DATA / "ollama.log"
LOG_MAX = 5 * 1024 * 1024

try:
    import psutil  # type: ignore
except Exception:  # pragma: no cover
    psutil = None

KV_TYPES = ("f16", "q8_0", "q4_0")
ENV_KEY_RE = re.compile(r"^[A-Z_][A-Z0-9_]*$")


# ------------------------------------------------------------------ ayarlar → ortam
def base_url():
    return CFG["ollama_url"].rstrip("/")


def host_port():
    u = urlsplit(base_url())
    return f"{u.hostname or '127.0.0.1'}:{u.port or 11434}"


def parse_extra_env(text):
    out, bad = {}, []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            bad.append(line)
            continue
        k, v = line.split("=", 1)
        k = k.strip().upper()
        if not ENV_KEY_RE.match(k):
            bad.append(line)
            continue
        out[k] = v.strip()
    return out, bad


def server_env():
    o = CFG.get("ollama_server", {}) or {}
    kv = o.get("kv_cache_type") or "q8_0"
    env = {
        "OLLAMA_FLASH_ATTENTION": "1" if o.get("flash_attention", True) else "0",
        "OLLAMA_KV_CACHE_TYPE": kv if kv in KV_TYPES else "q8_0",
        "OLLAMA_MAX_LOADED_MODELS": str(max(1, int(o.get("max_loaded_models") or 2))),
        "OLLAMA_NUM_PARALLEL": str(max(1, int(o.get("num_parallel") or 1))),
        "OLLAMA_KEEP_ALIVE": str(CFG["performance"].get("keep_alive", "30m")),
        "OLLAMA_HOST": host_port(),
    }
    if int(o.get("context_length") or 0) > 0:
        env["OLLAMA_CONTEXT_LENGTH"] = str(int(o["context_length"]))
    if int(o.get("gpu_overhead_mb") or 0) > 0:
        env["OLLAMA_GPU_OVERHEAD"] = str(int(o["gpu_overhead_mb"]) * 1024 * 1024)
    if (o.get("models_dir") or "").strip():
        env["OLLAMA_MODELS"] = o["models_dir"].strip()
    extra, _ = parse_extra_env(o.get("extra_env", ""))
    env.update(extra)
    return env


# Başlatma biçimi değişince sürüm artar → eski biçimle çalışan Ollama açılışta otomatik yeniden başlatılır.
# v2: DETACHED_PROCESS kaldırıldı (runner süreçleri için konsol pencereleri açılıyordu).
SPAWN_VERSION = 2


def env_hash(env=None):
    data = dict(env or server_env(), _spawn=SPAWN_VERSION)
    return hashlib.sha1(json.dumps(data, sort_keys=True).encode()).hexdigest()[:12]


def _hidden_startupinfo():
    """Windows: süreç ve (konsolu miras alan) alt süreçleri tamamen gizli başlasın."""
    if not IS_WIN:
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0  # SW_HIDE
    return si


# ------------------------------------------------------------------ keşif
def find_exe():
    exe = shutil.which("ollama")
    if exe:
        return exe
    if IS_WIN:
        for base in (os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", "")):
            for sub in (("Programs", "Ollama", "ollama.exe"), ("Ollama", "ollama.exe")):
                p = Path(base, *sub)
                if base and p.exists():
                    return str(p)
    return None


def version(timeout=2.0):
    try:
        with urllib.request.urlopen(base_url() + "/api/version", timeout=timeout) as r:
            return json.loads(r.read().decode()).get("version", "?")
    except Exception:
        return None


_EXE_VER = {}


def installed_version(exe=None):
    """Sunucu kapalıyken kurulu sürüm (`ollama --version`), önbellekli."""
    exe = exe or find_exe()
    if not exe:
        return None
    try:
        key = (exe, os.path.getmtime(exe))
    except OSError:
        return None
    if key not in _EXE_VER:
        try:
            out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=6, creationflags=NOWIN,
                                 encoding="utf-8", errors="replace")
            m = re.search(r"(\d+\.\d+\.\d+)", (out.stdout or "") + (out.stderr or ""))
            _EXE_VER[key] = m.group(1) if m else None
        except Exception:
            _EXE_VER[key] = None
    return _EXE_VER[key]


def is_up(timeout=2.0):
    return version(timeout) is not None


def models_dir():
    d = (CFG.get("ollama_server", {}) or {}).get("models_dir") or os.environ.get("OLLAMA_MODELS")
    return Path(d) if d else Path.home() / ".ollama" / "models"


def server_log_candidates():
    c = [LOG_FILE]
    if IS_WIN and os.environ.get("LOCALAPPDATA"):
        c.append(Path(os.environ["LOCALAPPDATA"]) / "Ollama" / "server.log")
    c.append(Path.home() / ".ollama" / "logs" / "server.log")
    return c


# ------------------------------------------------------------------ PID dosyası
def read_pid():
    try:
        raw = PID_FILE.read_text().strip()
    except Exception:
        return {}
    try:
        d = json.loads(raw)
        return d if isinstance(d, dict) else {"pid": int(d)}
    except Exception:
        try:
            return {"pid": int(raw)}
        except ValueError:
            return {}


def write_pid(pid, h):
    PID_FILE.write_text(json.dumps({"pid": pid, "hash": h, "started": time.time()}))


# ------------------------------------------------------------------ süreçler
def _is_ollama(name):
    n = (name or "").lower()
    return n.startswith("ollama")


def processes():
    out = []
    if psutil:
        for p in psutil.process_iter(["pid", "name", "memory_info", "create_time", "cmdline"]):
            try:
                if not _is_ollama(p.info["name"]):
                    continue
                cmd = " ".join(p.info.get("cmdline") or [])
                out.append({"pid": p.info["pid"], "name": p.info["name"],
                            "mem_mb": round((p.info["memory_info"].rss if p.info.get("memory_info") else 0) / 1048576),
                            "started": p.info.get("create_time"), "cmd": cmd[:300],
                            "kind": _kind(p.info["name"], cmd)})
            except Exception:
                continue
        return out
    if IS_WIN:
        try:
            r = subprocess.run('tasklist /FO CSV /NH /FI "IMAGENAME eq ollama*"', shell=True, capture_output=True,
                               text=True, creationflags=NOWIN, timeout=8, encoding="utf-8", errors="replace")
            for line in r.stdout.splitlines():
                cols = [c.strip('"') for c in re.findall(r'"[^"]*"', line)]
                if len(cols) >= 5 and _is_ollama(cols[0]):
                    mem = int(re.sub(r"\D", "", cols[4]) or 0) // 1024
                    out.append({"pid": int(cols[1]), "name": cols[0], "mem_mb": mem, "started": None, "cmd": "",
                                "kind": _kind(cols[0], "")})
        except Exception:
            pass
        return out
    try:
        r = subprocess.run(["ps", "-eo", "pid=,rss=,etimes=,args="], capture_output=True, text=True, timeout=5)
        now = time.time()
        for line in r.stdout.splitlines():
            parts = line.split(None, 3)
            if len(parts) < 4:
                continue
            exe = Path(parts[3].split()[0]).name
            if _is_ollama(exe):
                out.append({"pid": int(parts[0]), "name": exe, "mem_mb": int(parts[1]) // 1024,
                            "started": now - int(parts[2]), "cmd": parts[3][:300], "kind": _kind(exe, parts[3])})
    except Exception:
        pass
    return out


def _kind(name, cmd):
    n, c = (name or "").lower(), (cmd or "").lower()
    if "app" in n:
        return "tray"          # Ollama'nın kendi tepsi uygulaması
    if "runner" in c or "llama_server" in n or "llama-server" in n:
        return "runner"        # model çalıştırıcı (VRAM'deki model)
    return "server"


def pid_alive(pid):
    if not pid:
        return False
    if psutil:
        return psutil.pid_exists(int(pid))
    if IS_WIN:
        r = subprocess.run(f'tasklist /FI "PID eq {int(pid)}" /NH', shell=True, capture_output=True, text=True,
                           creationflags=NOWIN)
        return str(pid) in r.stdout
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


# ------------------------------------------------------------------ durum
def status():
    ver = version()
    info = read_pid()
    procs = processes()
    ours = bool(info.get("pid")) and pid_alive(info.get("pid")) and ver is not None
    env = server_env()
    md = models_dir()
    disk = None
    try:
        probe = md if md.exists() else md.anchor or Path.home()
        du = shutil.disk_usage(probe)
        disk = {"free": du.free, "total": du.total}
    except Exception:
        pass
    log = next((str(p) for p in server_log_candidates() if p.exists()), str(LOG_FILE))
    if ours and LOG_FILE.exists():
        log = str(LOG_FILE)
    return {
        "running": ver is not None, "version": ver, "url": base_url(), "exe": find_exe(),
        "pid": info.get("pid") if ours else None, "started": info.get("started") if ours else None,
        "ours": ours, "applied": bool(ours and info.get("hash") == env_hash(env)),
        "external": ver is not None and not ours,
        "tray_app": any(p["kind"] == "tray" for p in procs),
        "manage": bool((CFG.get("ollama_server", {}) or {}).get("manage", True)),
        "processes": procs, "env": env, "models_dir": str(md), "disk": disk, "log_path": log,
        "psutil": psutil is not None,
        "installed_version": ver or installed_version(),
    }


# ------------------------------------------------------------------ denetim
def _rotate_log():
    try:
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > LOG_MAX:
            LOG_FILE.replace(LOG_FILE.with_suffix(".log.1"))
    except Exception:
        pass


def stop(timeout=15.0):
    """Tüm Ollama süreçlerini (tepsi uygulaması, sunucu, model çalıştırıcıları) durdurur."""
    procs = processes()
    if psutil and procs:
        ps_ = []
        for p in procs:
            try:
                ps_.append(psutil.Process(p["pid"]))
            except Exception:
                pass
        for p in sorted(ps_, key=lambda x: 0 if "app" in x.name().lower() else 1):
            try:
                p.terminate()
            except Exception:
                pass
        _, alive = psutil.wait_procs(ps_, timeout=5)
        for p in alive:
            try:
                p.kill()
            except Exception:
                pass
    elif IS_WIN:
        subprocess.run('taskkill /F /IM "ollama app.exe" >nul 2>&1', shell=True, creationflags=NOWIN)
        subprocess.run('taskkill /F /IM ollama.exe >nul 2>&1', shell=True, creationflags=NOWIN)
        subprocess.run('taskkill /F /IM ollama_llama_server.exe >nul 2>&1', shell=True, creationflags=NOWIN)
    else:
        for p in procs:
            try:
                os.kill(p["pid"], 15)
            except OSError:
                pass
    t0 = time.time()
    while time.time() - t0 < timeout:
        if not is_up(0.8):
            break
        time.sleep(0.4)
    try:
        PID_FILE.unlink()
    except Exception:
        pass
    return not is_up(0.8)


def start(wait=40.0):
    """Ollama'yı ATLAS ayarlarıyla başlatır. Dönüş: (başarılı, mesaj)."""
    if is_up():
        return True, "Ollama zaten çalışıyor."
    exe = find_exe()
    if not exe:
        return False, "Ollama bulunamadı. KUR.bat ile kurun veya https://ollama.com/download adresinden indirin."
    _rotate_log()
    env = os.environ.copy()
    senv = server_env()
    env.update(senv)
    log = open(LOG_FILE, "ab")
    log.write(f"\n===== ATLAS: Ollama başlatılıyor {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n".encode())
    log.flush()
    # ÖNEMLİ: DETACHED_PROCESS KULLANMA. Konsolsuz (detached) bir ollama.exe, her model yüklemesinde başlattığı
    # runner sürecine YENİ ve GÖRÜNÜR bir konsol açtırır (model değişiminde yanıp sönen terminaller). CREATE_NO_WINDOW
    # ise görünmez bir konsol verir; runner'lar onu miras alır ve hiçbir pencere açılmaz.
    flags = (0x00000200 | NOWIN) if IS_WIN else 0  # CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
    try:
        p = subprocess.Popen([exe, "serve"], env=env, stdout=log, stderr=log, stdin=subprocess.DEVNULL,
                             creationflags=flags, startupinfo=_hidden_startupinfo(), close_fds=True,
                             start_new_session=not IS_WIN)
    except Exception as e:
        return False, f"Ollama başlatılamadı: {e}"
    write_pid(p.pid, env_hash(senv))
    t0 = time.time()
    while time.time() - t0 < wait:
        if is_up(1.0):
            return True, f"Ollama başlatıldı (PID {p.pid})."
        if p.poll() is not None:
            return False, f"Ollama hemen kapandı (çıkış kodu {p.returncode}). Log: {LOG_FILE}"
        time.sleep(0.4)
    return False, f"Ollama {int(wait)} sn içinde yanıt vermedi. Log: {LOG_FILE}"


def restart():
    stop()
    time.sleep(0.6)
    return start()


def ensure(log=lambda msg, level="info": None):
    """Açılışta çağrılır: Ollama'yı ATLAS ayarlarıyla çalışır hale getirir."""
    st_ver = version()
    info = read_pid()
    ours = bool(info.get("pid")) and pid_alive(info.get("pid")) and st_ver is not None
    manage = bool((CFG.get("ollama_server", {}) or {}).get("manage", True))
    if ours and info.get("hash") == env_hash():
        log("Ollama zaten ATLAS ayarlarıyla çalışıyor.", "ok")
        return True
    if st_ver is not None and not ours and not manage:
        log(f"Harici Ollama v{st_ver} kullanılıyor (ATLAS yönetimi kapalı).", "ok")
        return True
    if st_ver is not None:
        log("Çalışan Ollama ATLAS ayarlarıyla yeniden başlatılıyor…", "warn")
        stop()
        time.sleep(1.0)
    ok, msg = start()
    log(msg + (" FlashAttention + KV önbellek ayarları aktif." if ok else ""), "ok" if ok else "err")
    return ok


def log_tail(lines=400, path=None):
    cands = [Path(path)] if path else server_log_candidates()
    st_ours = read_pid().get("pid") and LOG_FILE.exists()
    if not path and st_ours:
        cands = [LOG_FILE] + [c for c in cands if c != LOG_FILE]
    for p in cands:
        if p.exists():
            try:
                size = p.stat().st_size
                with open(p, "rb") as f:
                    f.seek(max(0, size - 400_000))
                    data = f.read().decode("utf-8", "replace")
                ls = data.splitlines()
                if size > 400_000 and ls:
                    ls = ls[1:]
                return {"path": str(p), "lines": ls[-int(lines):], "size": size,
                        "others": [str(c) for c in server_log_candidates() if c.exists() and c != p]}
            except Exception as e:
                return {"path": str(p), "lines": [f"(log okunamadı: {e})"], "size": 0, "others": []}
    return {"path": str(LOG_FILE), "lines": [], "size": 0, "others": []}
