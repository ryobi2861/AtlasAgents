"""İş akışları (playbook): sık yapılan işler için adım adım tarifler.

Kullanıcının mesajı bir iş akışının anahtar kelimeleriyle eşleşirse tarif o turun bağlamına eklenir ve ajan onu izler.
Ajan başarılı bir yöntemi save_playbook ile yeni iş akışı olarak kaydedebilir; kullanıcı Hafıza panelinden yönetir.
"""
import re

DEFAULT_PLAYBOOKS = [
    {
        "name": "C++ derleme / link hatası çözme",
        "keywords": "derleme hata, derlenmiyor, derleyemiyorum, compile error, build hata, build fail, linker, lnk2019, "
                    "lnk1104, lnk2001, lnk1120, undefined reference, unresolved external, c2065, c2039, error c, hata veriyor",
        "steps": "1. Tam hata çıktısını al (proje build komutu veya compile_cpp); tahminle düzeltme yapma.\n"
                 "2. İLK hatadan başla — sonrakiler çoğu zaman onun sonucudur.\n"
                 "3. Hata koduna göre kök neden: LNK1104 '...exe dosyası açılamıyor' bir kaynak kod hatası değildir; linker çıktı dosyasını oluşturamıyor/açamıyordur. Hedef EXE çalışıyorsa Windows dosyayı kilitlemiş olabilir; ayrıca yanlış/olmayan çıktı yolu, yazma izni veya antivirüs kilidi olasılıklarını kontrol et. Önce build betiğindeki /OUT: veya hedef yolunu ve dosyanın varlığını incele; süreç çalışıyorsa kullanıcıya kapatmasını söyle, kendiliğinden taskkill/oyun başlatma-kapatma yapma. Dosya kilidi kalktıktan sonra yeniden derle.\n"
                 "4. C2065/undeclared → eksik #include veya isim alanı; LNK2019/2001 → tanımı olmayan fonksiyon, eksik .cpp veya .lib (#pragma comment(lib) / linker girdisi), çağrı kuralı/extern \"C\" uyumsuzluğu; C2039 → yanlış üye/sürüm.\n"
                 "5. İlgili kaynak/derleme ayarını read_file ile incele, yalnızca kaynak kod hatasıysa hedefli edit_file ile düzelt.\n"
                 "6. Yeniden derle; temiz olana kadar tekrarla. Sonunda kök nedeni ve değişikliği 2-3 satırla yaz.",
    },
    {
        "name": "Yeni C++ projesi kurma (CMake)",
        "keywords": "yeni proje, proje oluştur, proje kur, cmake projesi, cmakelists, iskelet, boilerplate, sıfırdan proje",
        "steps": "1. Hedefi netleştir: exe mi DLL mi kütüphane mi; C++ standardı (varsayılan C++20); x86/x64.\n"
                 "2. Klasör yapısı: CMakeLists.txt, src/, include/, (gerekirse) third_party/.\n"
                 "3. CMakeLists: cmake_minimum_required(3.20), project(), CMAKE_CXX_STANDARD, MSVC için /W4 /utf-8 "
                 "/permissive-, Release'te /O2; DLL ise add_library(SHARED).\n"
                 "4. Minimal ama derlenebilir kaynak dosyaları yaz (yer tutucu yok).\n"
                 "5. Derle ve doğrula; build komutunu README'ye ve proje notlarına ekle.",
    },
    {
        "name": "DLL projesi iskeleti (Windows)",
        "keywords": "dll projesi, dll iskeleti, dllmain, dll oluştur, dll yaz, enjekte edilecek dll, injected dll",
        "steps": "1. Mimariyi hedef sürece göre seç (x86/x64 aynı olmalı).\n"
                 "2. DllMain'i minimal tut: DLL_PROCESS_ATTACH'ta DisableThreadLibraryCalls + iş için CreateThread; "
                 "DllMain içinde LoadLibrary/kilit/uzun iş YAPMA (loader lock).\n"
                 "3. Ana iş parçacığında kurulum; çıkışta (DLL_PROCESS_DETACH / unload) kaynakları ve hook'ları geri al.\n"
                 "4. Hata ayıklama için OutputDebugString veya dosyaya log.\n"
                 "5. Derle (/LD veya add_library SHARED), export/bağımlılıkları kontrol et.",
    },
    {
        "name": "ImGui / girdi (input) sorunları",
        "keywords": "imgui, wndproc, sızıyor, sızma, input sızıyor, girdi sızıyor, oyuna gidiyor, wm_char, "
                    "wantcapture, overlay input, imgui input, imgui klavye, imgui fare",
        "steps": "1. WndProc zincirini doğrula: ImGui_ImplWin32_WndProcHandler önce çağrılmalı, sonra orijinal WndProc.\n"
                 "2. io.WantCaptureMouse / io.WantCaptureKeyboard / WantTextInput bayraklarına göre oyuna giden "
                 "mesajları filtrele (WM_KEYDOWN/UP, WM_CHAR, WM_*BUTTON*, WM_MOUSEWHEEL, WM_INPUT).\n"
                 "3. Raw Input / DirectInput kullanan uygulamalarda WndProc filtresi yetmez; o kanalı da ele al.\n"
                 "4. Durum geçişlerini (açık/kapalı/odak) tek bir yerde yönet; kenar (edge) tetiklemeyi doğrula.\n"
                 "5. Değişiklikten sonra derle; test adımlarını kullanıcıya net yaz.",
    },
    {
        "name": "Performans optimizasyonu",
        "keywords": "optimize, optimizasyon, yavaş, hızlandır, performans, darboğaz, bottleneck, profil, fps düşük",
        "steps": "1. Önce ölç: sıcak noktayı bul (profil, zamanlama, sayaçlar); tahminle optimize etme.\n"
                 "2. Algoritma/karmaşıklık → veri düzeni (önbellek dostu, SoA) → gereksiz kopya/allocation → "
                 "paralellik/SIMD sırasıyla ele al.\n"
                 "3. Her değişiklikten sonra doğruluğu ve kazancı tekrar ölç.\n"
                 "4. Sonuçları önce/sonra rakamlarıyla raporla.",
    },
    {
        "name": "IDA bulgularını rapora dökme",
        "keywords": "ida rapor, analiz raporu, bulguları rapor, rapora dök, reverse rapor, tersine mühendislik raporu",
        "steps": "1. Proje notlarındaki ve bu sohbetteki bulguları topla (adres → ad → işlev).\n"
                 "2. Eksik kritik fonksiyon varsa ida decompile ile doğrula; kanıtsız iddia yazma.\n"
                 "3. Rapor yapısı: Özet · Dosya bilgisi (mimari, derleyici, packer) · Önemli fonksiyonlar tablosu "
                 "(adres | ad | işlev) · Veri yapıları/sabitler · Akış · Açık sorular.\n"
                 "4. Raporu proje klasörüne .md olarak yaz ve proje notlarını güncelle.",
    },
    {
        "name": "Çökme / crash analizi",
        "keywords": "çöküyor, crash, çökme, access violation, 0xc0000005, segfault, dump, minidump, kapanıyor",
        "steps": "1. Belirtiyi netleştir: ne zaman, hangi adımda, hata kodu/adres.\n"
                 "2. Dump/log varsa incele (cdb/WinDbg: !analyze -v, kv); yoksa log ekleyerek yeniden üret.\n"
                 "3. Şüpheliler: null/dangling pointer, sınır aşımı, iş parçacığı yarışı, yanlış çağrı kuralı, "
                 "DllMain/loader lock, mimari uyumsuzluğu.\n"
                 "4. Kök nedeni düzelt, derle ve senaryoyu tekrar test ettir.",
    },
]


def fold(text: str) -> str:
    """Türkçe duyarsız karşılaştırma: küçük harf + aksan katlama."""
    t = (text or "").replace("İ", "i").replace("I", "ı").lower()
    return t.translate(str.maketrans("çğıöşü", "cgiosu"))


def keywords_of(pb) -> list:
    return [k.strip() for k in str(pb.get("keywords", "")).split(",") if k.strip()]


def score(pb, text: str) -> int:
    """Anahtar kelime puanı: çok kelimeli/uzun ifadeler 2, kısa tek kelimeler 1 puan."""
    ft = fold(text)
    total = 0
    for k in keywords_of(pb):
        fk = fold(k)
        if len(fk) < 3:
            continue
        if re.search(r"(?<![a-z0-9])" + re.escape(fk), ft):
            total += 2 if (" " in fk or len(fk) >= 8) else 1
    return total


def match(playbooks, text: str, k: int = 2, min_score: int = 2):
    scored = [(score(pb, text), pb.get("uses", 0) or 0, pb) for pb in playbooks]
    scored = [x for x in scored if x[0] >= min_score]
    scored.sort(key=lambda x: (-x[0], -x[1]))
    return [pb for _, _, pb in scored[:k]]


def render(pbs) -> str:
    out = []
    for pb in pbs:
        out.append(f"### İş akışı: {pb['name']}\n{pb['steps'].strip()}")
    return "\n\n".join(out)
