"""run_command güvenlik/akıl katmanı.

Sorunlar (gerçek kullanımdan):
 - "derle" denince model oyunu BAŞLATAN start.bat'ı çalıştırdı (derleme betiği build.bat idi).
 - Model "başlat → tasklist → taskkill → başlat …" döngüsüne girdi; komutlar her seferinde biraz farklı yazıldığı ve
   çıktılar (PID, süre) değiştiği için tekrar koruması bunu ilerleme sandı.
Çözüm:
 - Projedeki .bat/.cmd/.ps1 betikleri İÇERİKLERİNE göre sınıflandırılır (derleme / başlatma) ve modele bildirilir.
 - Her komut çözümlenir: build / launch (program başlatma) / kill (süreç öldürme) / query / other.
 - Program başlatma ve süreç öldürme yalnızca kullanıcının isteği bunu içeriyorsa yapılır ("çalıştır/başlat/test et").
 - Aynı programı başlatma / öldürme ve aynı komutu tekrar tekrar çalıştırma tur başına sınırlıdır.
"""
import re
import shlex
from pathlib import Path

BUILD_TOOL_RE = re.compile(
    r"(?<![\w.-])(cmake|msbuild|ninja|cl|clang\+\+|clang-cl|clang|g\+\+|gcc|mingw32-make|make|nmake|devenv|meson|"
    r"premake\d*|xmake|cargo\s+build|dotnet\s+build|vcvars\w*\.bat|vsdevcmd\.bat)(\.exe)?(?![\w-])", re.I)
BUILD_NAME_RE = re.compile(r"(build|derle|compile|make|rebuild|cmake|msbuild)", re.I)
BUILD_ONLY_RE = re.compile(r"\b(derle|derlemesi|derlensin|build(?:\.bat|\.cmd)?|rebuild|compile)\b", re.I)
APP_RUN_RE = re.compile(r"(oyunu?\s+(?:çalıştır|başlat|aç|test)|programı\s+(?:çalıştır|başlat|aç)|exe(?:\s+dosyasını)?\s+(?:çalıştır|başlat)|stomp_loader(?:\.exe)?\s+(?:çalıştır|başlat)|oyna)", re.I)
LAUNCH_NAME_RE = re.compile(r"(start|run|launch|ba[sş]lat|play|oyna|inject|loader|calistir|çalıştır)", re.I)
KILL_PROGS = {"taskkill", "tskill", "pskill", "kill", "killall", "pkill"}
QUERY_PROGS = {
    "tasklist", "dir", "where", "type", "findstr", "find", "echo", "git", "more", "tree", "ls", "cat", "set", "ver",
    "systeminfo", "wmic", "sc", "netstat", "ipconfig", "whoami", "certutil", "fc", "comp", "dumpbin", "objdump", "nm",
    "strings", "sigcheck", "diec", "die", "file", "attrib", "copy", "xcopy", "move", "del", "erase", "mkdir", "md",
    "rmdir", "rd", "ren", "rename", "robocopy", "python", "python3", "py", "pip", "node", "npm", "cls", "timeout",
    "hostname", "reg", "query", "fsutil", "icacls", "chcp", "exit", "rem", "pause", "date", "time", "vol", "label",
    "sort", "head", "tail", "grep", "wc", "du", "df", "ps", "pwd", "mklink", "7z", "tar", "unzip", "zip", "curl",
    "wget", "ping", "tracert", "nslookup", "cmd", "conan", "vcpkg",
}
# İzin yalnızca İSTEK kipinden gelir: "çalıştır", "başlat", "test et", "çalıştırsın", "başlatabilirsin", "çalıştırmanı".
# "başlatma" (olumsuz/isim), "başlatıp başlatıp öldürüyor" (şikâyet), "start.bat" (dosya adı) izin DEĞİLDİR.
_REQ = r"(?:(?![\w])|s[ıi]n\b|abilirsin|ebilirsin|man[ıi]\b|mak\s+isti|ır\s+m[ıi]s[ıi]n|er\s+mis[ıi]n)"
RUN_INTENT_RE = re.compile(
    r"((?:çalıştır|calistir|başlat|baslat|test\s*et|\baç|\bdene|enjekte\s*et|inject\s*et|debug\s*et)" + _REQ +
    r"|test\s*edip|deneyip|\b(run|launch|start|execute|test)\b(?![.\w]))", re.I)
KILL_INTENT_RE = re.compile(r"((?:öldür|oldur|kapat|sonlandır|durdur)" + _REQ + r"|\bkill\b(?![.\w]))", re.I)

CAP_LAUNCH, CAP_KILL, CAP_SAME, CAP_BUILD = 2, 2, 3, 6


def _tokens(seg: str):
    try:
        return shlex.split(seg, posix=False)
    except ValueError:
        return seg.split()


def _unq(t: str) -> str:
    return t.strip().strip('"').strip("'")


def _base(t: str) -> str:
    """Platformdan bağımsız dosya adı (Windows yolu Linux'ta da doğru ayrılır)."""
    return re.split(r"[\\/]", _unq(t))[-1]


def _strip_comments(text: str) -> str:
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.lower().startswith(("rem ", "rem\t", "::", "#", "@rem")) or s.lower() == "rem":
            continue
        out.append(s.lstrip("@"))
    return "\n".join(out)


def script_kind(path: Path):
    """(tür, özet satırı) — tür: build | launch | other. Build adı kullanıcı derleme kuralıdır."""
    # start.bat oyun/uygulama başlatır; içinde build kelimesi/komutu geçse de asla derleme betiği sayma.
    if path.stem.lower() == "start":
        return "launch", "start.bat başlatma betiğidir; derleme için build.bat kullan."
    # Kullanıcının açık kuralı: build.bat derlemedir. İçerikte oluşan EXE'nin yolu geçse bile çalıştırma betiği sayma.
    if BUILD_NAME_RE.search(path.stem):
        try:
            body = _strip_comments(path.read_text(encoding="utf-8", errors="replace")[:65536])
            first = next((ln[:160] for ln in body.splitlines() if ln.strip()), "")
        except OSError:
            first = ""
        return "build", first
    try:
        body = _strip_comments(path.read_text(encoding="utf-8", errors="replace")[:65536])
    except OSError:
        body = ""
    lines = [ln for ln in body.splitlines() if not ln.lower().startswith(("echo", "setlocal", "endlocal", "title",
                                                                          "chcp", "cls", "pause", "exit", "set "))]
    for ln in lines:
        if BUILD_TOOL_RE.search(ln):
            return "build", ln[:160]
    for ln in lines:
        low = ln.lower()
        if re.match(r"start\b", low) or "start-process" in low or re.search(r"\.exe\b", low):
            return "launch", ln[:160]
    # içerik belirsiz → başka betik çağırıyor olabilir: ada göre
    if BUILD_NAME_RE.search(path.stem):
        return "build", (lines[0][:160] if lines else "")
    if LAUNCH_NAME_RE.search(path.stem):
        return "launch", (lines[0][:160] if lines else "")
    return "other", (lines[0][:160] if lines else "")


def _segments(cmd: str):
    # powershell -Command "..." içini de böl
    return [s for s in re.split(r"\s*(?:&&|\|\||&|\||;)\s*", cmd or "") if s.strip()]


def analyze(command: str, wd: Path):
    """Komutu parçalara ayırıp her parçayı sınıflandırır. [(tür, hedef, aile anahtarı, açıklama)]"""
    out = []
    cur = Path(wd) if wd else Path.cwd()
    for seg in _segments(command):
        s = seg.strip().strip("()").strip()
        toks = [t for t in _tokens(s) if t]
        if not toks:
            continue
        first = _unq(toks[0])
        low = first.lower()
        name = _base(low)
        stem = name[:-4] if name.endswith((".exe", ".com")) else name
        if low in ("cd", "chdir", "pushd") and len(toks) > 1:
            arg = _unq(" ".join(t for t in toks[1:] if t.lower() != "/d"))
            p = Path(arg)
            cur = p if p.is_absolute() else (cur / p)
            continue
        if low in ("popd",):
            continue
        if low == "call" and len(toks) > 1:
            first = _unq(toks[1]); low = first.lower(); name = _base(low)
            stem = name[:-4] if name.endswith((".exe", ".com")) else name
            toks = toks[1:]
        if low == "start":
            rest = toks[1:]
            tgt = ""
            i = 0
            while i < len(rest):
                t = rest[i]
                if t.startswith("/"):
                    if t.lower() == "/d" and i + 1 < len(rest):
                        i += 1
                    i += 1
                    continue
                if t in ('""', "''") or (t.startswith('"') and not tgt and i + 1 < len(rest)
                                          and _unq(t) and not re.search(r"\.(exe|bat|cmd|lnk)$", _unq(t), re.I)):
                    i += 1          # pencere başlığı
                    continue
                tgt = _unq(t)
                break
            tn = _base(tgt).lower() if tgt else "?"
            if tn.endswith((".bat", ".cmd")):
                p = Path(tgt) if Path(tgt).is_absolute() else cur / tgt
                k, line = script_kind(p)
                if k == "build":
                    out.append(("build", tn, "build:" + tn, line))
                    continue
            out.append(("launch", tn, "launch:" + tn, s[:160]))
            continue
        if stem in KILL_PROGS or low in ("stop-process", "spps") or re.search(r"stop-process", s, re.I):
            m = re.search(r"/im\s+(\"[^\"]+\"|\S+)", s, re.I) or re.search(r"-name\s+(\"[^\"]+\"|\S+)", s, re.I) \
                or re.search(r"/pid\s+(\d+)", s, re.I)
            tgt = _unq(m.group(1)).lower() if m else "?"
            out.append(("kill", tgt, "kill:" + tgt, s[:160]))
            continue
        if stem in ("powershell", "pwsh") and re.search(r"start-process", s, re.I):
            m = re.search(r"start-process\s+(?:-filepath\s+)?(\"[^\"]+\"|'[^']+'|\S+)", s, re.I)
            tn = _base(m.group(1)).lower() if m else "?"
            out.append(("launch", tn, "launch:" + tn, s[:160]))
            continue
        if BUILD_TOOL_RE.match(first) or BUILD_TOOL_RE.match(name) or BUILD_TOOL_RE.search(" ".join(toks[:2])) \
                and stem not in QUERY_PROGS:
            out.append(("build", stem, "build:" + _norm(s), s[:160]))
            continue
        if name.endswith((".bat", ".cmd", ".ps1")):
            p = Path(first) if Path(first).is_absolute() else cur / first
            k, line = script_kind(p)
            kk = {"build": "build", "launch": "launch"}.get(k, "other")
            out.append((kk, name, f"{kk}:{name}", line or s[:160]))
            continue
        if stem in QUERY_PROGS:
            out.append(("query", stem, "query:" + _norm(s), s[:160]))
            continue
        if name.endswith((".exe", ".com")) or (cur / (first + ".exe")).exists() or (cur / first).suffix.lower() == ".exe":
            nm = name if name.endswith((".exe", ".com")) else name + ".exe"
            out.append(("launch", nm, "launch:" + nm, s[:160]))
            continue
        out.append(("other", stem, "other:" + _norm(s), s[:160]))
    return out


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())[:200]


def project_commands(root):
    """Projedeki betikler: {"build": [(göreli yol, satır)], "launch": [...], "other": [...]} (kök + 1 alt seviye)."""
    res = {"build": [], "launch": [], "other": []}
    if not root:
        return res
    root = Path(root)
    if not root.is_dir():
        return res
    skip = {".git", ".atlas", ".vs", "node_modules", "__pycache__", ".venv", "x64", "Debug", "Release", "CMakeFiles"}
    cands = []
    try:
        for p in root.iterdir():
            if p.is_file() and p.suffix.lower() in (".bat", ".cmd", ".ps1"):
                cands.append(p)
            elif p.is_dir() and p.name not in skip and not p.name.startswith("."):
                try:
                    cands += [q for q in p.iterdir() if q.is_file() and q.suffix.lower() in (".bat", ".cmd", ".ps1")]
                except OSError:
                    pass
    except OSError:
        return res
    for p in sorted(cands)[:40]:
        k, line = script_kind(p)
        res[k].append((str(p.relative_to(root)).replace("/", "\\"), line))
    has_cmake = (root / "CMakeLists.txt").exists()
    sln = sorted(root.glob("*.sln"))[:1]
    if not res["build"]:
        if has_cmake:
            res["build"].append(("(CMake)", "cmake -S . -B build && cmake --build build --config Release"))
        elif sln:
            res["build"].append((sln[0].name, f"msbuild \"{sln[0].name}\" /p:Configuration=Release /m"))
    return res


def render_commands(cmds) -> str:
    if not cmds or not (cmds["build"] or cmds["launch"]):
        return ""
    out = ["## Bu projenin komutları (ATLAS betik içeriklerinden tespit etti — doğru olanı kullan)"]
    if cmds["build"]:
        out.append("DERLEME (kullanıcı \"derle/build\" derse bunlar):")
        out += [f"- {p} → `{ln}`" if ln else f"- {p}" for p, ln in cmds["build"][:6]]
    if cmds["launch"]:
        out.append("BAŞLATMA / ÇALIŞTIRMA — derleme DEĞİL; yalnızca kullanıcı açıkça \"çalıştır/başlat/test et\" derse:")
        out += [f"- {p} → `{ln}`" if ln else f"- {p}" for p, ln in cmds["launch"][:6]]
    out.append("Kullanıcının başlattığı programları (oyun vb.) kendiliğinden başlatma, öldürme (taskkill) veya yeniden "
               "başlatma; bir programı tekrar tekrar başlatıp kapatma döngüsüne girme.")
    return "\n".join(out)


class TurnState:
    def __init__(self):
        self.fam = {}      # aile anahtarı → çalıştırılma sayısı
        self.whole = {}    # tüm komut (normalize) → sayı

    def bump(self, key, d=1):
        self.fam[key] = self.fam.get(key, 0) + d
        return self.fam[key]


def _build_hint(cmds) -> str:
    if cmds and cmds["build"]:
        p, ln = cmds["build"][0]
        return f" Derlemek için bu projenin derleme komutu: {p}" + (f" (`{ln}`)" if ln and p.startswith("(") else "") + "."
    return " Derlemek için compile_cpp aracını veya projenin derleme betiğini kullan."


def check(command: str, wd, root, intent_text: str, state: TurnState, cmds=None):
    """Komut çalıştırılmalı mı? Uygunsa None; değilse modele dönecek açıklayıcı hata metni.
    İzin verilen komutlar sayaçlara işlenir."""
    parts = analyze(command, Path(wd) if wd else (Path(root) if root else Path.cwd()))
    raw_intent = intent_text or ""
    run_ok = bool(RUN_INTENT_RE.search(raw_intent))
    build_only = bool(BUILD_ONLY_RE.search(raw_intent)) and not bool(APP_RUN_RE.search(raw_intent))
    kill_ok = bool(KILL_INTENT_RE.search(raw_intent)) or (run_ok and not build_only)
    req = re.sub(r"\s+", " ", raw_intent).strip()[:140]
    for kind, tgt, key, desc in parts:
        if kind == "launch" and (not run_ok or build_only):
            what = f"{tgt} bir BAŞLATMA betiği/programı (içinde: `{desc}`), derleme değil." if tgt.endswith(
                (".bat", ".cmd", ".ps1")) else f"Bu komut bir programı BAŞLATIR ({tgt})."
            return (f"Çalıştırılmadı: {what} Kullanıcı program başlatmayı istemedi (istek: «{req}»). Program "
                    f"başlatma/öldürme yalnızca kullanıcı açıkça \"çalıştır / başlat / test et\" derse yapılır."
                    + _build_hint(cmds))
        if kind == "kill" and not kill_ok:
            return (f"Çalıştırılmadı: süreç sonlandırma ({tgt}) istenmedi (istek: «{req}»). Kullanıcının programlarını "
                    f"kendiliğinden kapatma; gerekiyorsa kullanıcıya sor.")
    # tekrar sınırları (yalnızca izinli komutlar için)
    whole = _norm(command)
    if state.whole.get(whole, 0) >= CAP_SAME:
        return (f"Çalıştırılmadı: aynı komutu bu turda {state.whole[whole]} kez çalıştırdın. Tekrar etme; elindeki "
                f"sonuçlarla ilerle ya da farklı bir yaklaşım dene.")
    for kind, tgt, key, desc in parts:
        n = state.fam.get(key, 0)
        if kind == "launch" and n >= CAP_LAUNCH:
            return (f"Çalıştırılmadı: {tgt} bu turda zaten {n} kez başlatıldı. Programı başlat-kapat döngüsüne sokma. "
                    f"Gözlemini kullanıcıya bildir; gerekirse kullanıcıdan programı kendisinin başlatıp sonucu "
                    f"söylemesini iste (ask_user).")
        if kind == "kill" and n >= CAP_KILL:
            return (f"Çalıştırılmadı: {tgt} bu turda zaten {n} kez sonlandırıldı. Başlat-öldür döngüsünü bırak ve "
                    f"şu ana kadarki sonucu kullanıcıya bildir.")
        if kind == "build" and n >= CAP_BUILD:
            return (f"Çalıştırılmadı: bu turda {n} kez derleme denendi. Aynı hatada dönüyorsan dur: hatanın kök nedenini "
                    f"açıkla ve kullanıcıya bildir.")
        if kind == "query" and n >= CAP_SAME:
            return f"Çalıştırılmadı: `{desc}` bu turda {n} kez çalıştırıldı; sonuç değişmeyecek, tekrar etme."
    state.whole[whole] = state.whole.get(whole, 0) + 1
    for kind, tgt, key, desc in parts:
        state.bump(key)
    return None


def is_build(command: str, wd) -> bool:
    return any(k == "build" for k, *_ in analyze(command, Path(wd) if wd else Path.cwd()))
