"""Proje indeksleyici: dosya ağacı + C/C++ sembol haritası + aranabilir kod parçaları."""
import json
import os
import re
import time
from pathlib import Path

SKIP_DIRS = {".git", ".svn", ".hg", ".vs", ".vscode", ".idea", "node_modules", "build", "out", "bin",
             "obj", "x64", "x86", "Debug", "Release", "RelWithDebInfo", "MinSizeRel", ".cache",
             "__pycache__", ".venv", "venv", "ipch", ".atlas", "vcpkg_installed", "_deps"}
CODE_EXT = {".c", ".cc", ".cpp", ".cxx", ".c++", ".h", ".hh", ".hpp", ".hxx", ".inl", ".ipp", ".tpp",
            ".ixx", ".cppm", ".asm", ".s", ".S", ".def", ".rc", ".cmake", ".py", ".cs", ".rs", ".go",
            ".java", ".js", ".ts", ".lua", ".hlsl", ".glsl", ".cu", ".json", ".toml", ".yaml", ".yml",
            ".md", ".txt", ".ini", ".bat", ".ps1", ".sh"}
SPECIAL_FILES = {"CMakeLists.txt", "Makefile", "makefile", "meson.build", "premake5.lua", "xmake.lua",
                 "conanfile.txt", "vcpkg.json", ".clang-format", "build.ninja"}
MAX_FILE = 512 * 1024
MAX_FILES = 6000
CHUNK = 80
OVERLAP = 12

TYPE_RE = re.compile(r"^\s*(?:template\s*<.*>\s*)?(class|struct|union|enum\s+class|enum|namespace)\s+"
                     r"(?:__declspec\([^)]*\)\s*|alignas\([^)]*\)\s*)?([A-Za-z_]\w*)\s*(?:final\s*)?[:{]?")
FUNC_RE = re.compile(r"^(?!\s*(?:if|for|while|switch|return|else|do|case|catch|sizeof|new|delete)\b)"
                     r"\s*(?:[\w:<>,\*&~\s]{1,120}?)\s+[\*&]*([A-Za-z_~][\w~]*(?:::[A-Za-z_~][\w~]*)*)\s*"
                     r"\([^;{}]{0,200}\)\s*(?:const)?\s*(?:noexcept)?\s*(?:override|final)?\s*\{?\s*$")
IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")


def iter_files(root: Path):
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith("cmake-build")
                       and not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix in CODE_EXT or fn in SPECIAL_FILES:
                try:
                    if p.stat().st_size > MAX_FILE:
                        continue
                except OSError:
                    continue
                yield p
                count += 1
                if count >= MAX_FILES:
                    return


def extract_symbols(text, is_cpp):
    syms = []
    if not is_cpp:
        return syms
    for line in text.splitlines():
        if len(line) > 300 or line.lstrip().startswith(("//", "*", "#")):
            continue
        m = TYPE_RE.match(line)
        if m:
            kind = m.group(1).split()[0]
            syms.append(f"{kind} {m.group(2)}")
            continue
        m = FUNC_RE.match(line)
        if m:
            syms.append(m.group(1) + "()")
    # tekrarları kaldır, sırayı koru
    seen, out = set(), []
    for s in syms:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def index_project(store, pid, root):
    root = Path(root)
    if not root.is_dir():
        raise FileNotFoundError(f"Klasör bulunamadı: {root}")
    t0 = time.time()
    store.clear_chunks(pid)
    map_lines, all_symbols, chunks = [], set(), []
    nfiles = 0
    for p in iter_files(root):
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        nfiles += 1
        rel = p.relative_to(root).as_posix()
        lines = text.splitlines()
        is_cpp = p.suffix.lower() in {".c", ".cc", ".cpp", ".cxx", ".c++", ".h", ".hh", ".hpp", ".hxx",
                                      ".inl", ".ipp", ".tpp", ".ixx", ".cppm", ".cu"}
        syms = extract_symbols(text, is_cpp)
        for s in syms:
            name = s.split()[-1].rstrip("()").split("::")[-1]
            if len(name) >= 3:
                all_symbols.add(name)
        sym_txt = ", ".join(syms[:14]) + (" …" if len(syms) > 14 else "")
        map_lines.append(f"{rel} ({len(lines)} satır)" + (f": {sym_txt}" if sym_txt else ""))
        for start in range(0, max(len(lines), 1), CHUNK - OVERLAP):
            part = lines[start:start + CHUNK]
            if not part:
                break
            chunks.append((rel, start + 1, start + len(part), "\n".join(part)))
            if len(chunks) >= 2000:
                store.add_chunks(pid, chunks)
                chunks = []
    if chunks:
        store.add_chunks(pid, chunks)

    map_lines.sort()
    proj_map = "\n".join(map_lines)
    if len(proj_map) > 7000:  # çok büyük projede klasör özetine düş
        dirs = {}
        for ln in map_lines:
            d = ln.split(" (")[0].rsplit("/", 1)[0] if "/" in ln.split(" (")[0] else "."
            dirs[d] = dirs.get(d, 0) + 1
        head = "\n".join(map_lines[:60])
        proj_map = (head + f"\n… (+{len(map_lines) - 60} dosya)\nKlasörler: " +
                    ", ".join(f"{d}/ ({n})" for d, n in sorted(dirs.items())[:80]))[:7000]
    store.update_project(pid, map=proj_map, symbols=json.dumps(sorted(all_symbols)[:20000]),
                         indexed_at=time.time())
    return {"files": nfiles, "symbols": len(all_symbols), "seconds": round(time.time() - t0, 2)}


def code_terms(text, symbols: set):
    """Kullanıcı mesajında geçen, projede gerçekten var olan tanımlayıcılar."""
    found = []
    for t in IDENT_RE.findall(text or ""):
        if t in symbols and t not in found:
            found.append(t)
    for t in re.findall(r"[\w\-/]+\.(?:cpp|hpp|h|c|cc|cxx|hxx|inl|txt|cmake)", text or ""):
        base = t.split("/")[-1].rsplit(".", 1)[0]
        if base and base not in found:
            found.append(base)
    return found[:12]
