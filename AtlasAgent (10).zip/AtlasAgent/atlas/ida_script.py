# -*- coding: utf-8 -*-
"""ATLAS ⇄ IDA Pro köprüsü (IDAPython, IDA 8.x / 9.x).

idat.exe -A -S"ida_script.py" -L"log.txt" [-o"db.i64"] <hedef>
İş tanımı ATLAS_IDA_JOB ortam değişkenindeki JSON dosyasından okunur (tırnak/boşluk sorunu olmasın diye),
sonuç job["out"] dosyasına JSON olarak yazılır. Bu dosya IDA'nın içinde çalışır, ATLAS'ın içinde değil.
"""
import io
import json
import os
import re
import sys
import time
import traceback

import ida_auto
import ida_bytes
import ida_entry
import ida_funcs
import ida_ida
import ida_kernwin
import ida_lines
import ida_loader
import ida_nalt
import ida_name
import ida_pro
import ida_segment
import ida_xref
import idaapi
import idautils
import idc

BADADDR = idaapi.BADADDR
T0 = time.time()

# ------------------------------------------------------------------ yardımcılar
SUSPICIOUS = {
    "anti_debug": ["IsDebuggerPresent", "CheckRemoteDebuggerPresent", "NtQueryInformationProcess", "OutputDebugString",
                   "NtSetInformationThread", "GetTickCount", "QueryPerformanceCounter", "ZwQueryInformationProcess"],
    "injection": ["VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread", "NtCreateThreadEx", "QueueUserAPC",
                  "SetWindowsHookEx", "OpenProcess", "NtMapViewOfSection", "RtlCreateUserThread", "SetThreadContext"],
    "crypto": ["CryptEncrypt", "CryptDecrypt", "CryptAcquireContext", "BCryptEncrypt", "BCryptDecrypt",
               "CryptGenRandom", "BCryptGenRandom", "CryptHashData"],
    "network": ["socket", "connect", "WSAStartup", "InternetOpen", "InternetConnect", "HttpSendRequest",
                "URLDownloadToFile", "WinHttpOpen", "send", "recv", "getaddrinfo"],
    "process": ["CreateProcess", "ShellExecute", "WinExec", "CreateToolhelp32Snapshot", "Process32First",
                "TerminateProcess"],
    "registry": ["RegOpenKey", "RegSetValue", "RegCreateKey", "RegQueryValue", "RegDeleteKey"],
    "file": ["CreateFile", "WriteFile", "ReadFile", "DeleteFile", "MoveFile", "CopyFile", "FindFirstFile"],
    "dynamic_load": ["LoadLibrary", "GetProcAddress", "LdrLoadDll", "LdrGetProcedureAddress"],
    "driver": ["IoCreateDevice", "IoCreateSymbolicLink", "ZwOpenProcess", "PsSetCreateProcessNotifyRoutine",
               "ObRegisterCallbacks", "MmGetSystemRoutineAddress", "KeStackAttachProcess"],
}


def hx(ea):
    return "0x%X" % ea


def clean(s):
    return ida_lines.tag_remove(s or "")


def fname(ea):
    n = ida_funcs.get_func_name(ea) or ida_name.get_name(ea) or ""
    return n


def demangled(ea):
    n = ida_name.get_name(ea) or ""
    try:
        d = ida_name.demangle_name(n, 0) if n else None
    except Exception:
        d = None
    return d or n


def imagebase():
    try:
        return ida_nalt.get_imagebase()
    except Exception:
        return 0


def resolve(target):
    """'0x140001000' | '140001000h' | 'sub_140001000' | 'main' | export adı | demangle edilmiş ad | RVA → ea"""
    t = str(target or "").strip().strip("`'\"")
    if not t:
        raise ValueError("hedef boş")
    m = re.fullmatch(r"(?:0x)?([0-9A-Fa-f]+)h?", t)
    if m and (t.lower().startswith("0x") or t.lower().endswith("h") or len(m.group(1)) >= 6):
        ea = int(m.group(1), 16)
        if not ida_bytes.is_mapped(ea) and ida_bytes.is_mapped(ea + imagebase()):
            ea += imagebase()  # RVA verilmiş
        if not ida_bytes.is_mapped(ea):
            raise ValueError("adres eşlenmemiş: %s" % t)
        return ea
    ea = ida_name.get_name_ea(BADADDR, t)
    if ea != BADADDR:
        return ea
    for pre in ("_", "__imp_", "j_", "?"):
        ea = ida_name.get_name_ea(BADADDR, pre + t)
        if ea != BADADDR:
            return ea
    m = re.fullmatch(r"(?:sub|loc|nullsub|j_sub|unknown_libname)_([0-9A-Fa-f]+)", t)
    if m:
        return int(m.group(1), 16)
    low = t.lower()
    best = None
    for f in idautils.Functions():
        n = fname(f)
        d = demangled(f)
        if low in (n.lower(), d.lower()) or d.lower().startswith(low + "("):
            return f
        if best is None and (low in n.lower() or low in d.lower()):
            best = f
    if best is not None:
        return best
    m = re.fullmatch(r"(?:0x)?([0-9A-Fa-f]{3,})h?", t)  # kısa hex: RVA veya adres olarak dene
    if m:
        v = int(m.group(1), 16)
        for ea in (v, v + imagebase()):
            if ida_bytes.is_mapped(ea):
                return ea
    raise ValueError("bulunamadı: %s (functions/strings ile doğru adı veya 0x… adresini bul)" % t)


def func_of(ea):
    f = ida_funcs.get_func(ea)
    if not f:
        raise ValueError("%s bir fonksiyonun içinde değil" % hx(ea))
    return f


HEXRAYS = None


def hexrays():
    """Hex-Rays decompiler'ı başlatır (batch modda eklenti otomatik yüklenmeyebilir)."""
    global HEXRAYS
    if HEXRAYS is not None:
        return HEXRAYS
    try:
        import ida_hexrays
    except Exception:
        HEXRAYS = False
        return False
    ok = False
    try:
        ok = bool(ida_hexrays.init_hexrays_plugin())
    except Exception:
        ok = False
    if not ok:
        proc = (ida_ida.inf_get_procname() or "").lower()
        is64 = ida_ida.inf_is_64bit()
        if proc.startswith("metapc") or proc in ("pc", "80386p", "80686p"):
            cands = ["hexx64"] if is64 else ["hexrays", "hexx86"]
        elif proc.startswith("arm"):
            cands = ["hexarm64"] if is64 else ["hexarm"]
        elif proc.startswith("mips"):
            cands = ["hexmips"]
        elif proc.startswith("ppc"):
            cands = ["hexppc64"] if is64 else ["hexppc"]
        else:
            cands = ["hexx64", "hexrays", "hexarm64", "hexarm"]
        for c in cands:
            try:
                if ida_loader.load_plugin(c) and ida_hexrays.init_hexrays_plugin():
                    ok = True
                    break
            except Exception:
                pass
    HEXRAYS = ida_hexrays if ok else False
    return HEXRAYS


def disasm_func(ea, max_lines=400):
    f = ida_funcs.get_func(ea)
    start, end = (f.start_ea, f.end_ea) if f else (ea, BADADDR)
    out, cur, n = [], start if f else ea, 0
    while cur != BADADDR and (cur < end) and n < max_lines:
        line = clean(idc.generate_disasm_line(cur, 0))
        cmt = idc.get_cmt(cur, 0) or idc.get_cmt(cur, 1)
        lbl = ida_name.get_name(cur) if cur != start and ida_name.get_name(cur) else ""
        if lbl:
            out.append("%s:" % lbl)
        out.append("  %s  %s%s" % (hx(cur), line, ("" if not cmt or ";" in line else "  ; " + cmt)))
        nxt = idc.next_head(cur, end if f else BADADDR)
        cur, n = nxt, n + 1
    if f and n >= max_lines:
        out.append("  … (%d satırda kesildi)" % max_lines)
    return "\n".join(out)


def decompile_one(ea, max_lines):
    f = func_of(ea)
    hr = hexrays()
    head = {"name": demangled(f.start_ea), "ea": hx(f.start_ea), "size": f.end_ea - f.start_ea}
    if hr:
        try:
            cf = hr.decompile(f.start_ea)
            if cf:
                lines = str(cf).splitlines()
                trunc = len(lines) > max_lines
                if trunc:
                    lines = lines[:max_lines] + ["// … (%d satırdan %d tanesi gösterildi)" % (len(lines), max_lines)]
                return dict(head, kind="pseudocode", code="\n".join(lines), truncated=trunc)
        except Exception as e:
            head["decompile_error"] = str(e)[:300]
    else:
        head["decompile_error"] = "Hex-Rays decompiler bu mimari/lisans için kullanılamıyor"
    return dict(head, kind="disasm", code=disasm_func(f.start_ea, max_lines))


def callers_callees(f):
    callers, seen = [], set()
    for x in idautils.XrefsTo(f.start_ea, 0):
        cf = ida_funcs.get_func(x.frm)
        key = cf.start_ea if cf else x.frm
        if key in seen:
            continue
        seen.add(key)
        callers.append({"ea": hx(x.frm), "func": demangled(cf.start_ea) if cf else "", "type": "call" if x.iscode else "data"})
    callees, seen = [], set()
    for head in idautils.FuncItems(f.start_ea):
        for x in idautils.XrefsFrom(head, 0):
            if x.type in (ida_xref.fl_CN, ida_xref.fl_CF):
                t = ida_funcs.get_func(x.to)
                to = t.start_ea if t else x.to
                if to in seen or to == f.start_ea:
                    continue
                seen.add(to)
                callees.append({"ea": hx(to), "func": demangled(to)})
    return callers, callees


def imports(filter_=""):
    out = []
    flt = (filter_ or "").lower()
    for i in range(ida_nalt.get_import_module_qty()):
        mod = ida_nalt.get_import_module_name(i) or "?"

        def cb(ea, name, ordinal, mod=mod):
            n = name or ("#%d" % ordinal)
            if not flt or flt in n.lower() or flt in mod.lower():
                out.append({"module": mod, "name": n, "ea": hx(ea)})
            return True
        ida_nalt.enum_import_names(i, cb)
    return out


def strings(filter_="", limit=200, minlen=5, with_xrefs=True):
    s = idautils.Strings(False)
    try:
        s.setup(strtypes=[ida_nalt.STRTYPE_C, ida_nalt.STRTYPE_C_16], minlen=minlen)
    except Exception:
        s.setup(minlen=minlen)
    out, flt = [], (filter_ or "").lower()
    rx = None
    if flt.startswith("re:"):
        rx = re.compile(filter_[3:], re.I)
    for st in s:
        try:
            txt = str(st)
        except Exception:
            continue
        if rx is not None:
            if not rx.search(txt):
                continue
        elif flt and flt not in txt.lower():
            continue
        item = {"ea": hx(st.ea), "text": txt[:300]}
        if with_xrefs:
            refs = []
            for x in idautils.XrefsTo(st.ea, 0):
                f = ida_funcs.get_func(x.frm)
                refs.append(demangled(f.start_ea) + "@" + hx(x.frm) if f else hx(x.frm))
                if len(refs) >= 4:
                    break
            item["refs"] = refs
        out.append(item)
        if len(out) >= limit:
            break
    return out


# ------------------------------------------------------------------ eylemler
def a_overview(job):
    segs = []
    for sea in idautils.Segments():
        sg = ida_segment.getseg(sea)
        perm = sg.perm
        segs.append({"name": ida_segment.get_segm_name(sg), "start": hx(sg.start_ea), "size": sg.end_ea - sg.start_ea,
                     "perm": ("r" if perm & 4 else "-") + ("w" if perm & 2 else "-") + ("x" if perm & 1 else "-")})
    entries = []
    for i in range(ida_entry.get_entry_qty()):
        o = ida_entry.get_entry_ordinal(i)
        ea = ida_entry.get_entry(o)
        entries.append({"name": ida_entry.get_entry_name(o) or "", "ea": hx(ea), "ordinal": o})
    funcs = list(idautils.Functions())
    lib = thunk = 0
    big = []
    for f in funcs:
        fn = ida_funcs.get_func(f)
        if fn.flags & ida_funcs.FUNC_LIB:
            lib += 1
        elif fn.flags & ida_funcs.FUNC_THUNK:
            thunk += 1
        else:
            big.append((fn.end_ea - fn.start_ea, f))
    big.sort(reverse=True)
    named = [demangled(f) for _, f in big if not re.match(r"(sub|nullsub|j_sub)_", fname(f))]
    imps = imports()
    sus = {}
    for cat, names in SUSPICIOUS.items():
        hits = sorted({i["name"] for i in imps for n in names if i["name"].lower().lstrip("_").startswith(n.lower())})
        if hits:
            sus[cat] = hits[:12]
    mods = {}
    for i in imps:
        mods[i["module"]] = mods.get(i["module"], 0) + 1
    md5 = ""
    try:
        md5 = ida_nalt.retrieve_input_file_md5().hex()
    except Exception:
        pass
    try:
        ftype = ida_loader.get_file_type_name()
    except Exception:
        ftype = ""
    try:
        comp = idaapi.get_compiler_name(ida_ida.inf_get_cc_id())
    except Exception:
        comp = ""
    sts = strings(limit=int(job.get("limit") or 60), minlen=6, with_xrefs=False)
    return {
        "file": ida_nalt.get_input_file_path(), "md5": md5, "type": ftype, "proc": ida_ida.inf_get_procname(),
        "bits": 64 if ida_ida.inf_is_64bit() else 32, "imagebase": hx(imagebase()), "compiler": comp,
        "ida": idaapi.get_kernel_version(), "decompiler": bool(hexrays()),
        "segments": segs, "entries": entries[:30], "entries_total": len(entries),
        "functions": {"total": len(funcs), "library": lib, "thunk": thunk, "user": len(big)},
        "largest": [{"name": demangled(f), "ea": hx(f), "size": sz} for sz, f in big[:15]],
        "named": named[:40], "import_modules": mods, "suspicious_imports": sus,
        "strings_sample": [s["text"] for s in sts],
    }


def a_functions(job):
    flt = (job.get("filter") or "").lower()
    off, lim = int(job.get("offset") or 0), int(job.get("limit") or 150)
    rows = []
    for f in idautils.Functions():
        fn = ida_funcs.get_func(f)
        n = demangled(f)
        if flt and flt not in n.lower() and flt not in fname(f).lower():
            continue
        if job.get("user_only") and fn.flags & (ida_funcs.FUNC_LIB | ida_funcs.FUNC_THUNK):
            continue
        rows.append({"ea": hx(f), "name": n, "size": fn.end_ea - fn.start_ea,
                     "lib": bool(fn.flags & ida_funcs.FUNC_LIB), "thunk": bool(fn.flags & ida_funcs.FUNC_THUNK)})
    if job.get("sort") == "size":
        rows.sort(key=lambda r: -r["size"])
    return {"total": len(rows), "offset": off, "items": rows[off:off + lim]}


def targets(job):
    raw = job.get("target") or ""
    items = raw if isinstance(raw, list) else re.split(r"[,;\n]+", str(raw))
    items = [str(t).strip() for t in items if str(t).strip()]
    if not items:
        raise ValueError("target gerekli (fonksiyon adı veya adres)")
    return items[:8]


def a_decompile(job):
    out = []
    for t in targets(job):
        try:
            r = decompile_one(resolve(t), int(job.get("max_lines") or 250))
            if job.get("with_xrefs", True):
                c, e = callers_callees(func_of(resolve(t)))
                r["callers"] = c[:15]
                r["callees"] = e[:25]
            out.append(r)
        except Exception as e:
            out.append({"target": t, "error": str(e)})
    return {"items": out}


def a_disasm(job):
    out = []
    for t in targets(job):
        try:
            ea = resolve(t)
            f = ida_funcs.get_func(ea)
            out.append({"name": demangled(f.start_ea) if f else ida_name.get_name(ea), "ea": hx(f.start_ea if f else ea),
                        "code": disasm_func(ea, int(job.get("max_lines") or 300))})
        except Exception as e:
            out.append({"target": t, "error": str(e)})
    return {"items": out}


def a_xrefs(job):
    out = []
    for t in targets(job):
        try:
            ea = resolve(t)
            f = ida_funcs.get_func(ea)
            r = {"target": t, "ea": hx(ea), "name": demangled(ea)}
            if f and f.start_ea == ea:
                r["callers"], r["callees"] = callers_callees(f)
            else:
                refs = []
                for x in idautils.XrefsTo(ea, 0):
                    cf = ida_funcs.get_func(x.frm)
                    refs.append({"ea": hx(x.frm), "func": demangled(cf.start_ea) if cf else "",
                                 "type": "code" if x.iscode else "data"})
                    if len(refs) >= 80:
                        break
                r["refs_to"] = refs
            out.append(r)
        except Exception as e:
            out.append({"target": t, "error": str(e)})
    return {"items": out}


def a_strings(job):
    return {"items": strings(job.get("filter") or "", int(job.get("limit") or 150), int(job.get("min_len") or 5))}


def a_imports(job):
    return {"items": imports(job.get("filter") or "")[: int(job.get("limit") or 400)]}


def a_rename(job):
    done = []
    pairs = job.get("renames") or []
    if job.get("target") and job.get("new_name"):
        pairs.append({"target": job["target"], "new_name": job["new_name"]})
    for p in pairs[:40]:
        try:
            ea = resolve(p["target"])
            f = ida_funcs.get_func(ea)
            if f and f.start_ea != ea and not ida_name.get_name(ea):
                ea = f.start_ea
            ok = ida_name.set_name(ea, str(p["new_name"]), ida_name.SN_NOWARN | ida_name.SN_FORCE)
            done.append({"target": p["target"], "ea": hx(ea), "new_name": ida_name.get_name(ea), "ok": bool(ok)})
        except Exception as e:
            done.append({"target": p.get("target"), "error": str(e)})
    return {"items": done, "saved": True}


def a_comment(job):
    ea = resolve(job.get("target"))
    text = str(job.get("text") or "")
    f = ida_funcs.get_func(ea)
    if f and f.start_ea == ea and not job.get("line"):
        idc.set_func_cmt(ea, text, 1)
        where = "fonksiyon"
    else:
        idc.set_cmt(ea, text, 0)
        where = "satır"
    return {"ea": hx(ea), "where": where, "saved": True}


def a_script(job):
    buf = io.StringIO()
    g = {"__name__": "__atlas__", "result": None, "ARGS": job.get("args") or {}}
    for m in ("idaapi", "idc", "idautils", "ida_funcs", "ida_name", "ida_bytes", "ida_segment", "ida_nalt", "ida_xref",
              "ida_lines", "ida_entry", "ida_ida", "ida_auto", "ida_loader", "ida_kernwin"):
        g[m] = sys.modules[m]
    g.update(resolve=resolve, hx=hx, demangled=demangled, decompile=lambda t, n=300: decompile_one(resolve(t), n)["code"])
    old = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(job.get("code") or "", "<atlas>", "exec"), g)
    finally:
        sys.stdout = old
    res = g.get("result")
    try:
        json.dumps(res)
    except Exception:
        res = repr(res)
    return {"stdout": buf.getvalue()[-60000:], "result": res, "saved": bool(job.get("save"))}


ACTIONS = {"overview": a_overview, "functions": a_functions, "decompile": a_decompile, "disasm": a_disasm,
           "xrefs": a_xrefs, "strings": a_strings, "imports": a_imports, "rename": a_rename, "comment": a_comment,
           "script": a_script}


def main():
    job_path = os.environ.get("ATLAS_IDA_JOB") or (sys.argv[1] if len(sys.argv) > 1 else "")
    job = json.load(open(job_path, encoding="utf-8"))
    res = {"ok": False}
    try:
        ida_auto.auto_wait()
        res["analysis_s"] = round(time.time() - T0, 2)
        fn = ACTIONS.get(job.get("action"))
        if not fn:
            raise ValueError("bilinmeyen eylem: %s" % job.get("action"))
        res["data"] = fn(job)
        res["ok"] = True
        if job.get("action") in ("rename", "comment") or (job.get("action") == "script" and job.get("save")):
            res["modified"] = True
    except Exception as e:
        res["error"] = "%s: %s" % (type(e).__name__, e)
        res["trace"] = traceback.format_exc()[-3000:]
    res["total_s"] = round(time.time() - T0, 2)
    with open(job["out"], "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False)
    try:
        ida_loader.save_database(None, 0)  # analiz + yeniden adlandırmalar kalıcı olsun
    except Exception:
        pass
    ida_pro.qexit(0)


if __name__ in ("__main__", "__atlas_main__") or os.environ.get("ATLAS_IDA_JOB"):
    main()
