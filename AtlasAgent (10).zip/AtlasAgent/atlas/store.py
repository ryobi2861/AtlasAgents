"""Kalıcı hafıza: SQLite (WAL) + FTS5 tam metin arama + vektör (embedding) arama.

Tablolar
- projects      : projeler, yaşayan proje notları, proje haritası
- conversations : sohbetler + kayan özet (eski mesajlar unutulmaz, özetlenir)
- messages      : tüm mesajlar (görsel analizleri dahil)
- memories      : kalıcı bilgiler (kullanıcı / proje kapsamlı) + embedding
- code_chunks   : proje kaynak kodu parçaları (FTS5 ile aranır)
"""
import json
import re
import sqlite3
import threading
import time

import numpy as np

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS playbooks(
    id INTEGER PRIMARY KEY, project_id INTEGER, name TEXT NOT NULL, keywords TEXT DEFAULT '',
    steps TEXT NOT NULL, source TEXT DEFAULT 'manual', uses INTEGER DEFAULT 0, created REAL, updated REAL);

CREATE TABLE IF NOT EXISTS projects(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, path TEXT DEFAULT '',
    description TEXT DEFAULT '', notes TEXT DEFAULT '', map TEXT DEFAULT '',
    symbols TEXT DEFAULT '[]', indexed_at REAL DEFAULT 0, instructions TEXT DEFAULT '',
    agent_instructions TEXT DEFAULT '', created REAL, updated REAL);

CREATE TABLE IF NOT EXISTS conversations(
    id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT DEFAULT 'Yeni sohbet',
    summary TEXT DEFAULT '', summary_upto INTEGER DEFAULT 0,
    last_role TEXT DEFAULT '', created REAL, updated REAL);
CREATE INDEX IF NOT EXISTS ix_conv_proj ON conversations(project_id, updated);

CREATE TABLE IF NOT EXISTS messages(
    id INTEGER PRIMARY KEY, conv_id INTEGER NOT NULL, role TEXT NOT NULL,
    content TEXT DEFAULT '', images TEXT DEFAULT '[]', extra TEXT DEFAULT '',
    model TEXT DEFAULT '', trace TEXT DEFAULT '[]', thinking TEXT DEFAULT '',
    stats TEXT DEFAULT '{}', created REAL);
CREATE INDEX IF NOT EXISTS ix_msg_conv ON messages(conv_id, id);

CREATE TABLE IF NOT EXISTS learning_events(
    id INTEGER PRIMARY KEY, message_id INTEGER UNIQUE, conv_id INTEGER NOT NULL, project_id INTEGER,
    request TEXT DEFAULT '', answer TEXT DEFAULT '', actions TEXT DEFAULT '[]',
    outcome TEXT DEFAULT 'attempted', feedback TEXT DEFAULT '', created REAL, updated REAL);
CREATE INDEX IF NOT EXISTS ix_learning_project ON learning_events(project_id, outcome, created);
CREATE INDEX IF NOT EXISTS ix_learning_conv ON learning_events(conv_id, created);

CREATE TABLE IF NOT EXISTS memories(
    id INTEGER PRIMARY KEY, project_id INTEGER, scope TEXT NOT NULL,
    content TEXT NOT NULL, embedding BLOB, source TEXT DEFAULT 'auto',
    hits INTEGER DEFAULT 0, created REAL);
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    content, content='memories', content_rowid='id',
    tokenize='unicode61 remove_diacritics 2');
CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
  INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content); END;
CREATE TRIGGER IF NOT EXISTS mem_ad AFTER DELETE ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content); END;
CREATE TRIGGER IF NOT EXISTS mem_au AFTER UPDATE OF content ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content);
  INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content); END;

CREATE TABLE IF NOT EXISTS file_changes(
    id INTEGER PRIMARY KEY, conv_id INTEGER, turn TEXT, path TEXT, before BLOB,
    existed INTEGER, tool TEXT, diff TEXT DEFAULT '', reverted INTEGER DEFAULT 0, created REAL);
CREATE INDEX IF NOT EXISTS ix_fc_turn ON file_changes(turn);
CREATE INDEX IF NOT EXISTS ix_fc_conv ON file_changes(conv_id);

CREATE TABLE IF NOT EXISTS code_chunks(
    id INTEGER PRIMARY KEY, project_id INTEGER, path TEXT,
    start_line INTEGER, end_line INTEGER, content TEXT);
CREATE INDEX IF NOT EXISTS ix_chunk_proj ON code_chunks(project_id);
CREATE VIRTUAL TABLE IF NOT EXISTS code_fts USING fts5(
    content, path, content='code_chunks', content_rowid='id',
    tokenize="unicode61 remove_diacritics 2 tokenchars '_'");
CREATE TRIGGER IF NOT EXISTS code_ai AFTER INSERT ON code_chunks BEGIN
  INSERT INTO code_fts(rowid, content, path) VALUES (new.id, new.content, new.path); END;
CREATE TRIGGER IF NOT EXISTS code_ad AFTER DELETE ON code_chunks BEGIN
  INSERT INTO code_fts(code_fts, rowid, content, path) VALUES('delete', old.id, old.content, old.path); END;
"""

STOP = set("""ve veya ile ama fakat için gibi bir bu şu o da de mi mı mu mü ne nasıl neden niye
hangi ki çok daha en sonra önce şimdi bana beni benim sen seni senin biz bize siz olan olarak
var yok evet hayır lütfen tamam acaba bunu şunu onu yap yapar misin mısın the and for with
that this from are was what how why you your can will have has into not but""".split())


def fts_query(text, stem=True, max_tokens=24):
    toks = re.findall(r"[\w]+", (text or "").lower(), re.UNICODE)
    out, seen = [], set()
    for t in toks:
        if len(t) < 3 or t in STOP or t.isdigit():
            continue
        if stem and len(t) > 5:  # Türkçe ekleri için kaba kök: ilk 5 harf + önek araması
            t = t[:5]
        if t in seen:
            continue
        seen.add(t)
        out.append(f'"{t}"*')
        if len(out) >= max_tokens:
            break
    return " OR ".join(out) if out else None


class Store:
    def __init__(self, path):
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._vec_cache = {}
        with self.lock:
            c = self.conn
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("PRAGMA temp_store=MEMORY")
            c.execute("PRAGMA mmap_size=268435456")
            c.execute("PRAGMA cache_size=-65536")
            fresh_pb = not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='playbooks'").fetchone()
            c.executescript(SCHEMA)
            if fresh_pb:   # varsayılan iş akışları yalnızca ilk kurulumda (silinenler geri gelmez)
                from .playbooks import DEFAULT_PLAYBOOKS
                now = time.time()
                c.executemany("INSERT INTO playbooks(project_id,name,keywords,steps,source,created,updated) "
                              "VALUES(NULL,?,?,?,'builtin',?,?)",
                              [(d["name"], d["keywords"], d["steps"], now, now) for d in DEFAULT_PLAYBOOKS])
            self._migrate(c)
            c.commit()

    MIGRATIONS = [("conversations", "plan", "TEXT DEFAULT '[]'"),
                  ("conversations", "pinned", "INTEGER DEFAULT 0"),
                  ("projects", "instructions", "TEXT DEFAULT ''"),
                  ("projects", "agent_instructions", "TEXT DEFAULT ''"),
                  ("messages", "turn", "TEXT DEFAULT ''"),
                  ("conversations", "brief", "TEXT DEFAULT ''")]

    def _migrate(self, c):
        for table, col, decl in self.MIGRATIONS:
            cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}
            if col not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")

    # ---------- düşük seviye ----------
    def q(self, sql, p=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, p).fetchall()]

    def one(self, sql, p=()):
        with self.lock:
            r = self.conn.execute(sql, p).fetchone()
            return dict(r) if r else None

    def x(self, sql, p=()):
        with self.lock:
            cur = self.conn.execute(sql, p)
            self.conn.commit()
            return cur.lastrowid

    # ---------- projeler ----------
    def projects(self):
        return self.q("SELECT id,name,path,description,indexed_at,updated FROM projects ORDER BY updated DESC")

    def project(self, pid):
        return self.one("SELECT * FROM projects WHERE id=?", (pid,)) if pid else None

    def add_project(self, name, path="", description=""):
        now = time.time()
        return self.x("INSERT INTO projects(name,path,description,created,updated) VALUES(?,?,?,?,?)",
                      (name, path, description, now, now))

    def update_project(self, pid, **kw):
        allowed = {"name", "path", "description", "notes", "map", "symbols", "indexed_at", "instructions", "agent_instructions"}
        sets = {k: v for k, v in kw.items() if k in allowed and v is not None}
        if not sets:
            return
        sets["updated"] = time.time()
        cols = ",".join(f"{k}=?" for k in sets)
        self.x(f"UPDATE projects SET {cols} WHERE id=?", (*sets.values(), pid))

    def delete_project(self, pid):
        with self.lock:
            convs = [r["id"] for r in self.q("SELECT id FROM conversations WHERE project_id=?", (pid,))]
            for cid in convs:
                self.conn.execute("DELETE FROM learning_events WHERE conv_id=?", (cid,))
                self.conn.execute("DELETE FROM messages WHERE conv_id=?", (cid,))
            self.conn.execute("DELETE FROM learning_events WHERE project_id=?", (pid,))
            self.conn.execute("DELETE FROM conversations WHERE project_id=?", (pid,))
            self.conn.execute("DELETE FROM memories WHERE project_id=?", (pid,))
            self.conn.execute("DELETE FROM code_chunks WHERE project_id=?", (pid,))
            self.conn.execute("DELETE FROM projects WHERE id=?", (pid,))
            self.conn.commit()
        self._vec_cache.clear()

    # ---------- sohbetler ----------
    def conversations(self, project_id):
        if project_id:
            return self.q("SELECT id,title,project_id,updated,pinned FROM conversations WHERE project_id=? ORDER BY pinned DESC, updated DESC LIMIT 300", (project_id,))
        return self.q("SELECT id,title,project_id,updated,pinned FROM conversations WHERE project_id IS NULL ORDER BY pinned DESC, updated DESC LIMIT 300")

    def all_conversations(self, limit=500):
        return self.q("SELECT c.id,c.title,c.project_id,c.updated,c.pinned,p.name AS project FROM conversations c "
                      "LEFT JOIN projects p ON p.id=c.project_id ORDER BY c.updated DESC LIMIT ?", (limit,))

    def conv(self, cid):
        return self.one("SELECT * FROM conversations WHERE id=?", (cid,))

    def add_conv(self, project_id=None, title="Yeni sohbet"):
        now = time.time()
        return self.x("INSERT INTO conversations(project_id,title,created,updated) VALUES(?,?,?,?)",
                      (project_id or None, title, now, now))

    def update_conv(self, cid, **kw):
        allowed = {"title", "summary", "summary_upto", "last_role", "plan", "pinned", "project_id", "brief"}
        touch = kw.pop("touch", True)
        sets = {k: v for k, v in kw.items() if k in allowed}
        if touch:
            sets["updated"] = time.time()
        if not sets:
            return
        cols = ",".join(f"{k}=?" for k in sets)
        self.x(f"UPDATE conversations SET {cols} WHERE id=?", (*sets.values(), cid))

    def delete_conv(self, cid):
        with self.lock:
            self.conn.execute("DELETE FROM learning_events WHERE conv_id=?", (cid,))
            self.conn.execute("DELETE FROM messages WHERE conv_id=?", (cid,))
            self.conn.execute("DELETE FROM conversations WHERE id=?", (cid,))
            self.conn.commit()

    # ---------- mesajlar ----------
    def messages(self, cid, after_id=0):
        rows = self.q("SELECT * FROM messages WHERE conv_id=? AND id>? ORDER BY id", (cid, after_id))
        for r in rows:
            for k in ("images", "trace"):
                try:
                    r[k] = json.loads(r[k] or "[]")
                except Exception:
                    r[k] = []
            try:
                r["stats"] = json.loads(r["stats"] or "{}")
            except Exception:
                r["stats"] = {}
        return rows

    def add_message(self, cid, role, content, images=None, extra="", model="", trace=None,
                    thinking="", stats=None, turn=""):
        mid = self.x("INSERT INTO messages(conv_id,role,content,images,extra,model,trace,thinking,stats,created,turn)"
                     " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                     (cid, role, content, json.dumps(images or []), extra, model,
                      json.dumps(trace or [], ensure_ascii=False), thinking,
                      json.dumps(stats or {}), time.time(), turn))
        self.x("UPDATE conversations SET updated=? WHERE id=?", (time.time(), cid))
        return mid

    def message(self, mid):
        return self.one("SELECT * FROM messages WHERE id=?", (mid,))

    def last_user_message(self, cid):
        r = self.one("SELECT * FROM messages WHERE conv_id=? AND role='user' ORDER BY id DESC LIMIT 1", (cid,))
        if r:
            r["images"] = json.loads(r["images"] or "[]")
        return r

    def add_learning_event(self, message_id, conv_id, project_id, request, answer, actions, outcome="attempted"):
        """Record one tool-using episode for auditable, feedback-driven improvement."""
        return self.x("INSERT OR IGNORE INTO learning_events(message_id,conv_id,project_id,request,answer,actions,"
                       "outcome,created,updated) VALUES(?,?,?,?,?,?,?,?,?)",
                      (message_id, conv_id, project_id, str(request or ""), str(answer or ""),
                       json.dumps(actions or [], ensure_ascii=False), outcome, time.time(), time.time()))

    def confirm_latest_learning_event(self, conv_id, outcome, feedback="", assistant_message_id=None):
        if outcome not in ("confirmed_success", "confirmed_failure"):
            return None
        if assistant_message_id is not None:
            row = self.one("SELECT id FROM learning_events WHERE conv_id=? AND message_id=? AND outcome NOT IN "
                           "('confirmed_success','confirmed_failure') ORDER BY id DESC LIMIT 1",
                           (conv_id, assistant_message_id))
        else:
            row = self.one("SELECT id FROM learning_events WHERE conv_id=? AND outcome NOT IN "
                           "('confirmed_success','confirmed_failure') ORDER BY id DESC LIMIT 1", (conv_id,))
        if not row:
            return None
        self.x("UPDATE learning_events SET outcome=?, feedback=?, updated=? WHERE id=?",
               (outcome, str(feedback or "")[:1000], time.time(), row["id"]))
        return row["id"]

    def recent_learning_events(self, project_id, limit=30):
        if project_id:
            return self.q("SELECT * FROM learning_events WHERE project_id=? ORDER BY id DESC LIMIT ?",
                          (project_id, int(limit)))
        return self.q("SELECT * FROM learning_events WHERE project_id IS NULL ORDER BY id DESC LIMIT ?",
                      (int(limit),))

    def delete_messages_from(self, cid, mid):
        """mid ve sonrasındaki tüm mesajları siler (düzenle / yeniden oluştur)."""
        self.x("DELETE FROM learning_events WHERE conv_id=? AND message_id IN (SELECT id FROM messages WHERE conv_id=? AND id>=?)",
               (cid, cid, mid))
        self.x("DELETE FROM messages WHERE conv_id=? AND id>=?", (cid, mid))
        c = self.conv(cid)
        if c and (c.get("summary_upto") or 0) >= mid:
            self.update_conv(cid, summary="", summary_upto=0)

    def search_messages(self, text, limit=40):
        like = f"%{text}%"
        return self.q("SELECT m.id, m.conv_id, m.role, substr(m.content, max(1, instr(lower(m.content), lower(?)) - 60), 180) AS snippet, "
                      "c.title, c.project_id FROM messages m JOIN conversations c ON c.id=m.conv_id "
                      "WHERE m.content LIKE ? ORDER BY m.id DESC LIMIT ?", (text, like, limit))

    # ---------- dosya değişiklikleri (geri alma noktaları) ----------
    def record_change(self, conv_id, turn, path, before, existed, tool, diff):
        first = self.one("SELECT id FROM file_changes WHERE turn=? AND path=?", (turn, path))
        if first:  # aynı turda ilk durumu koru, sadece diff'i güncelle
            self.x("UPDATE file_changes SET diff=? WHERE id=?", (diff, first["id"]))
            return first["id"]
        return self.x("INSERT INTO file_changes(conv_id,turn,path,before,existed,tool,diff,created) VALUES(?,?,?,?,?,?,?,?)",
                      (conv_id, turn, path, before, int(existed), tool, diff, time.time()))

    def changes(self, conv_id=None, turn=None):
        if turn:
            return self.q("SELECT * FROM file_changes WHERE turn=? ORDER BY id", (turn,))
        return self.q("SELECT id,conv_id,turn,path,existed,tool,diff,reverted,created FROM file_changes "
                      "WHERE conv_id=? ORDER BY id DESC LIMIT 300", (conv_id,))

    def set_message_extra(self, mid, extra):
        self.x("UPDATE messages SET extra=? WHERE id=?", (extra, mid))

    # ---------- hafıza ----------
    def memories(self, project_id=None):
        if project_id:
            return self.q("SELECT id,project_id,scope,content,source,hits,created FROM memories "
                          "WHERE project_id=? OR project_id IS NULL ORDER BY scope, created DESC", (project_id,))
        return self.q("SELECT id,project_id,scope,content,source,hits,created FROM memories "
                      "WHERE project_id IS NULL ORDER BY created DESC")

    def user_memories(self, limit=20):
        return self.q("SELECT id,content FROM memories WHERE scope='user' ORDER BY hits DESC, created DESC LIMIT ?", (limit,))

    def lessons(self, limit=12, project_id=None):
        """Deneyimden öğrenilen davranış dersleri: genel (project_id NULL) + bu projeye özel olanlar."""
        return self.q("SELECT id,content,project_id FROM memories WHERE scope='lesson' AND "
                      "(project_id IS NULL OR project_id=?) ORDER BY (project_id IS NULL), hits DESC, created DESC "
                      "LIMIT ?", (project_id or -1, limit))

    # ---------- iş akışları ----------
    def playbooks(self, project_id=None):
        return self.q("SELECT * FROM playbooks WHERE project_id IS NULL OR project_id=? ORDER BY uses DESC, name",
                      (project_id or -1,))

    def playbook(self, pid):
        return self.one("SELECT * FROM playbooks WHERE id=?", (pid,))

    def save_playbook(self, name, steps, keywords="", project_id=None, source="manual"):
        """Aynı adlı (aynı kapsamda) iş akışı varsa günceller, yoksa ekler. Dönüş: (id, yeni_mi)."""
        name, steps = name.strip()[:120], steps.strip()
        now = time.time()
        row = self.one("SELECT id FROM playbooks WHERE lower(name)=lower(?) AND "
                       "((project_id IS NULL AND ? IS NULL) OR project_id=?)", (name, project_id, project_id))
        if row:
            self.x("UPDATE playbooks SET steps=?, keywords=?, updated=? WHERE id=?",
                   (steps, keywords, now, row["id"]))
            return row["id"], False
        return self.x("INSERT INTO playbooks(project_id,name,keywords,steps,source,created,updated) "
                      "VALUES(?,?,?,?,?,?,?)", (project_id, name, keywords, steps, source, now, now)), True

    def update_playbook(self, pid, **f):
        cols = [k for k in ("name", "keywords", "steps") if k in f]
        if cols:
            self.x(f"UPDATE playbooks SET {', '.join(c + '=?' for c in cols)}, updated=? WHERE id=?",
                   (*[str(f[c]) for c in cols], time.time(), pid))

    def delete_playbook(self, pid):
        self.x("DELETE FROM playbooks WHERE id=?", (pid,))

    def use_playbook(self, pid):
        self.x("UPDATE playbooks SET uses=uses+1 WHERE id=?", (pid,))

    def add_memory(self, content, scope="project", project_id=None, embedding=None, source="auto"):
        content = content.strip()
        if not content:
            return None
        pid = project_id if scope in ("project", "lesson") else None
        dup = self.one("SELECT id FROM memories WHERE lower(content)=lower(?) AND "
                       "((project_id IS NULL AND ? IS NULL) OR project_id=?)", (content, pid, pid))
        if dup:
            return None
        blob = np.asarray(embedding, dtype=np.float32).tobytes() if embedding is not None else None
        mid = self.x("INSERT INTO memories(project_id,scope,content,embedding,source,created) VALUES(?,?,?,?,?,?)",
                     (pid, scope, content, blob, source, time.time()))
        self._vec_cache.clear()
        return mid

    def update_memory(self, mid, content):
        self.x("UPDATE memories SET content=?, embedding=NULL WHERE id=?", (content, mid))
        self._vec_cache.clear()

    def delete_memory(self, mid):
        self.x("DELETE FROM memories WHERE id=?", (mid,))
        self._vec_cache.clear()

    def bump_hits(self, ids):
        if ids:
            with self.lock:
                self.conn.executemany("UPDATE memories SET hits=hits+1 WHERE id=?", [(i,) for i in ids])
                self.conn.commit()

    def _vectors(self, project_id):
        key = project_id or 0
        if key in self._vec_cache:
            return self._vec_cache[key]
        rows = self.q("SELECT id, embedding FROM memories WHERE embedding IS NOT NULL AND "
                      "(project_id IS NULL OR project_id=?)", (project_id or -1,))
        if not rows:
            self._vec_cache[key] = (np.zeros(0, dtype=np.int64), None)
            return self._vec_cache[key]
        vecs = [np.frombuffer(r["embedding"], dtype=np.float32) for r in rows]
        dim = max(set(len(v) for v in vecs), key=[len(v) for v in vecs].count)
        keep = [(r["id"], v) for r, v in zip(rows, vecs) if len(v) == dim]
        ids = np.array([k[0] for k in keep], dtype=np.int64)
        mat = np.stack([k[1] for k in keep])
        mat = mat / (np.linalg.norm(mat, axis=1, keepdims=True) + 1e-8)
        self._vec_cache[key] = (ids, mat)
        return self._vec_cache[key]

    def nearest(self, qvec, project_id, k=30):
        ids, mat = self._vectors(project_id)
        if mat is None or len(ids) == 0 or len(qvec) != mat.shape[1]:
            return []
        q = np.asarray(qvec, dtype=np.float32)
        q = q / (np.linalg.norm(q) + 1e-8)
        sims = mat @ q
        order = np.argsort(-sims)[:k]
        return [(int(ids[i]), float(sims[i])) for i in order]

    def search_memories(self, query, project_id, qvec=None, k=8):
        """Hibrit arama: BM25 (FTS5) + kosinüs benzerliği, Reciprocal Rank Fusion ile birleşir."""
        scores, rows_by_id = {}, {}
        fq = fts_query(query)
        if fq:
            try:
                rows = self.q(
                    "SELECT m.id, m.content, m.scope FROM memories_fts f JOIN memories m ON m.id=f.rowid "
                    "WHERE memories_fts MATCH ? AND (m.project_id IS NULL OR m.project_id=?) "
                    "ORDER BY bm25(memories_fts) LIMIT 30", (fq, project_id or -1))
            except sqlite3.OperationalError:
                rows = []
            for rank, r in enumerate(rows):
                scores[r["id"]] = scores.get(r["id"], 0) + 1.0 / (60 + rank)
                rows_by_id[r["id"]] = r
        if qvec is not None:
            for rank, (mid, sim) in enumerate(self.nearest(qvec, project_id)):
                if sim < 0.40:
                    continue
                scores[mid] = scores.get(mid, 0) + 1.0 / (60 + rank) + (sim - 0.4) * 0.02
                if mid not in rows_by_id:
                    r = self.one("SELECT id, content, scope FROM memories WHERE id=?", (mid,))
                    if r:
                        rows_by_id[mid] = r
        best = sorted(scores, key=lambda i: -scores[i])[:k]
        return [rows_by_id[i] for i in best if i in rows_by_id]

    def max_similarity(self, qvec, project_id):
        n = self.nearest(qvec, project_id, k=1)
        return n[0][1] if n else 0.0

    # ---------- kod indeksi ----------
    def clear_chunks(self, pid):
        self.x("DELETE FROM code_chunks WHERE project_id=?", (pid,))

    def add_chunks(self, pid, chunks):
        with self.lock:
            self.conn.executemany(
                "INSERT INTO code_chunks(project_id,path,start_line,end_line,content) VALUES(?,?,?,?,?)",
                [(pid, c[0], c[1], c[2], c[3]) for c in chunks])
            self.conn.commit()

    def search_code(self, pid, terms, k=4):
        if not terms:
            return []
        fq = " OR ".join(f'"{t}"' for t in terms[:12])
        try:
            return self.q(
                "SELECT c.path, c.start_line, c.end_line, c.content FROM code_fts f "
                "JOIN code_chunks c ON c.id=f.rowid WHERE code_fts MATCH ? AND c.project_id=? "
                "ORDER BY bm25(code_fts) LIMIT ?", (fq, pid, k))
        except sqlite3.OperationalError:
            return []
