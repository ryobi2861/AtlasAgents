"""ATLAS yapılandırması. config.json yoksa varsayılanlarla oluşturulur."""
import copy
import json
import os
import sys
import threading
from pathlib import Path

FROZEN = getattr(sys, "frozen", False)
# RES: salt-okunur kaynaklar (arayüz, ikon). DATA: kullanıcı verisi (hafıza, ayarlar).
if FROZEN:  # PyInstaller ile derlenmiş .exe
    RES = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    BASE = Path(sys.executable).resolve().parent
    DATA = Path(os.environ.get("APPDATA", Path.home())) / "ATLAS"
else:
    BASE = Path(__file__).resolve().parent.parent
    RES = BASE
    DATA = BASE / "data"
IMAGES = DATA / "images"
DATA.mkdir(parents=True, exist_ok=True)
IMAGES.mkdir(exist_ok=True)
CONFIG_PATH = DATA / "config.json"
_OLD = BASE / "config.json"  # v1 konumu → taşı
if not CONFIG_PATH.exists() and _OLD.exists():
    try:
        _OLD.replace(CONFIG_PATH)
    except OSError:
        pass
STATIC = RES / "static"
ASSETS = RES / "assets"

# RTX 4060 8GB + 32GB RAM + Ryzen 7 5700X (8C/16T) için ayarlandı.
DEFAULTS = {
    "config_version": 8,
    "user_name": "Onur",
    "agent_name": "ATLAS",
    "custom_instructions": "",
    "skills": {"enabled": True},
    "mcp": {"enabled": True, "servers": []},
    "ollama_url": "http://127.0.0.1:11434",
    "models": {
        # Ana ve kodlama modeli aynı 35B-A3B: hız değil doğruluk/akıl yürütme öncelikli.
        "main": {"name": "huihui_ai/Qwen3.6-abliterated:35b-a3b", "num_ctx": 8192,
                 "temperature": 0.6, "top_p": 0.95, "top_k": 20, "presence_penalty": 1.5, "num_gpu": None},
        # Ağır iş: Qwen3.6 35B-A3B (MoE, adım başına 3B aktif → 8GB VRAM + RAM'de hızlı). Yerel araç çağırma,
        # düşünme ve görsel destekli; ajan tabanlı kodlama için eğitildi (SWE-bench Verified 73.4).
        # Model kartı: temp 1.0 / top_p 0.95 / top_k 20 / presence 1.5 — kod/araç hassasiyeti için sıcaklık 0.7.
        "coder": {"name": "huihui_ai/Qwen3.6-abliterated:35b-a3b", "num_ctx": 8192,
                  "temperature": 0.7, "top_p": 0.95, "top_k": 20, "presence_penalty": 1.5, "num_gpu": None},
        # Aynı ana modeli görsel rolde kullan — model değişimi/indirimi yok.
        "vision": {"name": "huihui_ai/Qwen3.6-abliterated:35b-a3b", "num_ctx": 8192,
                   "temperature": 0.6, "top_p": 0.95, "top_k": 20, "num_gpu": None},
        # İkinci, farklı aileden bağımsız reviewer; 35B'nin hatalarını yakalamak için sırayla çalışır.
        "reviewer": {"name": "orcarouter/Qwen3.8-27B-Uncensored:q4_K_M", "num_ctx": 8192,
                     "temperature": 0.2, "top_p": 0.9, "top_k": 20, "num_gpu": None},
        "embed": {"name": "qwen3-embedding:0.6b", "cpu_only": True},
    },
    "performance": {
        "num_thread": 8,
        "num_batch": 512,
        "keep_alive": "30m",
        "max_output_tokens": 8192,
        "warmup_on_start": True,
        "auto_pull_models": True,   # eksik rol modellerini açılışta arka planda indir
        "retire_old_models": True,  # yenisi indikten sonra ATLAS'ın artık kullanmadığı eski modelleri sil
        "auto_ctx": True,        # num_ctx'i VRAM'e göre ölçerek ayarla (tamamen GPU'ya sığan en büyük bağlam)
        "auto_ctx_min": 12288,   # bundan azına ancak sığıyorsa ölçüm kullanılmaz, ayardaki num_ctx kalır
        "auto_ctx_max": 32768,   # üst sınır (çok büyük bağlam istem işlemeyi yavaşlatır)
        "auto_ctx_margin": 1,    # tavana ulaşılmadıysa 2048'lik güvenlik adımı (tarayıcı/oyun VRAM'i için)
    },
    "agent": {
        "max_steps": 24,
        "auto_extend": True,    # adım sınırında sessiz ara kontrolle devam (ilerleme varsa)
        "hard_max_steps": 150,  # tek turda kesin üst sınır
        "auto_verify": True,    # C/C++ değişikliklerinden sonra bitirmeden önce derleyerek doğrula
        "verify_rounds": 2,
        "playbooks": True,      # eşleşen iş akışlarını bağlama ekle
        "auto_cleanup": True,    # iş %100 bitince geçici betikleri sil (bitmediyse koru)
        "cleanup_max_days": 3,   # yarım kalan işlerin geçici betikleri en geç bu kadar gün sonra silinir
        "backups_keep": 5,       # .atlas/backups: dosya başına tutulan yedek sayısı (14 günden eskiler silinir)
        "loop_guard": True,      # tek cevap/düşünce içinde sonsuz tekrar → akışı kes, tekrarı sil
        "command_guard": True,   # program başlatma/öldürme yalnızca istenirse; başlat-öldür döngüsü engeli
        "task_brief": True,      # işe başlamadan isteği amaç/teslimat/kısıt/bitti kriterine çevir
        "clarify": True,         # kritik belirsizlikte işe başlamadan seçenekli tek soru sor
        "anchor_every": 8,       # uzun turlarda her N adımda asıl görevi hatırlat (0 = kapalı)
        "stall_steps": 4,        # bu kadar adım ilerleme yoksa "dur, düşün, strateji değiştir"
        "auto_continue": 3,     # kesilen uzun cevabı otomatik sürdürme sayısı
        "auto_approve_commands": False,
        "auto_memory": True,
        "auto_summarize": True,
        "sticky_routing": True,
        "web_tools": True,
        "repair_tool_calls": True,  # bozuk araç çağrılarını onar (JSON, ad, parametre, tip, metin içi çağrı)
        "tool_result_chars": 9000,
        "compiler": "auto",
        "cpp_std": "c++20",
    },
    # Tersine mühendislik ve harici programlar
    "re": {
        "ida_path": "",               # boş = otomatik bul (C:\\Program Files\\IDA Professional 9.x\\idat.exe)
        "ida_timeout": 900,           # sn — ilk analiz büyük dosyalarda uzun sürebilir
        "decompile_lines": 250,
        "model": "main",              # inceleme görevleri: main (hızlı, yerel araç desteği) | auto (coder'a da gidebilir)
        "programs": "",               # satır başına: Ad = yol | kullanım notu  (ajan run_command ile kullanır)
    },
    # Ollama sunucusu (ATLAS başlatırken bu ortam değişkenlerini uygular — Ollama paneli)
    "ollama_server": {
        "manage": True,               # Ollama'yı ATLAS başlatsın/yönetsin (kapalıysa çalışan harici Ollama kullanılır)
        "flash_attention": True,      # daha az VRAM, daha hızlı uzun bağlam
        "kv_cache_type": "q8_0",      # f16 | q8_0 | q4_0 — bağlam belleği
        "max_loaded_models": 2,       # 1 LLM (GPU) + embedding (CPU)
        "num_parallel": 1,            # tek kullanıcı: paralel slot = VRAM israfı
        "context_length": 0,          # 0 = model/istek belirler
        "gpu_overhead_mb": 0,         # GPU'da boş bırakılacak bellek (oyun/tarayıcı için)
        "models_dir": "",             # boş = varsayılan (%USERPROFILE%\\.ollama\\models)
        "extra_env": "",              # gelişmiş: satır başına KEY=VALUE
    },
    "desktop": {
        "close_to_tray": True,
        "start_minimized": False,
        "hotkey_toggle": "ctrl+alt+space",
        "hotkey_screenshot": "ctrl+alt+s",
        "notifications": True,
        "theme": "dark",
        "always_on_top": False,
        "devtools": False,
    },
}

_lock = threading.RLock()


def _merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _migrate(user, cfg):
    """Kayıtlı eski varsayılanları yenileriyle değiştir (kullanıcının bilerek değiştirdiği değerlere dokunmaz)."""
    ver = int(user.get("config_version") or 1)
    if ver < 3:
        main = cfg["models"]["main"]
        if main.get("temperature") in (0.6, None):   # eski varsayılan → döngüye daha yatkın
            main["temperature"] = 0.8
        main.setdefault("presence_penalty", 1.5)
    if ver < 4:   # model seti yenilendi: eski varsayılan coder / görsel modeli kullananlar yenisine geçer
        ms = cfg["models"]
        for role in ("coder", "vision"):
            if retired_role(ms.get(role, {}).get("name", "")) == role:
                ms[role] = json.loads(json.dumps(DEFAULTS["models"][role]))
    if ver < 6:   # önceki model turunda 35B tüm rollere sabitlenmişti
        ms = cfg["models"]
        old_fast = "huihui_ai/qwen3.5-abliterated:9b"
        prior_35b = "huihui_ai/Qwen3.6-abliterated:35b-a3b"
        if same_model(ms.get("main", {}).get("name", ""), prior_35b):
            ms["main"] = json.loads(json.dumps(DEFAULTS["models"]["main"]))
        if same_model(ms.get("vision", {}).get("name", ""), prior_35b):
            ms["vision"] = json.loads(json.dumps(DEFAULTS["models"]["vision"]))
        # Eski varsayılan 9B coder değil, ağır kodlama rolü artık Qwen3.6 35B'dir.
        if same_model(ms.get("coder", {}).get("name", ""), old_fast):
            ms["coder"] = json.loads(json.dumps(DEFAULTS["models"]["coder"]))
    if ver < 7:   # 9B varsayılanını emekliye ayır: her düşünme/kod/görsel rolü 35B olsun.
        ms = cfg["models"]
        old_fast = "huihui_ai/qwen3.5-abliterated:9b"
        for role in ("main", "coder", "vision"):
            if same_model(ms.get(role, {}).get("name", ""), old_fast):
                ms[role] = json.loads(json.dumps(DEFAULTS["models"][role]))
        ms.setdefault("reviewer", json.loads(json.dumps(DEFAULTS["models"]["reviewer"])))
    if ver < 8:   # takım modellerine geç; eski 9B/Qwen3 rol atamalarını kaldırıp güncel takım varsayılanlarını kullan.
        ms = cfg["models"]
        for role in ("main", "coder", "vision"):
            name = (ms.get(role) or {}).get("name", "")
            if retired_role(name):
                ms[role] = json.loads(json.dumps(DEFAULTS["models"][role]))
        if "reviewer" not in ms:
            ms["reviewer"] = json.loads(json.dumps(DEFAULTS["models"]["reviewer"]))
    cfg["config_version"] = DEFAULTS["config_version"]


# ATLAS'ın önceki varsayılan model aileleri (tüm etiketleriyle) → yeni rolü; yalnızca yenisi kuruluysa silinir.
RETIRED = {
    "huihui_ai/qwen3-coder-abliterated": "coder",
    "huihui_ai/qwen3-vl-abliterated": "vision",
    "huihui_ai/qwen3.5-abliterated": "main",
}


def _family(name):
    return (name or "").strip().lower().split(":")[0]


def same_model(a, b):
    a, b = (a or "").strip(), (b or "").strip()
    return a == b or a == b + ":latest" or b == a + ":latest"


def retired_role(name):
    return RETIRED.get(_family(name))


def retire_plan(installed: dict, models: dict) -> list:
    """Silinecek eski modeller [(ad, boyut)]. Kural: eski aileden olmalı, hiçbir role atanmamış olmalı ve
    o rolün güncel modeli kurulu olmalı (yenisi inmeden eskisi silinmez, kullanıcı modelsiz kalmaz)."""
    assigned = [m.get("name", "") for m in models.values() if isinstance(m, dict)]
    def have(n):
        return any(same_model(n, i) for i in installed)
    out = []
    for name, size in installed.items():
        role = retired_role(name)
        if not role or any(same_model(name, a) for a in assigned):
            continue
        cur = (models.get(role) or {}).get("name", "")
        if cur and have(cur):
            out.append((name, int(size or 0)))
    return out


def shares_main(role) -> bool:
    """Rol ana modelin aynı ağırlıklarını kullanıyorsa True (ortak bağlam ölçümü/yükleme ayarı)."""
    if role not in ("vision", "coder"):
        return False
    ms = CFG["models"] if "CFG" in globals() else DEFAULTS["models"]
    return same_model(ms.get(role, {}).get("name"), ms.get("main", {}).get("name"))


def load():
    with _lock:
        user = {}
        if CONFIG_PATH.exists():
            try:
                user = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except Exception:
                user = {}
        for legacy in ("host", "port"):  # eski web sunucusu ayarları — artık kullanılmıyor
            user.pop(legacy, None)
        cfg = _merge(DEFAULTS, user)
        _migrate(user, cfg)
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        return cfg


CFG = load()


def save(new_cfg: dict):
    with _lock:
        merged = _merge(CFG, new_cfg)
        CFG.clear()
        CFG.update(merged)
        CONFIG_PATH.write_text(json.dumps(CFG, indent=2, ensure_ascii=False), encoding="utf-8")
        return CFG
