"""Load, scope and persist repository-local AGENTS.md instructions for every project turn."""
import os
import re
import stat
import tempfile
from pathlib import Path

SKIP_DIRS = {
    ".git", ".svn", ".hg", ".atlas", "node_modules", "__pycache__", ".venv", "venv",
    "build", "dist", "out", "target", "bin", "obj", "x64", "x86", "debug", "release",
}
MAX_FILES = 24
MAX_FILE_CHARS = 6000
MAX_TOTAL_CHARS = 16000
CONFIRMED_SECTION = "## ATLAS: käyttäjän vahvistamat työmenetelmät"


def read_agent_files(root) -> str | None:
    """Return a labeled AGENTS.md snapshot; None means root could not be inspected, '' means none exist."""
    if not root:
        return None
    base = Path(root).expanduser()
    try:
        base = base.resolve()
        if not base.is_dir():
            return None
    except OSError:
        return None

    found = []
    walk_errors = []
    walk_error = False
    for dirpath, dirnames, filenames in os.walk(base, onerror=walk_errors.append):
        dirnames[:] = sorted(d for d in dirnames if d.casefold() not in SKIP_DIRS)
        for filename in filenames:
            if filename.casefold() in {"agents.md", "agenst.md"}:
                found.append(Path(dirpath) / filename)
    found.sort(key=lambda p: p.relative_to(base).as_posix().casefold())
    if not found:
        return None if walk_errors else ""

    selected, omitted = found[:MAX_FILES], max(0, len(found) - MAX_FILES)
    sections, total = [], 0
    for index, path in enumerate(selected):
        try:
            resolved = path.resolve()
            resolved.relative_to(base)  # don't follow an AGENTS.md symlink outside the project
            rel = path.relative_to(base).as_posix()
            content = path.read_text(encoding="utf-8", errors="replace").replace("\r\n", "\n").strip()
        except (OSError, ValueError):
            walk_error = True
            continue
        if not content:
            continue
        if len(content) > MAX_FILE_CHARS:
            content = content[:MAX_FILE_CHARS].rstrip() + "\n[… AGENTS.md bu dosya için karakter sınırında kısaltıldı …]"
        heading = f"### {rel}\n"
        remaining = MAX_TOTAL_CHARS - total - len(heading)
        if remaining <= 0:
            omitted += len(selected) - index
            break
        if len(content) > remaining:
            content = content[:remaining].rstrip() + "\n[… AGENTS.md toplam bağlam sınırında kısaltıldı …]"
            omitted += 1
        sections.append(heading + content)
        total += len(heading) + len(content)
    if walk_error or walk_errors:
        # A transient read failure must not erase previously persisted instructions.
        return None
    if omitted:
        sections.append(f"### Not\n{omitted} ek AGENTS.md dosyası sınırlar nedeniyle bu turda yüklenmedi.")
    return "\n\n".join(sections)


def sync_project_rules(store, project) -> str:
    """Refresh the stored snapshot from disk; keep the last known snapshot if the root is unavailable."""
    if not project:
        return ""
    previous = str(project.get("agent_instructions") or "")
    if not project.get("path"):
        return ""
    current = read_agent_files(project.get("path"))
    if current is None:
        return previous
    if current != previous:
        store.update_project(project["id"], agent_instructions=current)
        project["agent_instructions"] = current
    return current


def append_confirmed_instruction(root, instruction, *, confirmed=False) -> bool:
    """Append a reusable, user-confirmed rule without overwriting AGENTS.md; safe and atomic."""
    if confirmed is not True or not root:
        return False
    base = Path(root).expanduser()
    try:
        base = base.resolve()
        if not base.is_dir():
            return False
    except OSError:
        return False

    entry = re.sub(r"\s+", " ", str(instruction or "")).strip().lstrip("-• ")
    if not (35 <= len(entry) <= 500) or "```" in entry:
        return False
    if re.search(r"(?i)(ignore|override|reveal).{0,50}(system|user|prompt|safety)|disable.{0,30}(security|safety)", entry):
        return False

    try:
        roots = [p for p in base.iterdir() if p.is_file() and p.name.casefold() in {"agents.md", "agenst.md"}]
    except OSError:
        return False
    roots.sort(key=lambda p: (p.name.casefold() != "agents.md", p.name.casefold(), p.name))
    target = roots[0] if roots else base / "AGENTS.md"
    if target.is_symlink():
        return False
    try:
        old_mode = stat.S_IMODE(target.stat().st_mode) if target.exists() else None
        original = target.read_text(encoding="utf-8") if target.exists() else ""
    except (OSError, UnicodeError):
        return False
    newline = "\r\n" if "\r\n" in original else "\n"
    text = original.replace("\r\n", "\n")
    marker = re.search(r"(?m)^" + re.escape(CONFIRMED_SECTION) + r"\s*$", text)
    if marker:
        after = marker.end()
        next_heading = re.search(r"(?m)^##\s+", text[after:])
        end = after + next_heading.start() if next_heading else len(text)
        section = text[after:end]
        normalized = " ".join(entry.casefold().split())
        existing = {" ".join(line.strip().lstrip("-• ").casefold().split())
                    for line in section.splitlines() if line.strip() and not line.lstrip().startswith("#")}
        if normalized in existing:
            return False
        updated = text[:end].rstrip("\n") + "\n- " + entry + "\n" + text[end:].lstrip("\n")
    else:
        suffix = "" if not text else ("" if text.endswith("\n") else "\n") + "\n"
        updated = text + suffix + CONFIRMED_SECTION + "\n\n- " + entry + "\n"

    temp_path = None
    try:
        fd, name = tempfile.mkstemp(prefix=".atlas-agents-", suffix=".tmp", dir=base)
        temp_path = Path(name)
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(updated.replace("\n", newline))
            handle.flush()
            os.fsync(handle.fileno())
        if old_mode is not None:
            os.chmod(temp_path, old_mode)
        os.replace(temp_path, target)
        return True
    except OSError:
        if temp_path:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
        return False
