"""Hafif, asenkron Ollama istemcisi (tek kalıcı HTTP bağlantı havuzu)."""
import json

import httpx


class OllamaError(Exception):
    def __init__(self, status, body):
        self.status = status
        self.body = body if isinstance(body, str) else body.decode("utf-8", "replace")
        super().__init__(f"Ollama {status}: {self.body[:400]}")


class Ollama:
    def __init__(self, base: str):
        self.base = base.rstrip("/")
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(None, connect=5.0),
            limits=httpx.Limits(max_keepalive_connections=8, max_connections=16),
        )
        self._caps = {}

    async def close(self):
        await self.client.aclose()

    async def version(self):
        r = await self.client.get(f"{self.base}/api/version", timeout=3)
        r.raise_for_status()
        return r.json().get("version", "?")

    async def tags(self):
        r = await self.client.get(f"{self.base}/api/tags", timeout=10)
        r.raise_for_status()
        return r.json().get("models", [])

    async def ps(self):
        r = await self.client.get(f"{self.base}/api/ps", timeout=5)
        r.raise_for_status()
        return r.json().get("models", [])

    async def show(self, model):
        r = await self.client.post(f"{self.base}/api/show", json={"model": model}, timeout=15)
        if r.status_code != 200:
            raise OllamaError(r.status_code, r.content)
        return r.json()

    async def capabilities(self, model):
        if model in self._caps:
            return self._caps[model]
        caps = set()
        try:
            info = await self.show(model)
            caps = set(info.get("capabilities") or [])
            if not caps:  # eski Ollama sürümleri için tahmin
                tpl = info.get("template", "")
                caps.add("completion")
                if ".Tools" in tpl:
                    caps.add("tools")
                if "think" in tpl.lower():
                    caps.add("thinking")
        except Exception:
            caps = {"completion"}
        self._caps[model] = caps
        return caps

    def forget_caps(self, model=None):
        if model:
            self._caps.pop(model, None)
        else:
            self._caps.clear()

    async def chat_stream(self, payload):
        payload = dict(payload, stream=True)
        async with self.client.stream("POST", f"{self.base}/api/chat", json=payload) as r:
            if r.status_code != 200:
                raise OllamaError(r.status_code, await r.aread())
            async for line in r.aiter_lines():
                if not line.strip():
                    continue
                data = json.loads(line)
                if "error" in data:
                    raise OllamaError(500, data["error"])
                yield data

    async def chat(self, payload):
        payload = dict(payload, stream=False)
        r = await self.client.post(f"{self.base}/api/chat", json=payload)
        if r.status_code != 200:
            raise OllamaError(r.status_code, r.content)
        return r.json()

    async def embed(self, model, inputs, options=None, keep_alive="60m"):
        body = {"model": model, "input": inputs, "keep_alive": keep_alive, "truncate": True}
        if options:
            body["options"] = options
        r = await self.client.post(f"{self.base}/api/embed", json=body, timeout=120)
        if r.status_code != 200:
            raise OllamaError(r.status_code, r.content)
        return r.json().get("embeddings", [])

    async def pull_stream(self, model):
        async with self.client.stream("POST", f"{self.base}/api/pull",
                                      json={"model": model, "stream": True}) as r:
            if r.status_code != 200:
                raise OllamaError(r.status_code, await r.aread())
            async for line in r.aiter_lines():
                if line.strip():
                    yield json.loads(line)

    async def load(self, model, options, keep_alive):
        """Modeli VRAM'e önceden yükler (ilk mesaj gecikmesini yok eder)."""
        body = {"model": model, "keep_alive": keep_alive, "options": options}
        r = await self.client.post(f"{self.base}/api/generate", json=body, timeout=600)
        if r.status_code != 200:
            raise OllamaError(r.status_code, r.content)
        return r.json()

    async def delete(self, model):
        r = await self.client.request("DELETE", f"{self.base}/api/delete", json={"model": model}, timeout=60)
        if r.status_code != 200:
            raise OllamaError(r.status_code, r.content)
        self._caps.pop(model, None)
        return True

    async def unload(self, model):
        await self.client.post(f"{self.base}/api/generate",
                               json={"model": model, "keep_alive": 0}, timeout=30)
