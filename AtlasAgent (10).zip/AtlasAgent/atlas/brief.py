"""Ajanın isteği doğru anlayıp hedeften sapmadan, akıllıca ilerlemesi için KODLA zorlanan yardımcılar.

- Görev anlayışı (brief): işe başlamadan önce kullanıcının mesajı yüklü modelle (düşünmeden, JSON) amaç / teslimatlar /
  kısıtlar / bitti kriteri'ne çevrilir; tur boyunca modelin önünde durur, sohbette saklanır ("devam et" aynı görevi sürdürür).
  Kritik belirsizlik varsa kullanıcıya seçenekli tek soru sorulur.
- Görev çapası: uzun turlarda periyodik olarak asıl istek + bitti kriteri + plan durumu hatırlatılır (sapma olmasın).
- Takılma tespiti: art arda ilerlemesiz adımlar ya da aynı derleme hatasının tekrarı → "dur ve düşün, strateji değiştir".
- Düzeltme algılama: "hayır öyle demedim" (yanlış anlama) ile "hâlâ çalışmıyor" (çözüm tutmadı) ayrı ele alınır.
"""
import json
import re

BRIEF_SCHEMA = {
    "type": "object",
    "properties": {
        "amac": {"type": "string"},
        "teslimatlar": {"type": "array", "items": {"type": "string"}},
        "kisitlar": {"type": "array", "items": {"type": "string"}},
        "bitti_kriteri": {"type": "array", "items": {"type": "string"}},
        "adimlar": {"type": "array", "items": {"type": "string"}, "maxItems": 7},
        "belirsizlik": {"type": "string"},
        "kritik": {"type": "boolean"},
        "soru": {"type": "string"},
        "secenekler": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["amac", "teslimatlar", "kisitlar", "bitti_kriteri", "adimlar", "belirsizlik", "kritik", "soru", "secenekler"],
}

BRIEF_PROMPT = """Sen bir yazılım ajanının "isteği anlama" adımısın. Kullanıcının SON mesajını, önceki görev ve konuşma
bağlamıyla birlikte oku; isteği net bir iş tanımına çevir. Uydurma; kullanıcının istemediği özellik/iş ekleme.
Kullanıcının belirttiği hedef nesne/sembol ve semptomu aynen koru; başka bir arıza türüyle değiştirme. Kullanıcı
"X bulunamıyor" dediyse bunu "input/klavye/fare sorunu" diye yorumlama; yalnızca açıkça söylediği veya araç
kanıtının gösterdiği şeyi yaz. Hata ayıklamada önce kanıt toplama/teşhis gerekir; kanıtlanmamış neden ve düzeltmeyi
kullanıcı isteği gibi sunma. Önceki model/ajan varsayımı kanıt değildir. Kritik anlam belirsizse kritik=true yap ve sor.

Aktif proje: {project}
Önceki görev (varsa): {prev}
Son konuşma (kısa): {recent}

Kullanıcının son mesajı:
\"\"\"{text}\"\"\"

Alanlar (Türkçe, kısa):
- amac: kullanıcının GERÇEKTEN ne istediği, tek cümle. Mesaj önceki görevi düzeltiyor/sürdürüyorsa ikisini birleştir.
- teslimatlar: somut çıktılar (değişecek/oluşacak dosyalar, eklenecek davranış, cevaplanacak soru). En fazla 5.
- kisitlar: kullanıcının açıkça ya da açıkça ima ettiği sınırlar ("yalnızca incele", "mevcut yapıyı bozma",
  "IDA çalıştırma", "C++17", "şu dosyaya dokunma"). Yoksa [].
- bitti_kriteri: işin bittiğini nasıl anlarız ("derleme hatasız", "tıklayınca oyun inputu kapanıyor"). En fazla 4.
- adimlar: görev 3 veya daha fazla somut aşamadan oluşuyorsa sıralı, uygulanabilir 3-7 TODO adımı yaz; basit soru/tek adımlı işte []. Her adım tamamlanınca canlı listede işaretlenecek şekilde küçük ve doğrulanabilir olsun.
- belirsizlik: işi yanlış yapmaya yol açabilecek EN önemli belirsizlik; yoksa "".
- kritik: true YALNIZCA belirsizlik çözülmeden başlamak büyük ihtimalle yanlış/boşa iş olacaksa (iki farklı anlam,
  hangi proje/dosya belli değil). Küçük ayrıntılarda false — ajan makul varsayım yapar.
- soru, secenekler: kritik ise kullanıcıya sorulacak kısa soru ve 2-4 kısa seçenek; değilse "" ve [].
Sadece JSON döndür."""

# düzeltme türleri
MISUNDERSTOOD_RE = re.compile(
    r"(\bhayır\b|\byok(,| ) ?öyle|öyle değil|bunu demedim|onu demedim|\bdemedim\b|istemedim|istediğim bu değil|"
    r"anlamadın|yanlış anladın|yanlış anlamışsın|yanlış (komut|dosya|betik|batch|şey|yer|program|proje)\w*|"
    r"yanlış .{0,30}(uyguladı|çalıştırdı|yaptı|açtı|derledi)|ben .{0,40}dedim|sana .{0,30}dedim|neden .{0,50}"
    r"(yaptın|ekledin|sildin|değiştirdin|çalıştırdın|açtın)|niye .{0,50}(yaptın|ekledin|sildin|değiştirdin))", re.I)
FAILED_RE = re.compile(
    r"(h[aâ]l[aâ] (çalışmıyor|olmuyor|aynı|düzelmedi|bozuk|hata)|yine (aynı|olmadı|olmuyor|çalışmadı|kesti|bozuldu|hata)|"
    r"\bolmadı\b|olmamış|düzelmedi|düzelmemiş|çözülmedi|çözmedi|işe yaramadı|değişen bir şey yok|aynı hata|"
    r"still (not|broken|fails)|doesn'?t work|didn'?t work)", re.I)
QUESTION_ONLY_RE = re.compile(r"^\s*[^\n]{0,90}\?\s*$")

CORRECTION_NOTE = ("(sistem notu) Kullanıcı seni DÜZELTİYOR: önceki yorumun ya da yaptığın, istediği şey değildi. "
                   "Önceki açıklamanı kanıt sayma; yanlış varsayımı açıkça terk et. Kullanıcının son düzeltmesini "
                   "önceliklendir, hedefi ve adlandırdığı nesneleri aynen koru. Yeni açıklama üretmeden önce ilgili "
                   "kaynak/log/araç kanıtını yeniden incele; kanıt yoksa sor. Düzeltme açıkça uygulama istemiyorsa "
                   "hiçbir dosyayı değiştirme. Önce neyi yanlış anladığını tek cümleyle kabul et, sonra doğru görevi yap. "
                   "Bu düzeltmeyi remember ile kalıcı ders olarak kaydet (genel davranışsa scope='lesson', yalnızca "
                   "bu projeye aitse scope='project_lesson').")
FAILED_NOTE = ("(sistem notu) Kullanıcı önceki çözümün İŞE YARAMADIĞINI söylüyor. Aynı yaklaşımı tekrarlama ve "
               "\"düzeltildi\" deme: önce neden işe yaramadığını araçlarla doğrula (ilgili kodu yeniden oku, gerçek "
               "tetiklenme koşulunu/akışı izle, derle), kök nedeni bul, sonra FARKLI bir çözüm uygula. İşe yarayan "
               "yöntemi bulunca remember(scope='project_lesson') ile kaydet.")

ANCHOR_PROMPT = ("(sistem — hatırlatma, kullanıcıya gösterilmez) Asıl görevi unutma.\n"
                 "Kullanıcının isteği: «{req}»\n{brief}{plan}"
                 "Hedeften sapma, gereksiz adım atma, aynı dosyayı/aracı tekrar tekrar çağırma. Bitti kriterleri "
                 "karşılandıysa araç çağırmayı bırak ve kısa nihai özeti yaz; karşılanmadıysa sıradaki adıma geç.")

REFLECT_PROMPT = ("(sistem — dur ve düşün) {why}\nSon denemeler:\n{recent}\n"
                  "Aynı şeyi tekrar deneme. Kendine kısaca sor: 1) Şu ana kadar KESİN bildiğim ne? 2) Neden işe "
                  "yaramadı — kök neden hipotezim ne? 3) Hangi FARKLI strateji? (başka dosya/fonksiyona bak, hatayı "
                  "search_code / web_search ile araştır, daha küçük bir değişiklik yap, varsayımımı bir testle doğrula; "
                  "kritik bilgi eksikse ask_user ile sor). Sonra hemen o stratejinin ilk aracını çağır.")


def _s(x, n=300):
    return re.sub(r"\s+", " ", str(x or "")).strip()[:n]


def _lst(x, k=5, n=200):
    if isinstance(x, str):
        x = [x] if x.strip() else []
    if not isinstance(x, list):
        return []
    return [_s(i, n) for i in x if _s(i, n)][:k]


def parse_brief(raw) -> dict:
    """Model çıktısını güvenle sözlüğe çevir; anlamsızsa {}."""
    if isinstance(raw, dict):
        d = raw
    else:
        txt = str(raw or "").strip()
        m = re.search(r"\{.*\}", txt, re.S)
        if not m:
            return {}
        try:
            d = json.loads(m.group(0))
        except Exception:
            return {}
    if not isinstance(d, dict):
        return {}
    b = {"amac": _s(d.get("amac"), 300),
         "teslimatlar": _lst(d.get("teslimatlar")),
         "kisitlar": _lst(d.get("kisitlar")),
         "bitti_kriteri": _lst(d.get("bitti_kriteri"), 4),
         "adimlar": _lst(d.get("adimlar"), 7),
         "belirsizlik": _s(d.get("belirsizlik"), 300),
         "kritik": bool(d.get("kritik")),
         "soru": _s(d.get("soru"), 300),
         "secenekler": _lst(d.get("secenekler"), 4, 120)}
    if not b["amac"]:
        return {}
    if not (b["soru"] and len(b["secenekler"]) >= 2):
        b["kritik"] = False
    return b


def load(raw) -> dict:
    try:
        d = json.loads(raw) if raw else {}
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def correction_kind(text: str) -> str:
    """'' | 'misunderstood' (yanlış anladın) | 'failed' (çözüm tutmadı)."""
    t = text or ""
    if MISUNDERSTOOD_RE.search(t):
        return "misunderstood"
    if FAILED_RE.search(t):
        return "failed"
    return ""


def needs_brief(text: str, *, is_cont: bool, review: bool, tools_on: bool) -> bool:
    """Yeni görev anlayışı çıkarılmalı mı? Kısa sohbet/soru, 'devam et' ve salt inceleme için gerekmez."""
    t = (text or "").strip()
    if not tools_on or is_cont or review:
        return False
    if len(t) < 20 or len(t.split()) < 4:
        return False
    if QUESTION_ONLY_RE.match(t) and not re.search(r"(yap|ekle|düzelt|yaz|oluştur|değiştir)", t, re.I):
        return False
    return True


def render(b: dict, header=True) -> str:
    if not b or not b.get("amac"):
        return ""
    out = (["<ikincil_atlas_gorev_ozeti>",
            "Bu, ATLAS'ın kullanıcı isteğinden çıkardığı yardımcı özettir; orijinal kullanıcı mesajı tek yetkili kaynaktır. "
            "Özet orijinal mesajla çelişirse özeti yok say, kullanıcı mesajına uy. Özette olmayan yeni iş/izin ekleme."]
           if header else [])
    out.append(f"Amaç: {b['amac']}")
    for key, title in (("teslimatlar", "Teslimatlar"), ("kisitlar", "Kısıtlar (mutlaka uy)"),
                       ("bitti_kriteri", "Bitti sayılır")):
        if b.get(key):
            out.append(f"{title}:\n" + "\n".join(f"- {x}" for x in b[key]))
    if b.get("netlesen"):
        out.append(f"Kullanıcının netleştirmesi: {b['netlesen']}")
    elif b.get("belirsizlik"):
        out.append(f"Belirsizlik (makul varsayım yap ve cevabında belirt): {b['belirsizlik']}")
    if b.get("adimlar"):
        out.append("Görev planı (todo; her aşamada canlı durumunu güncelle):\n" + "\n".join(f"- {x}" for x in b["adimlar"]))
    if header:
        out.append("</ikincil_atlas_gorev_ozeti>")
    return "\n".join(out)


def original_request_message(user_text: str) -> str:
    """Keep the user's complete original wording intact; ATLAS summaries are explicitly secondary."""
    original = str(user_text or "")
    return ("## KULLANICININ ORİJİNAL İSTEĞİ — AYNEN, EKSİKSİZ VE TEK YETKİLİ KAYNAK\n"
            + original
            + "\n## ORİJİNAL İSTEK SONU\n"
            "ATLAS'ın görev özeti, planı, hafızası veya varsayımı bu isteği değiştiremez/genişletemez. "
            "Çelişki varsa bu orijinal isteğe ve kullanıcının en son düzeltmesine uy.\n")


def anchor(user_text: str, b: dict, plan) -> str:
    bl = ""
    if b and b.get("amac"):
        bl = f"Amaç: {b['amac']}\n"
        if b.get("kisitlar"):
            bl += "Kısıtlar: " + "; ".join(b["kisitlar"]) + "\n"
        if b.get("bitti_kriteri"):
            bl += "Bitti sayılır: " + "; ".join(b["bitti_kriteri"]) + "\n"
    pl = ""
    if plan:
        done = sum(1 for p in plan if p.get("status") == "done")
        nxt = next((p.get("step", "") for p in plan if p.get("status") != "done"), "")
        pl = f"Plan: {done}/{len(plan)} tamam" + (f"; sıradaki: {_s(nxt, 160)}" if nxt else "") + "\n"
    return ANCHOR_PROMPT.format(req=_s(user_text, 400), brief=bl, plan=pl)


_NUM = re.compile(r"\d+")


def compile_error_sig(result: str) -> str:
    """Derleme çıktısındaki ilk hata satırının (sayılardan arındırılmış) imzası; başarılıysa ''."""
    if not result or "✔ Derleme başarılı" in result:
        return ""
    for line in result.splitlines():
        low = line.lower()
        if "error" in low or "hata" in low and ":" in low:
            if low.startswith("[cc") or low.startswith("[çıkış"):
                continue
            return _NUM.sub("#", line.strip())[:200]
    return ""


class StallGuard:
    """Art arda ilerlemesiz adımları ve tekrar eden derleme hatalarını izler; gerekiyorsa yansıtma istemi üretir."""

    def __init__(self, limit=4, cap=3):
        self.limit, self.cap = limit, cap
        self.idle, self.used = 0, 0
        self.recent = []          # (ad, kısa argüman, sonuç başı)
        self.last_sig, self.sig_hits = "", 0
        self.pending = ""

    def record(self, made_progress: bool, calls):
        for name, args, result in calls:
            self.recent.append((name, _s(args, 120), _s(result, 160)))
            if name == "compile_cpp":
                sig = compile_error_sig(result)
                if sig and sig == self.last_sig:
                    self.sig_hits += 1
                    if self.sig_hits >= 1 and not self.pending:
                        self.pending = f"Aynı derleme hatası tekrar etti: «{_s(sig, 180)}»."
                else:
                    self.last_sig, self.sig_hits = sig, 0
        self.recent = self.recent[-6:]
        self.idle = 0 if made_progress else self.idle + 1
        if self.idle >= self.limit and not self.pending:
            self.pending = f"Son {self.idle} adımda yeni bilgi ya da ilerleme yok (aynı sonuçlar / hatalar)."

    def take(self):
        """Yansıtma istemi (varsa) — bir kez döner, sayaçları sıfırlar."""
        if not self.pending or self.used >= self.cap:
            self.pending = ""
            return None
        why, self.pending = self.pending, ""
        self.used += 1
        self.idle, self.sig_hits = 0, 0
        rec = "\n".join(f"- {n}({a}) → {r}" for n, a, r in self.recent[-5:]) or "-"
        return REFLECT_PROMPT.format(why=why, recent=rec)
