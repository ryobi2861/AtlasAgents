"""IDA Pro (idat.exe) entegrasyonu: bulma, başsız çalıştırma, veritabanı önbelleği.

Her çağrı: idat.exe -A -S<ida_script.py> -L<log> [-o<db.i64>] <hedef veya db>
 - İlk çağrıda IDA otomatik analiz yapar ve .i64 veritabanını proje/.atlas/ida altına kaydeder (bir kez, uzun sürebilir).
 - Sonraki çağrılar hazır veritabanını açar (saniyeler).
 - Kullanıcı kendi .i64/.idb dosyasını verirse doğrudan o kullanılır (IDA'da açıksa önce kapatılmalı).
"""
import asyncio
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from .config import CFG, DATA, RES

IS_WIN = sys.platform == "win32"
NOWIN = 0x08000000 if IS_WIN else 0
SCRIPT = next((p for p in (Path(__file__).resolve().parent / "ida_script.py", Path(RES) / "atlas" / "ida_script.py")
               if p.exists()), Path(__file__).resolve().parent / "ida_script.py")
DB_EXT = (".i64", ".idb")
_LOCKS: dict = {}


def short_path(p) -> str:
    """Windows 8.3 kısa yol: IDA'nın -S anahtarı boşluklu yolları argüman sanmasın."""
    p = str(p)
    if not IS_WIN or " " not in p:
        return p
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(1024)
        n = ctypes.windll.kernel32.GetShortPathNameW(p, buf, 1024)
        if n and " " not in buf.value:
            return buf.value
    except Exception:
        pass
    return p


def _ver_key(path):
    m = re.search(r"(\d+)\.(\d+)", str(path))
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def candidates():
    pats = []
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
             os.environ.get("LOCALAPPDATA", "") + r"\Programs", r"C:\Tools", r"C:\RE", r"D:\Tools", r"D:\Program Files",
             str(Path.home() / "Desktop"), str(Path.home() / "Tools")]
    for r in roots:
        if r and os.path.isdir(r):
            pats += [os.path.join(r, "IDA*", "idat.exe"), os.path.join(r, "IDA*", "idat64.exe"),
                     os.path.join(r, "*", "IDA*", "idat.exe"), os.path.join(r, "Hex-Rays*", "*", "idat.exe")]
    if not IS_WIN:
        home = str(Path.home())
        pats += [home + "/idapro*/idat", home + "/ida*/idat", "/opt/ida*/idat", home + "/.local/ida*/idat"]
    found = []
    for p in pats:
        found += glob.glob(p)
    w = shutil.which("idat") or shutil.which("idat.exe")
    if w:
        found.append(w)
    uniq = []
    for f in found:
        f = str(Path(f))
        if f not in uniq and os.path.isfile(f):
            uniq.append(f)
    # idat.exe (IDA 9: tek ikili) idat64'ten önce, yüksek sürüm önce
    uniq.sort(key=lambda f: (_ver_key(f), Path(f).name.lower() == "idat.exe"), reverse=True)
    return uniq


_FIND_CACHE = {"t": 0.0, "key": None, "val": None}


def find_idat(cfg=None, fresh=False):
    cfg = cfg or CFG
    key = str((cfg.get("re") or {}).get("ida_path") or "")
    if not fresh and _FIND_CACHE["key"] == key and time.time() - _FIND_CACHE["t"] < 120:
        return _FIND_CACHE["val"]
    val = _find_idat(cfg)
    _FIND_CACHE.update(t=time.time(), key=key, val=val)
    return val


def _find_idat(cfg):
    p = str((cfg.get("re") or {}).get("ida_path") or "").strip().strip('"')
    if p:
        pp = Path(os.path.expandvars(p))
        if pp.is_dir():
            for n in ("idat.exe", "idat64.exe", "idat"):
                if (pp / n).is_file():
                    return str(pp / n)
        elif pp.is_file():
            return str(pp)
    c = candidates()
    return c[0] if c else None


def ida_version_of(exe):
    """Kurulum klasör adından sürüm (ör. 'IDA Professional 9.3' → '9.3')."""
    m = re.search(r"(\d+\.\d+)", str(Path(exe).parent.name)) if exe else None
    return m.group(1) if m else None


def db_dir(root=None):
    d = (Path(root) / ".atlas" / "ida") if root else (DATA / "ida")
    d.mkdir(parents=True, exist_ok=True)
    return d


def db_for(binary: Path, root=None) -> Path:
    if binary.suffix.lower() in DB_EXT:
        return binary
    st = binary.stat()
    h = hashlib.sha1(f"{binary.resolve()}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()[:8]
    safe = re.sub(r"[^\w.\-]", "_", binary.stem)[:40]
    return db_dir(root) / f"{safe}_{h}.i64"


def _script_path():
    """Betiği boşluksuz bir yere kopyala (kısa yol alınamazsa da çalışsın)."""
    dst_dir = DATA / "ida"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "atlas_ida.py"
    try:
        if not dst.exists() or dst.read_bytes() != SCRIPT.read_bytes():
            shutil.copy2(SCRIPT, dst)
    except Exception:
        return short_path(SCRIPT)
    return short_path(dst)


def _tail(path, n=40):
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-n:])
    except Exception:
        return ""


def _kill(proc):
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, creationflags=NOWIN, timeout=10)
        else:
            proc.kill()
    except Exception:
        pass


async def run(binary, action, params=None, root=None, timeout=None, on_note=None):
    """IDA'da bir eylem çalıştırır → dict (betiğin JSON sonucu + meta). Hata durumunda RuntimeError."""
    exe = find_idat()
    if not exe:
        raise RuntimeError("IDA Pro bulunamadı. Ayarlar → Tersine mühendislik → IDA yolu alanına idat.exe'nin yolunu gir "
                           "(ör. C:\\Program Files\\IDA Professional 9.3\\idat.exe).")
    binary = Path(binary)
    if not binary.is_file():
        raise RuntimeError(f"dosya bulunamadı: {binary}")
    db = db_for(binary, root)
    new_db = not db.exists()
    timeout = int(timeout or (CFG.get("re") or {}).get("ida_timeout", 900))
    lock = _LOCKS.setdefault(str(db).lower(), asyncio.Lock())
    async with lock:
        work = Path(tempfile.mkdtemp(prefix="atlas_ida_", dir=str(DATA / "ida") if (DATA / "ida").exists() else None))
        out, jobf, logf = work / "out.json", work / "job.json", db.parent / (db.stem + ".log")
        job = {"action": action, "out": str(out), **(params or {})}
        jobf.write_text(json.dumps(job, ensure_ascii=False), encoding="utf-8")
        cmd = [exe, "-A", "-S" + _script_path(), "-L" + str(logf)]
        if new_db:
            cmd.append("-o" + str(db))
        cmd.append(str(binary) if new_db else str(db))
        env = dict(os.environ, ATLAS_IDA_JOB=str(jobf), TVHEADLESS="1", PYTHONIOENCODING="utf-8")
        if new_db and on_note:
            on_note(f"IDA ilk analizi yapıyor ({binary.name}, {binary.stat().st_size // 1024} KB) — büyük dosyalarda "
                    f"birkaç dakika sürebilir; sonraki sorgular hazır veritabanını kullanır.")
        t0 = time.time()
        try:
            return await _run_job(proc_args=(cmd, db, env), out=out, logf=logf, binary=binary, db=db, new_db=new_db,
                                  timeout=timeout, exe=exe, t0=t0)
        finally:
            shutil.rmtree(work, ignore_errors=True)   # başarısız/iptal edilen çalıştırmalar da iz bırakmasın


async def _run_job(proc_args, out, logf, binary, db, new_db, timeout, exe, t0):
    cmd, _, env = proc_args
    proc = await asyncio.create_subprocess_exec(*cmd, cwd=str(db.parent), env=env, stdin=asyncio.subprocess.DEVNULL,
                                                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
                                                creationflags=NOWIN)
    try:
        await asyncio.wait_for(proc.wait(), timeout)
    except asyncio.TimeoutError:
        _kill(proc)
        raise RuntimeError(f"IDA {timeout} sn içinde bitmedi ve durduruldu. İlk çalıştırmaysa IDA'yı bir kez normal "
                           f"açıp lisans/EULA penceresini onayla. Log: {logf}\n{_tail(logf, 15)}")
    except asyncio.CancelledError:
        _kill(proc)
        raise
    dt = round(time.time() - t0, 1)
    if not out.exists():
        tail = _tail(logf, 30)
        hint = ""
        low = tail.lower()
        if "python" in low and ("not" in low or "fail" in low or "error" in low):
            hint = " IDAPython yüklenemedi: IDA klasöründeki idapyswitch.exe ile Python sürümünü seç."
        elif "license" in low or "lisans" in low:
            hint = " Lisans sorunu: IDA'yı bir kez normal açıp lisansı doğrula."
        elif "already" in low or "locked" in low or "in use" in low:
            hint = " Veritabanı başka bir IDA penceresinde açık olabilir; kapatıp tekrar dene."
        if new_db and db.exists() and db.stat().st_size < 1024:
            db.unlink(missing_ok=True)
        raise RuntimeError(f"IDA sonuç üretmedi (çıkış kodu {proc.returncode}, {dt} sn).{hint}\nLog ({logf}):\n{tail}")
    res = json.loads(out.read_text(encoding="utf-8"))
    res.update(db=str(db), new_db=new_db, seconds=dt, idat=exe)
    if not res.get("ok"):
        raise RuntimeError(f"IDA betiği hata verdi: {res.get('error')}\n{(res.get('trace') or '')[-1200:]}")
    return res


def check(exe=None):
    """Ayarlar ekranındaki 'Test et' için: idat var mı, betik yerinde mi, sürüm."""
    exe = exe or find_idat(fresh=True)
    if not exe:
        return {"ok": False, "error": "idat.exe bulunamadı", "candidates": candidates()}
    return {"ok": os.path.isfile(exe), "path": exe, "version": ida_version_of(exe), "script": str(SCRIPT),
            "script_ok": SCRIPT.exists(), "candidates": candidates()}


__all__ = ["find_idat", "run", "check", "candidates", "db_for", "short_path", "RES"]


# ------------------------------------------------------------------ diğer RE programlarını bul
KNOWN_TOOLS = [
    # (ad, glob kalıpları (kök altında), PATH adı, ajan için kullanım notu)
    ("Ghidra (başsız)", ["ghidra*/support/analyzeHeadless.bat", "*/ghidra*/support/analyzeHeadless.bat"], None,
     "analyzeHeadless.bat <proje_klasörü> <proje_adı> -import <exe> -postScript <script> -deleteProject"),
    ("x64dbg", ["x64dbg*/release/x64/x64dbg.exe", "x64dbg*/x64/x64dbg.exe", "*/x64dbg*/release/x64/x64dbg.exe"], None,
     "GUI hata ayıklayıcı: x64dbg.exe <exe> ile hedefi açar (etkileşimli, çıktı vermez)"),
    ("Detect It Easy (diec)", ["die*/diec.exe", "*/die*/diec.exe", "Detect It Easy*/diec.exe"], "diec",
     "diec.exe -j <exe>  → derleyici/packer/protector tespiti (JSON)"),
    ("CDB (WinDbg konsol)", ["Windows Kits/10/Debuggers/x64/cdb.exe"], "cdb",
     "cdb.exe -c \"lm;g;k;q\" <exe>  → konsol hata ayıklayıcı; crash dump: cdb -z dump.dmp -c \"!analyze -v;q\""),
    ("radare2", ["radare2*/bin/radare2.exe", "*/radare2*/bin/radare2.exe"], "radare2",
     "radare2 -q -c \"aaa;afl;pdf @ main\" <exe>"),
    ("dnSpyEx (.NET)", ["dnSpy*/dnSpy.exe", "*/dnSpy*/dnSpy.exe"], None, ".NET derleyici/hata ayıklayıcı (GUI)"),
    ("ILSpy CLI (.NET)", [], "ilspycmd", "ilspycmd <dll> -o <klasör>  → .NET derlemesini C#'a çevirir"),
    ("PE-bear", ["PE-bear*/PE-bear.exe", "*/PE-bear*/PE-bear.exe"], None, "PE başlık inceleme (GUI)"),
    ("Binary Ninja", ["Vector35/BinaryNinja/binaryninja.exe"], None, "GUI; başsız kullanım için Python API gerekir"),
    ("dumpbin (MSVC)", [], "dumpbin", "dumpbin /headers /imports /exports <exe>"),
    ("objdump", [], "objdump", "objdump -d -M intel <dosya>"),
    ("UPX", ["upx*/upx.exe", "*/upx*/upx.exe"], "upx", "upx -d <exe> -o <çıktı>  → UPX paketini aç (kopya üzerinde çalış)"),
]


def detect_tools():
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
             os.environ.get("LOCALAPPDATA", "") + r"\Programs", r"C:\Tools", r"C:\RE", r"D:\Tools", "C:\\",
             str(Path.home() / "Desktop"), str(Path.home() / "Downloads"), str(Path.home() / "Tools")]
    roots = [r for r in roots if r and os.path.isdir(r)]
    found = []
    ida = find_idat()
    if ida:
        found.append({"name": f"IDA Pro {ida_version_of(ida) or ''}".strip(), "path": ida,
                      "note": "ATLAS'ın `ida` aracı otomatik kullanır", "builtin": True})
    for name, pats, onpath, note in KNOWN_TOOLS:
        hit = None
        for r in roots:
            for p in pats:
                g = glob.glob(os.path.join(r, p))
                if g:
                    hit = sorted(g, key=_ver_key, reverse=True)[0]
                    break
            if hit:
                break
        if not hit and onpath:
            hit = shutil.which(onpath)
        if hit:
            found.append({"name": name, "path": str(Path(hit)), "note": note})
    return found


# ------------------------------------------------------------------ kayıtlı IDAPython betikleri
# <proje>/.atlas/ida/scripts/<ad>.py — ajan save_as ile kaydeder, script_name ile yeniden çalıştırır.
# Her betik, IDA arayüzünde File > Script file ile de çalışabilsin diye küçük bir uyumluluk katmanı içerir.
# Çalıştırılan tüm betikler ayrıca scripts/_gecmis/ altına (son 30) kaydedilir.
SCRIPT_MARK = "# ---- betik ----"
SCRIPT_END = "# ---- ATLAS: IDA arayüzünde çalıştırılınca sonucu yazdır ----"
HISTORY_KEEP = 30
PRELUDE = '''# ---- ATLAS uyumluluk katmanı (IDA'da File > Script file ile çalıştırırken yardımcıları tanımlar) ----
try:
    resolve
except NameError:
    import idaapi, idc, idautils, ida_funcs, ida_name, ida_bytes, ida_segment, ida_nalt, ida_xref, ida_lines
    def hx(ea):
        return "0x%X" % ea
    def resolve(t):
        if isinstance(t, int):
            return t
        t = str(t).strip()
        if t.lower().startswith("0x"):
            return int(t, 16)
        if t.lower().startswith("sub_"):
            return int(t[4:], 16)
        return idc.get_name_ea_simple(t)
    def demangled(ea):
        n = idc.get_func_name(ea) or ""
        return idc.demangle_name(n, idc.get_inf_attr(idc.INF_SHORT_DN)) or n
    def decompile(t, n=300):
        import ida_hexrays
        return "\\n".join(str(ida_hexrays.decompile(resolve(t))).splitlines()[:n])
    result = None
    ARGS = {}
'''


def scripts_dir(root=None, create=True):
    d = db_dir(root) / "scripts" if create else ((Path(root) / ".atlas" / "ida" / "scripts") if root else DATA / "ida" / "scripts")
    if create:
        d.mkdir(parents=True, exist_ok=True)
    return d


def safe_script_name(name: str) -> str:
    n = re.sub(r"\.py$", "", str(name or "").strip(), flags=re.I)
    n = re.sub(r"[^\w\-]+", "_", n, flags=re.UNICODE).strip("_.")[:60]
    return n or "betik"


def script_body(text: str) -> str:
    """Kayıtlı dosyadan yalnızca betik gövdesi (uyumluluk katmanı ve kapanış hariç)."""
    if SCRIPT_MARK in text:
        text = text.split(SCRIPT_MARK, 1)[1]
    if SCRIPT_END in text:
        text = text.split(SCRIPT_END, 1)[0]
    return text.strip("\n") + "\n"


def _meta(text: str):
    desc, target = "", ""
    for ln in text.splitlines()[:12]:
        if ln.startswith("# açıklama:"):
            desc = ln.split(":", 1)[1].strip()
        elif ln.startswith("# hedef:"):
            target = ln.split(":", 1)[1].strip()
    if not desc:   # kullanıcının kendi betiği: ilk yorum satırı / docstring
        m = re.search(r'^\s*(?:#\s*(.+)|"""\s*(.+?)\s*(?:"""|$))', text, re.M)
        if m:
            desc = (m.group(1) or m.group(2) or "").strip()
    return desc[:160], target


def save_script(root, name, code, description="", target="", folder=None) -> Path:
    d = folder or scripts_dir(root)
    d.mkdir(parents=True, exist_ok=True)
    name = safe_script_name(name)
    body = script_body(code)
    head = (f"# ATLAS IDA betiği: {name}\n# açıklama: {' '.join(str(description or '').split())[:300]}\n"
            f"# hedef: {target}\n# kaydedildi: {time.strftime('%Y-%m-%d %H:%M')}\n"
            f"# Kullanım: ATLAS'ta ida action=script script_name={name} · IDA'da File > Script file\n\n")
    text = (head + PRELUDE + SCRIPT_MARK + "\n" + body + "\n" + SCRIPT_END + "\n"
            "if __name__ != \"__atlas__\" and result is not None:\n    print(result)\n")
    p = d / f"{name}.py"
    p.write_text(text, encoding="utf-8")
    return p


def list_scripts(root=None):
    d = scripts_dir(root, create=False)
    if not d.is_dir():
        return []
    out = []
    for p in sorted(d.glob("*.py"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            desc, target = _meta(p.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
        out.append({"name": p.stem, "description": desc, "target": target, "path": str(p),
                    "size": p.stat().st_size, "modified": p.stat().st_mtime})
    return out


def load_script(root, name) -> str:
    p = scripts_dir(root, create=False) / f"{safe_script_name(name)}.py"
    if not p.is_file():
        raise FileNotFoundError(name)
    return p.read_text(encoding="utf-8", errors="replace")


def log_history(root, code, ok, target=""):
    """Çalıştırılan geçici betiği _gecmis/ altına yaz (en fazla 30). İş %100 bitince cleanup bunu siler; iş yarım
    kaldıysa kullanıcı neyin çalıştığını görebilsin diye kalır."""
    try:
        d = scripts_dir(root) / "_gecmis"
        name = time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}" + ("" if ok else "_HATA")
        base, k = name, 1
        while (d / f"{name}.py").exists():   # aynı milisaniyede ikinci çalıştırma üzerine yazmasın
            k += 1
            name = f"{base}_{k}"
        sp = save_script(root, name, code, "otomatik geçmiş kaydı" + ("" if ok else " (hata verdi)"), target, folder=d)
        old = sorted(d.glob("*.py"), key=lambda x: x.stat().st_mtime, reverse=True)[HISTORY_KEEP:]
        for p in old:
            p.unlink(missing_ok=True)
        return sp
    except OSError:
        return None
