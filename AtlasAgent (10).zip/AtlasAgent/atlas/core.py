"""ATLAS çekirdeği — ağ sunucusu YOK.

Arayüz (pywebview penceresi) bu modüle süreç içi köprüyle bağlanır:
  JS  →  window.pywebview.api.request(method, path, body)  →  Core.request()  →  işleyici fonksiyon
  JS  →  window.pywebview.api.stream(sid, path, body)      →  olaylar pencereye doğrudan itilir
Hiçbir port dinlenmez, tarayıcıdan erişilemez. Tüm asenkron iş tek bir arka plan olay döngüsünde çalışır.
"""
import asyncio
import base64
import inspect
import json
import logging
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from . import config
from .agent import Agent
from .config import CFG, DATA, IMAGES
from .indexer import index_project, iter_files
from .ollama import Ollama
from .store import Store

log = logging.getLogger("atlas")
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
OLLAMA_MIN = (0, 30, 0)  # Qwen3.6/Qwen3.8 hibrit mimarileri için alt sürüm eşiği

store = Store(DATA / "atlas.db")
ollama = Ollama(CFG["ollama_url"])
agent = Agent(store, ollama)
TURNS: dict = {}     # turn_id → asyncio.Task
EVENTS: list = []    # arayüze bir kez gösterilecek bildirimler (/api/status ile alınır)
MODELS_BG = {"model": "", "pct": 0, "running": False}
PENDING: dict = {}   # onay / soru id → Future
DESKTOP = None       # desktop.py tarafından atanır (pencere, tepsi, diyaloglar)


def set_desktop(d):
    global DESKTOP
    DESKTOP = d


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ------------------------------------------------------------------ süreç içi yönlendirici
ROUTES = []  # (method, regex, handler, stream)


def route(method, pattern, stream=False):
    rx = re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn, stream))
        return fn
    return deco


def _convert(fn, raw):
    """Yol/sorgu parametrelerini işleyicinin tip ipuçlarına göre çevir."""
    sig = inspect.signature(fn)
    out = {}
    for name, val in raw.items():
        if name not in sig.parameters:
            continue
        ann = sig.parameters[name].annotation
        if ann is int or "int" in str(ann):
            try:
                val = int(val)
            except (TypeError, ValueError):
                raise ApiError(400, f"Geçersiz parametre: {name}")
        out[name] = val
    return out


def _resolve(method, path, body):
    parts = urlsplit(path)
    query = {k: v[0] for k, v in parse_qs(parts.query).items()}
    for m, rx, fn, stream in ROUTES:
        if m != method:
            continue
        hit = rx.match(parts.path)
        if not hit:
            continue
        kwargs = _convert(fn, {**query, **hit.groupdict()})
        if "body" in inspect.signature(fn).parameters:
            kwargs["body"] = body if isinstance(body, dict) else {}
        return fn, kwargs, stream
    raise ApiError(404, f"Bilinmeyen istek: {method} {parts.path}")


class Core:
    """Olay döngüsünü kendi iş parçacığında çalıştırır; köprüden gelen çağrıları oraya aktarır."""

    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self.streams = {}  # sid → Task
        self._thread = threading.Thread(target=self._run, daemon=True, name="atlas-core")

    def start(self):
        self._thread.start()
        self.ready.wait(10)
        return self

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.create_task(warmup())
        self.ready.set()
        self.loop.run_forever()

    def stop(self):
        async def _close():
            for t in list(TURNS.values()):
                t.cancel()
            if TURNS:
                await asyncio.sleep(0.5)  # iptal edilen turlar o ana kadarki cevabı kaydetsin
            await agent.mcp.close()
            await ollama.close()
        try:
            asyncio.run_coroutine_threadsafe(_close(), self.loop).result(3)
        except Exception:
            pass
        self.loop.call_soon_threadsafe(self.loop.stop)

    # ---- tek seferlik istek (köprü iş parçacığından çağrılır, sonucu bekler)
    def request(self, method, path, body=None, timeout=None):
        async def run():
            fn, kwargs, stream = _resolve(method.upper(), path, body)
            if stream:
                raise ApiError(400, "Bu istek akış olarak çağrılmalı")
            res = fn(**kwargs)
            if inspect.isawaitable(res):
                res = await res
            return res
        fut = asyncio.run_coroutine_threadsafe(run(), self.loop)
        try:
            return {"ok": True, "data": fut.result(timeout)}
        except ApiError as e:
            return {"ok": False, "status": e.status, "error": e.message}
        except Exception as e:
            log.error("İstek hatası %s %s: %s\n%s", method, path, e, traceback.format_exc())
            return {"ok": False, "status": 500, "error": str(e)}

    # ---- akış: olaylar push(sid, olay) ile pencereye gönderilir
    def stream(self, sid, path, body, push):
        async def run():
            try:
                fn, kwargs, stream = _resolve("POST", path, body)
                if not stream:
                    raise ApiError(400, "Akış olmayan istek")
                async for ev in fn(**kwargs):
                    push(sid, ev)
            except asyncio.CancelledError:
                push(sid, {"type": "stopped"})
            except ApiError as e:
                push(sid, {"type": "error", "text": e.message})
            except Exception as e:
                log.error("Akış hatası %s: %s\n%s", path, e, traceback.format_exc())
                push(sid, {"type": "error", "text": str(e)})
            finally:
                self.streams.pop(sid, None)
                push(sid, None)  # akış bitti

        def start():
            self.streams[sid] = self.loop.create_task(run())
        self.loop.call_soon_threadsafe(start)

    def cancel(self, sid):
        t = self.streams.get(sid)
        if t:
            self.loop.call_soon_threadsafe(t.cancel)


def _fit_roles():
    """Ölçülmesi gereken roller. nvidia-smi yoksa yalnızca ana model (büyük modeli boşuna yükleyip durmasın)."""
    from .ctxfit import ROLES, gpu_info
    need = [r for r in ROLES if agent.fit.needs(r)]
    if need and gpu_info() is None:
        need = [r for r in need if r == "main"]
    return need


async def _fit_bg(reason=""):
    """Gerekiyorsa arka planda bağlam ölçümü. Ajan çalışıyorsa ya da ölçüm sürüyorsa dokunmaz."""
    if agent.fit.lock.locked() or agent.status["busy"]:
        return False
    need = await asyncio.to_thread(_fit_roles)
    if not need:
        return False
    log.info("Bağlam ölçümü başlıyor (%s): %s", reason or "gerekli", ", ".join(need))
    agent.status["bg"] = "Bağlam VRAM'e göre ayarlanıyor…"
    try:
        await agent.fit.calibrate_all(need, warm="main")
    finally:
        agent.status["bg"] = ""
    return True


def _gb(n):
    return f"{n / 1e9:.1f} GB"


async def _installed_map():
    return {t["name"]: int(t.get("size") or 0) for t in await ollama.tags()}


async def retire_old(reason="", force=False):
    """ATLAS'ın artık kullanmadığı eski varsayılan modelleri sil (yalnızca yenisi kuruluysa ve role atanmamışsa)."""
    if not force and not CFG["performance"].get("retire_old_models", True):
        return []
    try:
        plan = config.retire_plan(await _installed_map(), CFG["models"])
    except Exception as e:
        log.warning("Eski model kontrolü atlandı: %s", e)
        return []
    done = []
    for name, size in plan:
        try:
            await ollama.unload(name)
        except Exception:
            pass
        try:
            await ollama.delete(name)
            ollama.forget_caps(name)
            done.append((name, size))
            log.info("Eski model silindi (%s): %s (%s)", reason or "temizlik", name, _gb(size))
        except Exception as e:
            log.warning("Eski model silinemedi: %s — %s", name, e)
    if done:
        EVENTS.append(f"🧹 Artık kullanılmayan eski modeller silindi: {', '.join(n for n, _ in done)} "
                      f"({_gb(sum(z for _, z in done))} boşaldı)")
    return done


async def ensure_models():
    """Eksik rol modellerini arka planda indir (yarıda kalan indirme Ollama'da kaldığı yerden sürer), sonra eskileri sil."""
    if MODELS_BG["running"]:
        return
    MODELS_BG["running"] = True
    try:
        if CFG["performance"].get("auto_pull_models", True):
            have = await _installed_map()
            want = []
            for role in ("main", "coder", "vision", "reviewer", "embed"):
                n = CFG["models"].get(role, {}).get("name", "")
                if n and not any(config.same_model(n, h) for h in have) and n not in want:
                    want.append(n)
            for name in want:
                log.info("Eksik model indiriliyor: %s", name)
                MODELS_BG.update(model=name, pct=0)
                try:
                    async for ev in ollama.pull_stream(name):
                        if ev.get("error"):
                            raise RuntimeError(ev["error"])
                        if ev.get("total"):
                            MODELS_BG["pct"] = int(ev.get("completed", 0) * 100 / ev["total"])
                    ollama.forget_caps(name)
                    EVENTS.append(f"✔ Yeni model indirildi: {name}")
                    log.info("Model indirildi: %s", name)
                except Exception as e:
                    log.warning("Model indirilemedi: %s — %s", name, e)
                    EVENTS.append(f"⚠ {name} indirilemedi: {e} (Ayarlar → Modeller'den tekrar deneyebilirsin)")
            MODELS_BG.update(model="", pct=0)
            if want:
                try:
                    await _fit_bg("yeni model")
                except Exception as e:
                    log.warning("Bağlam ölçümü atlandı: %s", e)
        await retire_old("açılış")
    finally:
        MODELS_BG.update(running=False, model="", pct=0)


async def warmup():
    try:   # model bakımı ön yüklemeden bağımsız: Ollama hazır olunca arka planda
        await ollama.version()
        asyncio.get_running_loop().create_task(ensure_models())
    except Exception as e:
        log.info("Model bakımı ertelendi (Ollama yok): %s", e)
    if not CFG["performance"].get("warmup_on_start"):
        return
    try:
        await ollama.version()
        installed = {m["name"] for m in await ollama.tags()}
        name = CFG["models"]["main"]["name"]
        try:   # bir kerelik ölçüm ana modeli zaten doğru bağlamla yüklü bırakır
            if await _fit_bg("açılış") and not agent.fit.needs("main") and agent.fit.result("main"):
                log.info("Ana model hazır (ölçümle yüklendi).")
                return
        except Exception as e:
            log.warning("Bağlam ölçümü atlandı: %s", e)
        if name in installed or name + ":latest" in installed:
            log.info("Ana model VRAM'e ön yükleniyor: %s", name)
            await ollama.load(name, agent.options("main"), CFG["performance"]["keep_alive"])
            log.info("Ana model hazır.")
    except Exception as e:
        log.warning("Ön yükleme atlandı: %s", e)


# ------------------------------------------------------------------ görseller
@route("POST", "/api/upload")
async def upload(body):
    m = re.match(r"data:image/(png|jpeg|jpg|webp|gif);base64,(.+)", body.get("data", ""), re.S)
    if not m:
        raise ApiError(400, "Geçersiz görsel")
    ext = "jpg" if m.group(1) == "jpeg" else m.group(1)
    raw = base64.b64decode(m.group(2))
    if len(raw) > 25 * 1024 * 1024:
        raise ApiError(400, "Görsel çok büyük")
    name = f"{uuid.uuid4().hex}.{ext}"
    (IMAGES / name).write_bytes(raw)
    return {"name": name}


# ------------------------------------------------------------------ durum / kurulum
def _gpu_info():
    if not shutil.which("nvidia-smi"):
        return None
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.used,memory.total,utilization.gpu,temperature.gpu",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=4,
                           creationflags=NO_WINDOW)
        n, used, total, util, temp = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")]
        return {"name": n, "mem_used": int(used), "mem_total": int(total), "util": int(util), "temp": int(temp)}
    except Exception:
        return None


def _ver_tuple(v):
    nums = re.findall(r"\d+", (v or "").split("-")[0])
    return tuple(int(x) for x in (nums + ["0", "0", "0"])[:3])


@route("GET", "/api/desktop/info")
async def desktop_info():
    """Arayüzün ilk açılışta ihtiyaç duyduğu yerel bilgiler."""
    return {"desktop": DESKTOP is not None, "platform": sys.platform, "images": IMAGES.resolve().as_uri() + "/"}


@route("GET", "/api/status")
async def status():
    out = {"ollama": False, "version": None, "models": {}, "loaded": [], "gpu": None,
           "busy": agent.status["busy"], "bg": agent.status["bg"], "embed_ok": agent.embed_ok,
           "desktop": DESKTOP is not None, "pulling": dict(MODELS_BG) if MODELS_BG["model"] else None,
           "events": [EVENTS.pop(0) for _ in range(len(EVENTS))]}
    from . import build
    from .version import APP_VERSION
    out["app_version"] = APP_VERSION
    out["build"] = build.RUNNING
    out["update"] = await asyncio.to_thread(build.update_available)
    out["gpu"] = await asyncio.to_thread(_gpu_info)
    try:
        out["version"] = await ollama.version()
        out["ollama"] = True
        out["ollama_min"] = ".".join(map(str, OLLAMA_MIN))
        out["ollama_outdated"] = _ver_tuple(out["version"]) < OLLAMA_MIN
        tags = await ollama.tags()
        names = {t["name"]: t for t in tags}
        for role, m in CFG["models"].items():
            n = m["name"]
            t = names.get(n) or names.get(n + ":latest")
            out["models"][role] = {"name": n, "installed": bool(t), "size": t["size"] if t else 0}
        for p in await ollama.ps():
            out["loaded"].append({"name": p["name"], "size": p.get("size", 0), "vram": p.get("size_vram", 0),
                                  "expires": p.get("expires_at"), "ctx": p.get("context_length")})
    except Exception as e:
        out["error"] = str(e)
        for role, m in CFG["models"].items():
            out["models"][role] = {"name": m["name"], "installed": False, "size": 0}
    return out


@route("POST", "/api/pull/{role}", stream=True)
async def pull(role: str):
    roles = list(CFG["models"]) if role == "all" else [role]
    for r in roles:
        if r not in CFG["models"]:
            raise ApiError(404, "Bilinmeyen rol")
    for r in roles:
        name = CFG["models"][r]["name"]
        yield {"role": r, "model": name, "status": "başlıyor"}
        try:
            async for ev in ollama.pull_stream(name):
                ev.update(role=r, model=name)
                yield ev
            ollama.forget_caps(name)
            yield {"role": r, "model": name, "status": "success", "done": True}
        except Exception as e:
            yield {"role": r, "model": name, "error": str(e)}
    gone = await retire_old("indirme sonrası")
    if gone:
        yield {"status": f"eski modeller silindi: {', '.join(n for n, _ in gone)}", "retired": [n for n, _ in gone]}


@route("POST", "/api/warmup/{role}")
async def warm(role: str):
    if role not in ("main", "coder", "vision", "reviewer"):
        raise ApiError(404, "Bilinmeyen rol")
    t0 = time.time()
    await ollama.load(CFG["models"][role]["name"], agent.options(role), CFG["performance"]["keep_alive"])
    return {"ok": True, "seconds": round(time.time() - t0, 1)}


@route("POST", "/api/unload")
async def unload_all():
    for p in await ollama.ps():
        await ollama.unload(p["name"])
    return {"ok": True}


@route("GET", "/api/config")
async def get_config():
    return CFG


@route("POST", "/api/config")
async def set_config(body):
    from .mcp_client import validate_server_config
    try:
        validate_server_config((body.get("mcp") or {}).get("servers", []))
    except ValueError as e:
        raise ApiError(400, str(e))
    old_names = {r: m["name"] for r, m in CFG["models"].items()}
    cfg = config.save(body)
    for r, m in cfg["models"].items():
        if old_names.get(r) != m["name"]:
            ollama.forget_caps()
    asyncio.get_running_loop().create_task(_fit_bg("ayar değişti"))   # model/bağlam ayarı değiştiyse yeniden ölç
    return cfg


@route("POST", "/api/mcp/test")
async def mcp_test(body):
    from .mcp_client import MCPError, validate_server_config
    try:
        server = (body or {}).get("server")
        tools = await agent.mcp.test_server(server)
        return {"ok": True, "tools": tools}
    except Exception as e:
        raise ApiError(400, f"MCP test failed: {type(e).__name__}: {e}")


@route("GET", "/api/ctxfit")
async def ctxfit_get():
    from .ctxfit import gpu_info
    out = agent.fit.summary()
    out["gpu"] = await asyncio.to_thread(gpu_info)
    return out


@route("POST", "/api/ctxfit/run", stream=True)
async def ctxfit_run(body):
    """Bağlamı VRAM'e göre şimdi ölç (seçili roller ya da hepsi); ilerleme olayları akış olarak gelir."""
    from .ctxfit import ROLES
    roles = [r for r in (body.get("roles") or ROLES) if r in ROLES]
    if agent.status["busy"]:
        raise ApiError(409, "Ajan şu an çalışıyor; yanıt bitince tekrar dene.")
    if agent.fit.lock.locked():
        raise ApiError(409, "Ölçüm zaten sürüyor.")
    q = asyncio.Queue()
    agent.status["bg"] = "Bağlam VRAM'e göre ayarlanıyor…"

    async def job():
        try:
            return await agent.fit.calibrate_all(roles, progress=lambda r, m: q.put_nowait({"role": r, "msg": m}),
                                                 warm="main")
        finally:
            agent.status["bg"] = ""
            q.put_nowait(None)
    task = asyncio.get_running_loop().create_task(job())
    try:
        while True:
            ev = await q.get()
            if ev is None:
                break
            yield ev
        await task
    except asyncio.CancelledError:
        task.cancel()
        raise
    yield {"done": True, "summary": agent.fit.summary()}


# ------------------------------------------------------------------ projeler
async def _index_bg(pid):
    p = store.project(pid)
    if p and p.get("path"):
        try:
            r = await asyncio.to_thread(index_project, store, pid, p["path"])
            log.info("Proje indekslendi: %s %s", p["name"], r)
            return r
        except Exception as e:
            log.warning("İndeksleme hatası: %s", e)
            return {"error": str(e)}


@route("GET", "/api/projects")
async def projects():
    return store.projects()


def default_projects_dir():
    docs = Path.home() / "Documents"
    return (docs if docs.is_dir() else Path.home()) / "ATLAS Projeler"


def _prep_path(path, create):
    """Proje klasörünü doğrular; create=True ise yoksa oluşturur."""
    path = str(path or "").strip().strip('"')
    if not path:
        return ""
    import os
    p = Path(os.path.expandvars(os.path.expanduser(path)))
    if not p.is_absolute():
        raise ApiError(400, "Klasör tam yol olmalı (ör. C:\\Users\\Onur\\source\\repos\\Proje)")
    if p.exists() and not p.is_dir():
        raise ApiError(400, f"Bu bir dosya, klasör değil: {p}")
    if not p.exists():
        if not create:
            raise ApiError(400, f"Klasör bulunamadı: {p} — oluşturmak için 'Yeni klasör oluştur'u seç.")
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ApiError(400, f"Klasör oluşturulamadı: {e}")
    return str(p.resolve())


@route("GET", "/api/projects/defaults")
async def project_defaults():
    return {"parent": str(default_projects_dir())}


@route("GET", "/api/fs/check")
async def fs_check(path: str = ""):
    import os
    p = Path(os.path.expandvars(os.path.expanduser(path.strip().strip('"')))) if path.strip() else None
    if not p or not p.is_absolute():
        return {"valid": False}
    used = next((x["name"] for x in store.projects() if x.get("path") and Path(x["path"]) == p), None)
    files = 0
    if p.is_dir():
        try:
            files = sum(1 for _ in zip(range(5000), p.iterdir()))
        except OSError:
            pass
    return {"valid": True, "exists": p.exists(), "is_dir": p.is_dir(), "parent_exists": p.parent.exists(),
            "entries": files, "used_by": used}


@route("POST", "/api/projects")
async def add_project(body):
    name = str(body.get("name", "")).strip() or "Proje"
    path = _prep_path(body.get("path", ""), bool(body.get("create")))
    pid = store.add_project(name, path, str(body.get("description", "")).strip())
    if str(body.get("instructions", "")).strip():
        store.update_project(pid, instructions=body["instructions"].strip())
    if path:
        asyncio.create_task(_index_bg(pid))
    return store.project(pid)


@route("GET", "/api/projects/{pid}")
async def get_project(pid: int):
    p = store.project(pid)
    if not p:
        raise ApiError(404, "Proje yok")
    p.pop("symbols", None)
    p.pop("agent_instructions", None)  # internal persisted snapshot; only injected into agent task context
    return p


@route("PATCH", "/api/projects/{pid}")
async def patch_project(pid: int, body):
    old = store.project(pid)
    allowed = {k: body[k] for k in ("name", "path", "description", "notes", "instructions") if k in body}
    if allowed.get("path"):
        allowed["path"] = _prep_path(allowed["path"], bool(body.get("create")))
    store.update_project(pid, **allowed)
    new_path = allowed.get("path")
    if new_path is not None and old and new_path != old["path"] and new_path.strip():
        asyncio.create_task(_index_bg(pid))
    return await get_project(pid)


@route("DELETE", "/api/projects/{pid}")
async def del_project(pid: int):
    store.delete_project(pid)
    return {"ok": True}


@route("POST", "/api/projects/{pid}/index")
async def reindex(pid: int):
    return await _index_bg(pid) or {"error": "Proje klasörü yok"}


@route("GET", "/api/projects/{pid}/tree")
async def project_tree(pid: int):
    p = store.project(pid)
    if not p or not p.get("path"):
        return {"root": "", "files": []}
    root = Path(p["path"])
    if not root.is_dir():
        return {"root": str(root), "files": [], "error": "Klasör bulunamadı"}

    def work():
        return sorted(f.relative_to(root).as_posix() for f in iter_files(root))
    return {"root": str(root), "files": await asyncio.to_thread(work)}


@route("GET", "/api/file")
async def read_any_file(path: str, project_id: int = None):
    fp = Path(path)
    if not fp.is_absolute() and project_id:
        pr = store.project(project_id)
        if pr and pr.get("path"):
            fp = Path(pr["path"]) / fp
    if not fp.is_file():
        raise ApiError(404, "Dosya yok")
    if fp.stat().st_size > 2_000_000:
        raise ApiError(400, "Dosya çok büyük")
    raw = fp.read_bytes()
    if b"\x00" in raw[:4096]:
        return {"path": str(fp), "binary": True, "size": len(raw)}
    return {"path": str(fp), "content": raw.decode("utf-8", "replace"), "size": len(raw)}


# ------------------------------------------------------------------ sohbetler
@route("GET", "/api/conversations")
async def convs(project_id: int = None):
    return store.conversations(project_id)


@route("POST", "/api/conversations")
async def add_conv(body):
    cid = store.add_conv(body.get("project_id"))
    return store.conv(cid)


@route("GET", "/api/conversations/{cid}")
async def get_conv(cid: int):
    c = store.conv(cid)
    if not c:
        raise ApiError(404, "Sohbet yok")
    c["messages"] = store.messages(cid)
    return c


@route("PATCH", "/api/conversations/{cid}")
async def rename_conv(cid: int, body):
    store.update_conv(cid, title=str(body.get("title", ""))[:120] or "Sohbet")
    return {"ok": True}


@route("DELETE", "/api/conversations/{cid}")
async def del_conv(cid: int):
    store.delete_conv(cid)
    return {"ok": True}


@route("DELETE", "/api/conversations/{cid}/messages/{mid}")
async def truncate_messages(cid: int, mid: int):
    """mid ve sonrasını sil (düzenle / yeniden oluştur)."""
    store.delete_messages_from(cid, mid)
    return {"ok": True}


@route("POST", "/api/conversations/{cid}/pin")
async def pin_conv(cid: int, body):
    store.update_conv(cid, pinned=1 if body.get("pinned") else 0, touch=False)
    return {"ok": True}


@route("POST", "/api/conversations/{cid}/compact")
async def compact(cid: int):
    c = store.conv(cid)
    if not c:
        raise ApiError(404, "Sohbet yok")
    ok = await agent.maybe_summarize(cid, c.get("last_role") or "main", force=True)
    return {"ok": bool(ok), "summary": store.conv(cid).get("summary", "")}


@route("GET", "/api/conversations/{cid}/export")
async def export_conv(cid: int):
    c = store.conv(cid)
    if not c:
        raise ApiError(404, "Sohbet yok")
    lines = [f"# {c['title']}", "", f"_ATLAS sohbet dışa aktarımı — {time.strftime('%d.%m.%Y %H:%M')}_", ""]
    for m in store.messages(cid):
        who = CFG.get("user_name", "Kullanıcı") if m["role"] == "user" else f"ATLAS ({(m.get('model') or '').split('/')[-1]})"
        lines.append(f"## {who}")
        for t in m.get("trace") or []:
            if t.get("name"):
                lines.append(f"> 🔧 `{t['name']}` {json.dumps(t.get('args', {}), ensure_ascii=False)[:200]}")
        lines += ["", m["content"] or "", ""]
    return {"filename": re.sub(r"[^\w\-]+", "_", c["title"])[:60] + ".md", "content": "\n".join(lines)}


@route("GET", "/api/search")
async def search(q: str = ""):
    q = q.strip()
    if len(q) < 2:
        return {"conversations": [], "messages": []}
    convs_ = [c for c in store.all_conversations(1000) if q.lower() in (c["title"] or "").lower()][:20]
    return {"conversations": convs_, "messages": store.search_messages(q, 30)}


@route("GET", "/api/conversations/{cid}/changes")
async def conv_changes(cid: int):
    return store.changes(conv_id=cid)


@route("POST", "/api/turns/{turn}/revert")
async def revert_turn(turn: str):
    done = []
    for ch in reversed(store.changes(turn=turn)):
        if ch["reverted"]:
            continue
        p = Path(ch["path"])
        try:
            if ch["existed"]:
                p.write_bytes(ch["before"] or b"")
            elif p.exists():
                p.unlink()
            store.x("UPDATE file_changes SET reverted=1 WHERE id=?", (ch["id"],))
            done.append(ch["path"])
        except Exception as e:
            done.append(f"HATA {ch['path']}: {e}")
    return {"reverted": done}


# ------------------------------------------------------------------ hafıza
@route("GET", "/api/memories")
async def memories(project_id: int = None):
    return store.memories(project_id)


@route("POST", "/api/memories")
async def add_memory(body):
    content = str(body.get("content", "")).strip()
    if not content:
        raise ApiError(400, "Boş hafıza kaydı")
    pid = body.get("project_id")
    emb = await agent.embed(content)
    sc = body.get("scope")
    if sc == "project_lesson" and pid:
        scope, mp = "lesson", pid
    elif sc in ("user", "lesson"):
        scope, mp = sc, None
    else:
        scope, mp = ("project", pid) if pid else ("user", None)
    return {"id": store.add_memory(content, scope, mp, emb, "manual")}


@route("PATCH", "/api/memories/{mid}")
async def edit_memory(mid: int, body):
    content = str(body.get("content", "")).strip()
    if content:
        store.update_memory(mid, content)
        emb = await agent.embed(content)
        if emb is not None:
            import numpy as np
            store.x("UPDATE memories SET embedding=? WHERE id=?", (np.asarray(emb, dtype=np.float32).tobytes(), mid))
            store._vec_cache.clear()
    return {"ok": True}


@route("DELETE", "/api/memories/{mid}")
async def del_memory(mid: int):
    store.delete_memory(mid)
    return {"ok": True}


# ------------------------------------------------------------------ iş akışları (playbook)
@route("GET", "/api/playbooks")
async def list_playbooks(project_id: int = None):
    return store.playbooks(project_id)


@route("POST", "/api/playbooks")
async def add_playbook(body):
    name, steps = str(body.get("name", "")).strip(), str(body.get("steps", "")).strip()
    if len(name) < 3 or len(steps) < 10:
        raise ApiError(400, "İş akışı için ad ve adımlar gerekli")
    pid = body.get("project_id") if body.get("scope") == "project" else None
    mid, new = store.save_playbook(name, steps, str(body.get("keywords", "")).strip(), pid, "manual")
    return {"id": mid, "new": new}


@route("PATCH", "/api/playbooks/{pid}")
async def edit_playbook(pid: int, body):
    store.update_playbook(pid, **{k: body[k] for k in ("name", "keywords", "steps") if k in body})
    return {"ok": True}


@route("DELETE", "/api/playbooks/{pid}")
async def del_playbook(pid: int):
    store.delete_playbook(pid)
    return {"ok": True}


# ------------------------------------------------------------------ sohbet akışı
@route("POST", "/api/chat", stream=True)
async def chat(body):
    conv_id = body.get("conv_id")
    if not store.conv(conv_id):
        raise ApiError(404, "Sohbet yok")
    q: asyncio.Queue = asyncio.Queue()
    turn_id = uuid.uuid4().hex[:10]
    loop = asyncio.get_running_loop()

    def emit(ev):
        if ev.get("type") == "workspace" and ev.get("project_id"):
            asyncio.ensure_future(_index_bg(ev["project_id"]))  # ajan çalışma alanı açtı → arka planda indeksle
        q.put_nowait(ev)

    async def confirm(kind, detail):
        # MCP trust is independent from command auto-approval: each untrusted tool call
        # requires its own explicit user confirmation.
        if kind != "mcp" and CFG["agent"].get("auto_approve_commands"):
            return True
        cid = uuid.uuid4().hex[:8]
        fut = loop.create_future()
        PENDING[cid] = fut
        emit({"type": "confirm", "id": cid, "kind": kind, "detail": detail})
        if DESKTOP:
            DESKTOP.notify_if_hidden("ATLAS onay bekliyor", str(detail)[:200])
        try:
            return await asyncio.wait_for(fut, 900)
        except asyncio.TimeoutError:
            return False
        finally:
            PENDING.pop(cid, None)

    async def ask(question, options, allow_free):
        qid = uuid.uuid4().hex[:8]
        fut = loop.create_future()
        PENDING[qid] = fut
        emit({"type": "question", "id": qid, "question": question, "options": options, "allow_free": allow_free})
        if DESKTOP:
            DESKTOP.notify_if_hidden("ATLAS bir soru soruyor", question[:200])
        try:
            return await asyncio.wait_for(fut, 1800)
        except asyncio.TimeoutError:
            return ""
        finally:
            PENDING.pop(qid, None)

    async def runner():
        autonomous = False
        try:
            from .autonomy import AUTONOMOUS_MAX_SECONDS, MAX_AUTONOMOUS_ROUNDS, requests_until_success
            original_request = str(body.get("text", ""))
            autonomous = requests_until_success(original_request) and not bool(body.get("regenerate"))
            if autonomous:
                active_conv = store.conv(conv_id) or {}
                active_project = store.project(active_conv.get("project_id")) if active_conv.get("project_id") else None
                if not active_project or not active_project.get("path") or not Path(active_project["path"]).is_dir():
                    emit({"type": "notice", "kind": "warn",
                          "text": "⛔ Çözene-kadar modu için önce gerçek klasörü bağlı bir aktif proje seç; proje dışı/genel sohbette otomatik dosya ve komut çalıştırma kapalı."})
                    return
            deadline = time.monotonic() + AUTONOMOUS_MAX_SECONDS if autonomous else None
            if autonomous:
                emit({"type": "notice", "kind": "info",
                      "text": "🛡️ Watchdog’lu otomatik çözüm/test modu başladı: aktif proje sınırı, 4 saatlik tavan, durdurma düğmesi ve 27B takılma devri etkin."})

            async def run_phase(phase_text, initial=False):
                call = agent.run_turn(
                    emit, conv_id, phase_text, body.get("images") or [] if initial else [],
                    body.get("mode", "auto"), bool(body.get("think", True)), confirm,
                    ask=ask, web=bool(body.get("web", True)),
                    regenerate=bool(body.get("regenerate")) if initial else False,
                    turn=turn_id, desktop=DESKTOP, autonomous=autonomous,
                    autonomous_deadline=deadline)
                try:
                    if deadline:
                        await asyncio.wait_for(call, timeout=max(0.1, deadline - time.monotonic()))
                    else:
                        await call
                    return True
                except asyncio.TimeoutError:
                    emit({"type": "notice", "text": "⏱️ 4 saatlik Watchdog sınırı doldu; çalışma güvenli şekilde durduruldu, checkpoint korundu ve başarı iddia edilmedi."})
                    return False

            if not await run_phase(original_request, initial=True):
                return
            if autonomous:
                for round_no in range(1, MAX_AUTONOMOUS_ROUNDS + 1):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        emit({"type": "notice", "text": "⏱️ 4 saatlik üst sınıra ulaşıldı; plan, değişiklikler ve son kanıt checkpoint olarak kaydedildi. 'Devam et' ile sürdürebilirsin."})
                        break
                    try:
                        agent.status["busy"] = True
                        agent.status["bg"] = "otomatik görev kanıtı denetleniyor"
                        decision, reason = await asyncio.wait_for(
                            agent.assess_autonomous_completion(conv_id, original_request), timeout=min(120, remaining))
                    except asyncio.TimeoutError:
                        emit({"type": "notice", "text": "⏱️ Watchdog tamamlanma denetçisi için zaman sınırına ulaştı; checkpoint korundu, başarı onaylanmadı."})
                        break
                    finally:
                        agent.status["bg"] = ""
                    if decision == "PASS":
                        emit({"type": "notice", "kind": "info", "text": "✅ Bağımsız tamamlanma denetçisi tüm bitti kriterleri için kanıt buldu."})
                        break
                    if decision == "BLOCKED":
                        emit({"type": "notice", "kind": "warn", "text": "⛔ Güvenli sınır/izin/eksik bilgi nedeniyle otomatik görev durdu: " + (reason or "kullanıcı girdisi gerekli")})
                        break
                    emit({"type": "notice", "kind": "info",
                          "text": f"🔁 Tamamlanma denetimi: iş henüz doğrulanmadı (aşama {round_no}/{MAX_AUTONOMOUS_ROUNDS}); aynı görev güvenli biçimde sürdürülüyor."})
                    if not await run_phase("Devam et — otomatik görev denetçisi henüz tüm bitti kriterlerine kanıt bulamadı. "
                                            "Eksik testi/plan adımını tamamla, başarısızlığı düzelt ve gerçek sonuçla yeniden doğrula; "
                                            "aynı başarısız yaklaşımı tekrarlama."):
                        break
                else:
                    emit({"type": "notice", "text": "⏸️ Otomatik görev aşama sınırına ulaştı; plan ve checkpoint korundu. 'Devam et' ile yeniden başlatabilirsin."})
        except asyncio.CancelledError:
            emit({"type": "stopped"})
        except Exception as e:
            log.error("Tur hatası: %s\n%s", e, traceback.format_exc())
            emit({"type": "error", "text": str(e)})
        finally:
            agent.status["busy"] = False
            if autonomous and agent.status.get("bg") == "otomatik görev kanıtı denetleniyor":
                agent.status["bg"] = ""
            q.put_nowait(None)

    task = asyncio.create_task(runner())
    TURNS[turn_id] = task
    yield {"type": "turn", "id": turn_id}
    try:
        while True:
            ev = await q.get()
            if ev is None:
                break
            yield ev
    finally:
        TURNS.pop(turn_id, None)
        if not task.done():
            task.cancel()


@route("POST", "/api/confirm")
async def do_confirm(body):
    fut = PENDING.get(body.get("id"))
    if fut and not fut.done():
        fut.set_result(bool(body.get("approve")))
        return {"ok": True}
    raise ApiError(404, "Onay bekleyen işlem yok")


@route("POST", "/api/answer")
async def do_answer(body):
    fut = PENDING.get(body.get("id"))
    if fut and not fut.done():
        fut.set_result(str(body.get("answer", "")))
        return {"ok": True}
    raise ApiError(404, "Bekleyen soru yok")


@route("POST", "/api/stop/{turn_id}")
async def stop(turn_id: str):
    t = TURNS.get(turn_id)
    if t and not t.done():
        t.cancel()
    return {"ok": True}


# ------------------------------------------------------------------ masaüstü işlemleri
def _need_desktop():
    if not DESKTOP:
        raise ApiError(400, "Masaüstü penceresi hazır değil")


@route("POST", "/api/desktop/show")
async def desktop_show():
    if DESKTOP:
        DESKTOP.show()
    return {"ok": DESKTOP is not None}


@route("POST", "/api/screenshot/{mode}")
async def screenshot(mode: str):
    from . import screen
    if mode == "region":
        name = await asyncio.to_thread(DESKTOP.capture_region if DESKTOP else screen.capture_region)
    else:
        name = await asyncio.to_thread(DESKTOP.capture_without_window if DESKTOP else screen.capture_full)
    if not name:
        raise ApiError(408, "Ekran görüntüsü alınmadı")
    return {"name": name}


@route("POST", "/api/desktop/pick_folder")
async def pick_folder():
    _need_desktop()
    return {"path": await asyncio.to_thread(DESKTOP.pick_folder)}


@route("POST", "/api/desktop/pick_path")
async def pick_path(body):
    """Tek dosya yolu seç (içeriği okunmaz) — idat.exe, incelenecek exe vb."""
    _need_desktop()
    kinds = {"exe": ["Programlar (*.exe;*.bat;*.cmd)", "Tüm dosyalar (*.*)"],
             "binary": ["İkili dosyalar (*.exe;*.dll;*.sys;*.i64;*.idb)", "Tüm dosyalar (*.*)"]}
    return {"path": await asyncio.to_thread(DESKTOP.pick_one, kinds.get(body.get("kind")))}


@route("POST", "/api/desktop/pick_files")
async def pick_files():
    _need_desktop()
    paths = await asyncio.to_thread(DESKTOP.pick_files) or []
    out = []
    for p in paths:
        fp = Path(p)
        try:
            suf = fp.suffix.lower()
            if suf in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"):
                if suf == ".bmp":
                    from PIL import Image
                    name = f"{uuid.uuid4().hex}.png"
                    Image.open(fp).save(IMAGES / name)
                else:
                    name = f"{uuid.uuid4().hex}.{'jpg' if suf in ('.jpg', '.jpeg') else suf.lstrip('.')}"
                    (IMAGES / name).write_bytes(fp.read_bytes())
                out.append({"kind": "image", "name": name, "file": fp.name})
            else:
                raw = fp.read_bytes()[:400_000]
                if b"\x00" in raw[:4096]:
                    out.append({"kind": "binary", "path": str(fp), "file": fp.name, "size": fp.stat().st_size})
                else:
                    out.append({"kind": "text", "path": str(fp), "file": fp.name,
                                "content": raw.decode("utf-8", "replace")})
        except Exception as e:
            out.append({"kind": "error", "file": fp.name, "error": str(e)})
    return {"files": out}


@route("POST", "/api/desktop/save")
async def save_file(body):
    _need_desktop()
    path = await asyncio.to_thread(DESKTOP.save_dialog, body.get("filename", ""))
    if not path:
        return {"ok": False}
    Path(path).write_text(body.get("content", ""), encoding="utf-8")
    return {"ok": True, "path": path}


@route("POST", "/api/desktop/open")
async def open_path(body):
    import os
    if sys.platform == "win32" and body.get("path"):
        os.startfile(body["path"])
        return {"ok": True}
    return {"ok": False}


@route("POST", "/api/desktop/notify")
async def notify(body):
    if DESKTOP:
        DESKTOP.notify(body.get("title") or "ATLAS", body.get("message", ""))
    return {"ok": True}


@route("POST", "/api/desktop/autostart")
async def autostart(body):
    _need_desktop()
    return {"ok": await asyncio.to_thread(DESKTOP.set_autostart, bool(body.get("value")))}


@route("POST", "/api/desktop/on_top")
async def on_top(body):
    if DESKTOP:
        DESKTOP.set_on_top(bool(body.get("value")))
    return {"ok": True}



# ------------------------------------------------------------------ Ollama sunucu paneli
from . import ollama_ctl  # noqa: E402

_CTL_LOCK = asyncio.Lock()


def _role_of(model):
    return [r for r, m in CFG["models"].items() if m.get("name") in (model, (model or "").removesuffix(":latest"))]


@route("GET", "/api/ollama/models")
async def ollama_models_list():
    try:
        tags = await ollama.tags()
        loaded = await ollama.ps()
        return {"models": [{"name": t.get("name", ""), "size": t.get("size", 0)} for t in tags],
                "loaded": [m.get("name", "") for m in loaded]}
    except Exception as e:
        raise ApiError(503, f"Ollama modelleri alınamadı: {e}")


@route("GET", "/api/ollama/overview")
async def ollama_overview():
    st = await asyncio.to_thread(ollama_ctl.status)
    st["gpu"] = await asyncio.to_thread(_gpu_info)
    st["busy"] = agent.status["busy"]
    st["min_version"] = ".".join(map(str, OLLAMA_MIN))
    st["outdated"] = bool(st["version"]) and _ver_tuple(st["version"]) < OLLAMA_MIN
    st["loaded"], st["models"] = [], []
    if st["running"]:
        try:
            for p in await ollama.ps():
                size, vram = p.get("size", 0) or 0, p.get("size_vram", 0) or 0
                st["loaded"].append({"name": p["name"], "size": size, "vram": vram,
                                     "gpu_pct": round(vram / size * 100) if size else 0,
                                     "expires": p.get("expires_at"), "ctx": p.get("context_length"),
                                     "params": (p.get("details") or {}).get("parameter_size"),
                                     "quant": (p.get("details") or {}).get("quantization_level"),
                                     "roles": _role_of(p["name"])})
            for t in await ollama.tags():
                d = t.get("details") or {}
                st["models"].append({"name": t["name"], "size": t.get("size", 0), "modified": t.get("modified_at"),
                                     "family": d.get("family"), "params": d.get("parameter_size"),
                                     "quant": d.get("quantization_level"), "format": d.get("format"),
                                     "roles": _role_of(t["name"])})
            st["models"].sort(key=lambda m: (not m["roles"], m["name"]))
            st["models_total"] = sum(m["size"] for m in st["models"])
        except Exception as e:
            st["api_error"] = str(e)
    st["roles"] = {r: m["name"] for r, m in CFG["models"].items()}
    st["ctxfit"] = agent.fit.summary()
    st["settings"] = {**CFG.get("ollama_server", {}), "keep_alive": CFG["performance"].get("keep_alive")}
    return st


async def _control(action, force):
    if agent.status["busy"] and action in ("stop", "restart") and not force:
        raise ApiError(409, "Ajan şu an çalışıyor. Yine de yapmak için 'Zorla' seç ya da yanıtın bitmesini bekle.")
    if _CTL_LOCK.locked():
        raise ApiError(409, "Başka bir Ollama işlemi sürüyor, biraz bekle.")
    async with _CTL_LOCK:
        if action == "start":
            ok, msg = await asyncio.to_thread(ollama_ctl.start)
        elif action == "stop":
            for t in list(TURNS.values()):
                t.cancel()
            ok = await asyncio.to_thread(ollama_ctl.stop)
            msg = "Ollama durduruldu." if ok else "Ollama durdurulamadı (yönetici yetkisi gerekebilir)."
        else:
            for t in list(TURNS.values()):
                t.cancel()
            ok, msg = await asyncio.to_thread(ollama_ctl.restart)
            if ok:
                msg = "Ollama yeni ayarlarla yeniden başlatıldı."
        ollama.forget_caps()
        log.info("Ollama %s: %s", action, msg)
        if not ok:
            raise ApiError(500, msg)
        if action in ("start", "restart"):
            asyncio.get_running_loop().create_task(_fit_bg("Ollama " + action))
        return {"ok": True, "message": msg}


@route("POST", "/api/ollama/start")
async def ollama_start(body):
    return await _control("start", bool(body.get("force")))


@route("POST", "/api/ollama/stop")
async def ollama_stop(body):
    return await _control("stop", bool(body.get("force")))


@route("POST", "/api/ollama/restart")
async def ollama_restart(body):
    return await _control("restart", bool(body.get("force")))


@route("GET", "/api/ollama/log")
async def ollama_log(lines: int = 400, path: str = None):
    allowed = {str(p) for p in ollama_ctl.server_log_candidates()}
    if path and path not in allowed:  # yalnızca bilinen Ollama log dosyaları okunabilir
        raise ApiError(403, "Bu dosya okunamaz")
    return await asyncio.to_thread(ollama_ctl.log_tail, max(20, min(lines, 3000)), path)


@route("POST", "/api/ollama/settings")
async def ollama_settings(body):
    s = body.get("settings") or {}
    cur = dict(CFG.get("ollama_server", {}))
    clean = {}
    for k in ("manage", "flash_attention"):
        if k in s:
            clean[k] = bool(s[k])
    for k, lo, hi in (("max_loaded_models", 1, 8), ("num_parallel", 1, 8), ("context_length", 0, 1_048_576),
                      ("gpu_overhead_mb", 0, 65536)):
        if k in s:
            try:
                clean[k] = max(lo, min(hi, int(s[k] or 0)))
            except (TypeError, ValueError):
                raise ApiError(400, f"Geçersiz sayı: {k}")
    if "kv_cache_type" in s:
        if s["kv_cache_type"] not in ollama_ctl.KV_TYPES:
            raise ApiError(400, "KV önbellek tipi f16, q8_0 veya q4_0 olmalı")
        clean["kv_cache_type"] = s["kv_cache_type"]
    if "models_dir" in s:
        d = str(s["models_dir"] or "").strip()
        if d and not Path(d).is_absolute():
            raise ApiError(400, "Model klasörü tam yol olmalı (ör. D:\\OllamaModels)")
        clean["models_dir"] = d
    if "extra_env" in s:
        _, bad = ollama_ctl.parse_extra_env(s["extra_env"])
        if bad:
            raise ApiError(400, "Geçersiz satır(lar): " + " | ".join(bad[:3]) + " — biçim: ANAHTAR=değer")
        clean["extra_env"] = str(s["extra_env"])
    patch = {"ollama_server": {**cur, **clean}}
    if body.get("keep_alive"):
        ka = str(body["keep_alive"]).strip()
        if not re.fullmatch(r"-1|0|\d+(\.\d+)?[smh]?", ka):
            raise ApiError(400, "Bellekte kalma süresi ör. 30m, 2h, -1 olmalı")
        patch["performance"] = {"keep_alive": ka}
    config.save(patch)
    st = await asyncio.to_thread(ollama_ctl.status)
    return {"ok": True, "applied": st["applied"], "running": st["running"], "ours": st["ours"]}


@route("POST", "/api/ollama/model/load")
async def ollama_model_load(body):
    name = str(body.get("model", "")).strip()
    if not name:
        raise ApiError(400, "Model adı yok")
    roles = _role_of(name)
    opts = agent.options(roles[0]) if roles and roles[0] != "embed" else ({} if "embed" in roles else agent.options("main"))
    t0 = time.time()
    await ollama.load(name, opts, CFG["performance"]["keep_alive"])
    return {"ok": True, "seconds": round(time.time() - t0, 1)}


@route("POST", "/api/ollama/model/unload")
async def ollama_model_unload(body):
    await ollama.unload(str(body.get("model", "")))
    return {"ok": True}


@route("POST", "/api/ollama/models/retire")
async def ollama_retire_legacy_models(body):
    """Yalnızca config.RETIRED ailelerini; güncel rol modeli kurulu ve eski model artık atanmamışsa sil."""
    gone = await retire_old("kullanıcının eski model temizliği", force=True)
    return {"ok": True, "deleted": [name for name, _ in gone], "freed_bytes": sum(size for _, size in gone)}


@route("POST", "/api/ollama/model/delete")
async def ollama_model_delete(body):
    name = str(body.get("model", "")).strip()
    if _role_of(name) and not body.get("force"):
        raise ApiError(409, f"{name} şu an ATLAS rolü olarak kullanılıyor ({', '.join(_role_of(name))}). "
                            "Önce başka bir model ata ya da 'Zorla' seç.")
    await ollama.delete(name)
    return {"ok": True}


@route("POST", "/api/ollama/model/show")
async def ollama_model_show(body):
    name = str(body.get("model", "")).strip()
    info = await ollama.show(name)
    mi = info.get("model_info") or {}
    arch = mi.get("general.architecture", "")
    ctx = next((v for k, v in mi.items() if k.endswith(".context_length")), None)
    return {"name": name, "capabilities": info.get("capabilities") or sorted(await ollama.capabilities(name)),
            "details": info.get("details") or {}, "parameters": info.get("parameters", ""),
            "template": (info.get("template") or "")[:4000], "arch": arch, "context_length": ctx,
            "param_count": mi.get("general.parameter_count"), "license": (info.get("license") or "")[:300],
            "modified": info.get("modified_at"), "roles": _role_of(name)}


@route("POST", "/api/ollama/model/assign")
async def ollama_model_assign(body):
    name, role = str(body.get("model", "")).strip(), body.get("role")
    if role not in CFG["models"]:
        raise ApiError(400, "Bilinmeyen rol")
    if not name:
        raise ApiError(400, "Model adı yok")
    config.save({"models": {role: {"name": name}}})
    ollama.forget_caps()
    asyncio.get_running_loop().create_task(retire_old("rol ataması"))
    return {"ok": True, "roles": {r: m["name"] for r, m in CFG["models"].items()}}


@route("POST", "/api/ollama/pull", stream=True)
async def ollama_pull_any(body):
    name = str(body.get("model", "")).strip()
    if not re.fullmatch(r"[\w.\-/:]+", name):
        raise ApiError(400, "Geçersiz model adı (ör. huihui_ai/Qwen3.6-abliterated:35b-a3b veya orcarouter/Qwen3.8-27B-Uncensored:q4_K_M)")
    yield {"model": name, "status": "başlıyor"}
    try:
        async for ev in ollama.pull_stream(name):
            ev["model"] = name
            yield ev
        ollama.forget_caps(name)
        yield {"model": name, "status": "success", "done": True}
    except Exception as e:
        yield {"model": name, "error": str(e)}
        return
    gone = await retire_old("indirme sonrası")
    if gone:
        yield {"model": name, "status": f"eski modeller silindi: {', '.join(n for n, _ in gone)}",
               "retired": [n for n, _ in gone]}


@route("POST", "/api/ollama/open")
async def ollama_open(body):
    import os
    what = body.get("what")
    st = await asyncio.to_thread(ollama_ctl.status)
    target = {"models": st["models_dir"], "log": str(Path(st["log_path"]).parent),
              "exe": str(Path(st["exe"]).parent) if st.get("exe") else None}.get(what)
    if not target or not Path(target).exists():
        raise ApiError(404, "Klasör bulunamadı")
    if sys.platform == "win32":
        os.startfile(target)
        return {"ok": True, "path": target}
    return {"ok": False, "path": target}


# ------------------------------------------------------------------ tersine mühendislik / harici programlar
@route("GET", "/api/re/check")
async def re_check():
    from . import ida as idamod
    info = await asyncio.to_thread(idamod.check)
    info["tools"] = await asyncio.to_thread(idamod.detect_tools)
    return info


@route("POST", "/api/re/test")
async def re_test(body):
    """IDA'yı küçük bir dosya üzerinde gerçekten çalıştırır (kurulum doğrulaması)."""
    from . import ida as idamod
    import os
    target = body.get("path") or (os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "whoami.exe")
                                  if sys.platform == "win32" else sys.executable)
    try:
        res = await idamod.run(target, "overview", {"limit": 5}, root=None, timeout=300)
    except Exception as e:
        raise ApiError(500, str(e))
    d = res.get("data") or {}
    return {"ok": True, "seconds": res["seconds"], "file": d.get("file"), "proc": d.get("proc"), "bits": d.get("bits"),
            "functions": (d.get("functions") or {}).get("total"), "decompiler": d.get("decompiler"), "ida": d.get("ida"),
            "db": res.get("db")}
