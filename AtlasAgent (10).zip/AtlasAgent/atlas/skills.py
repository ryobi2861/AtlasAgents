"""Agent Skills discovery and safe, on-demand resource access."""
from __future__ import annotations

import re
from pathlib import Path

try:
    import yaml
except ImportError:  # Skills parsing has a stdlib fallback for existing installations.
    yaml = None

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
MAX_SKILLS = 200
MAX_SKILL_CHARS = 60_000
MAX_RESOURCE_CHARS = 60_000


def skill_roots(project_root=None):
    roots = [
        (Path.home() / ".agents" / "skills", "user"),
        (Path.home() / ".claude" / "skills", "user"),
    ]
    if project_root:
        root = Path(project_root)
        roots += [(root / ".agents" / "skills", "project"),
                  (root / ".claude" / "skills", "project")]
    return roots


def _parse_frontmatter(frontmatter: str):
    if yaml is not None:
        try:
            return yaml.safe_load(frontmatter)
        except yaml.YAMLError:
            return None
    # Minimal YAML frontmatter fallback for existing installations without PyYAML.
    # Agent Skills only needs scalar name/description metadata here.
    import ast
    lines = frontmatter.splitlines()
    data, i = {}, 0
    while i < len(lines):
        line = lines[i]
        i += 1
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.match(r"^([A-Za-z][A-Za-z0-9_-]*):(?:[ \t]*(.*))?$", line)
        if not match:
            return None
        key, value = match.group(1), match.group(2) or ""
        if value in ("|", ">", "|-", ">-"):
            block, folded = [], value.startswith(">")
            while i < len(lines) and (not lines[i].strip() or lines[i][:1].isspace()):
                block.append(lines[i].strip())
                i += 1
            data[key] = (" " if folded else "\n").join(x for x in block if x)
        elif value.startswith(("'", '"')):
            try:
                data[key] = ast.literal_eval(value)
            except (ValueError, SyntaxError):
                return None
        else:
            data[key] = re.split(r"\s+#", value, maxsplit=1)[0].strip()
    return data


def _read_skill(path: Path, source: str):
    skill_file = path / "SKILL.md"
    if path.is_symlink() or skill_file.is_symlink() or not skill_file.is_file():
        return None
    try:
        raw = skill_file.read_text(encoding="utf-8").replace("\r\n", "\n")
    except (OSError, UnicodeError):
        return None
    if len(raw) > MAX_SKILL_CHARS or not raw.startswith("---\n"):
        return None
    end = raw.find("\n---", 4)
    if end < 0:
        return None
    meta = _parse_frontmatter(raw[4:end])
    if not isinstance(meta, dict):
        return None
    name, desc = meta.get("name"), meta.get("description")
    if not isinstance(name, str) or len(name) > 64 or not _NAME.fullmatch(name) or name != path.name:
        return None
    if not isinstance(desc, str) or not desc.strip() or len(desc) > 1024:
        return None
    return {"name": name, "description": desc.strip(), "source": source,
            "path": str(path.resolve()), "body": raw[end + 4:].lstrip("\n")}


def discover_skills(project_root=None):
    """Discover standard skills; project-local definitions override user definitions."""
    found = {}
    roots = skill_roots(project_root)
    for root, source in roots:
        if not root.is_dir() or root.is_symlink():
            continue
        try:
            children = sorted(root.iterdir(), key=lambda p: p.name)
        except OSError:
            continue
        for child in children:
            if len(found) >= MAX_SKILLS and child.name not in found:
                continue
            skill = _read_skill(child, source)
            if skill:
                if skill["name"] not in found or source == "project":
                    found[skill["name"]] = skill
    return list(found.values())


def read_resource(skill, relative_path):
    """Read a text resource within a discovered skill; traversal and symlink escape are rejected."""
    rel = Path(str(relative_path or ""))
    if rel.is_absolute() or not rel.parts or any(p in (".", "..") for p in rel.parts):
        raise ValueError("Kaynak yolu skill klasörü içinde göreli olmalı.")
    root = Path(skill["path"]).resolve()
    path = (root / rel).resolve(strict=True)
    try:
        path.relative_to(root)
    except ValueError:
        raise ValueError("Skill klasörü dışına erişim reddedildi.")
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_RESOURCE_CHARS * 4:
        raise ValueError("Kaynak dosyası geçersiz veya çok büyük.")
    text = path.read_text(encoding="utf-8")
    if len(text) > MAX_RESOURCE_CHARS:
        raise ValueError("Kaynak dosyası çok büyük.")
    return text
