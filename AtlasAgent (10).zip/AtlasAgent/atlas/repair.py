"""Bozuk araç çağrılarını tolere eden onarım katmanı.

Yerel modeller (özellikle quantize / abliterated olanlar) araç çağrılarını sık sık bozar:
  • geçersiz JSON (tek tırnak, sondaki virgül, tırnaksız anahtar, kaçışsız tırnak, kesik çıktı, ``` çiti)
  • yanlış araç adı (readFile, functions.read_file, open_file, cat, bash…)
  • yanlış parametre adı (file_path, filename, cmd, text…) veya tipi ("42", "true", tek dosya yerine dizi)
  • çağrıyı metin olarak yazma (<tool_call>, <function=…>, <invoke>, ```json, read_file({...}) …)
Bu modül hepsini mümkün olduğunca düzeltir; düzeltilemeyen çağrılar için modele açıklayıcı
bir hata ve doğru kullanım örneği döndürülür (model kendini düzeltebilsin diye).
"""
import difflib
import json
import re

# ====================================================================== toleranslı JSON
_CLOSERS = {"{": "}", "[": "]"}


class _Lenient:
    """Hata affeden JSON / JS-nesne / Python-dict ayrıştırıcısı.
    Kesik girdiyi otomatik kapatır (self.truncated=True olur)."""

    def __init__(self, text):
        self.t = text
        self.i = 0
        self.n = len(text)
        self.truncated = False

    # --- yardımcılar
    def ws(self):
        t, n = self.t, self.n
        while self.i < n:
            c = t[self.i]
            if c in " \t\r\n\ufeff":
                self.i += 1
            elif t.startswith("//", self.i):
                j = t.find("\n", self.i)
                self.i = n if j < 0 else j + 1
            elif t.startswith("/*", self.i):
                j = t.find("*/", self.i + 2)
                self.i = n if j < 0 else j + 2
            else:
                break

    def eof(self):
        return self.i >= self.n

    # --- değerler
    def value(self, ctx=None):
        self.ws()
        if self.eof():
            self.truncated = True
            return None
        c = self.t[self.i]
        if c == "{":
            return self.obj()
        if c == "[":
            return self.arr()
        if c in "\"'`":
            return self.string(c, ctx)
        m = re.compile(r"[-+]?(?:0[xX][0-9a-fA-F]+|\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+)").match(self.t, self.i)
        if m and (m.end() >= self.n or self.t[m.end()] in " \t\r\n,}]):/"):
            self.i = m.end()
            s = m.group()
            if s.lower().startswith(("0x", "-0x", "+0x")):
                return s  # hex adresler string kalsın (şema int isterse sonradan çevrilir)
            try:
                return int(s)
            except ValueError:
                return float(s)
        return self.bare(ctx)

    def bare(self, ctx):
        """Tırnaksız değer: true/false/null/None… ya da düz metin (ayırıcıya kadar)."""
        stop = ",}]\n" if ctx in ("obj", "arr") else "\n"
        j = self.i
        depth = 0
        while j < self.n:
            ch = self.t[j]
            if ch in "([":
                depth += 1
            elif ch in ")]" and depth:
                depth -= 1
            elif ch in stop and depth == 0:
                break
            j += 1
        word = self.t[self.i:j].strip()
        self.i = j
        low = word.lower()
        if low in ("true", "yes"):
            return True
        if low in ("false", "no"):
            return False
        if low in ("null", "none", "undefined", "nil"):
            return None
        return word

    def string(self, q, ctx):
        t = self.t
        if t.startswith(q * 3, self.i):  # """üçlü tırnak""" (Python tarzı)
            j = t.find(q * 3, self.i + 3)
            if j < 0:
                self.truncated = True
                s, self.i = t[self.i + 3:], self.n
            else:
                s, self.i = t[self.i + 3:j], j + 3
            return s
        self.i += 1
        out = []
        while self.i < self.n:
            c = t[self.i]
            if c == "\\" and self.i + 1 < self.n:
                e = t[self.i + 1]
                if e == "u" and re.match(r"[0-9a-fA-F]{4}", t[self.i + 2:self.i + 6]):
                    out.append(chr(int(t[self.i + 2:self.i + 6], 16)))
                    self.i += 6
                    continue
                out.append({"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f", "0": "\0"}.get(e, e))
                self.i += 2
                continue
            if c == q:
                if self._closes_here(ctx):
                    self.i += 1
                    return "".join(out)
                out.append(c)  # kaçışsız iç tırnak → metnin parçası say
                self.i += 1
                continue
            out.append(c)
            self.i += 1
        self.truncated = True
        return "".join(out)

    def _closes_here(self, ctx):
        """Bu tırnak gerçekten dizgiyi mi kapatıyor? (kaçışsız iç tırnakları ayırt etmek için)"""
        rest = re.sub(r"//[^\n]*|/\*.*?\*/", "", self.t[self.i + 1:self.i + 400], flags=re.S)  # yalnızca ileri bakış
        if ctx == "key":
            return bool(re.match(r"\s*[:=]", rest)) or not rest.strip()
        if ctx == "obj":
            return bool(re.match(r"\s*(,\s*([\"'`]?[\w\-$]+[\"'`]?\s*[:=]|[}\]])|[}\]]|\Z|,\s*\Z)", rest))
        if ctx == "arr":
            return bool(re.match(r"\s*(,|\]|\Z)", rest))
        return True

    def key(self):
        self.ws()
        c = self.t[self.i] if not self.eof() else ""
        if c in "\"'`":
            return self.string(c, "key")
        m = re.compile(r"[^\s:=,{}\[\]]+").match(self.t, self.i)
        if not m:
            return None
        self.i = m.end()
        return m.group()

    def obj(self):
        self.i += 1
        d = {}
        while True:
            self.ws()
            if self.eof():
                self.truncated = True
                return d
            c = self.t[self.i]
            if c == "}":
                self.i += 1
                return d
            if c in ",;":
                self.i += 1
                continue
            if c == "]":  # yanlış kapanış
                self.i += 1
                return d
            k = self.key()
            if k is None:
                self.i += 1
                continue
            self.ws()
            if not self.eof() and self.t[self.i] in ":=":
                self.i += 1
            elif self.eof():
                self.truncated = True
                d[k] = None
                return d
            d[k] = self.value("obj")

    def arr(self):
        self.i += 1
        a = []
        while True:
            self.ws()
            if self.eof():
                self.truncated = True
                return a
            c = self.t[self.i]
            if c == "]":
                self.i += 1
                return a
            if c == ",":
                self.i += 1
                continue
            if c == "}":
                self.i += 1
                return a
            before = self.i
            a.append(self.value("arr"))
            if self.i == before:
                self.i += 1


def strip_fences(s):
    s = s.strip()
    m = re.match(r"^```[\w\-]*\s*\n?(.*?)\n?```\s*$", s, re.S)
    return m.group(1).strip() if m else s


def loads_lenient(s, notes=None):
    """Toleranslı JSON çözümleme. Dönüş: (nesne, kesik_mi). Hiçbir şey çıkmazsa ValueError."""
    if not isinstance(s, str):
        return s, False
    raw = strip_fences(s)
    if not raw:
        return {}, False
    try:
        obj = json.loads(raw, strict=False)
        if isinstance(obj, str) and obj.strip()[:1] in "{[":  # çift kodlanmış JSON
            if notes is not None:
                notes.append("çift kodlanmış JSON çözüldü")
            return loads_lenient(obj, notes)
        return obj, False
    except Exception:
        pass
    starts = [i for i in (raw.find("{"), raw.find("[")) if i >= 0]
    if not starts:
        raise ValueError("JSON bulunamadı")
    p = _Lenient(raw[min(starts):])
    obj = p.value()
    if obj is None:
        raise ValueError("JSON çözülemedi")
    if notes is not None:
        notes.append("bozuk JSON onarıldı" + (" (kesik çıktı)" if p.truncated else ""))
    return obj, p.truncated


# ====================================================================== adlar
def snake(s):
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(s))
    return re.sub(r"[\s\-\.]+", "_", s).strip("_").lower()


TOOL_ALIASES = {
    "list_dir": ["ls", "dir", "list_files", "list_directory", "listdir", "list_folder", "tree", "list", "glob",
                 "directory_tree", "view_directory", "get_files", "list_dir_tree"],
    "read_file": ["open_file", "cat", "view_file", "view", "read", "get_file", "file_read", "show_file",
                  "read_file_content", "readfile", "open", "get_file_contents", "read_text_file"],
    "write_file": ["create_file", "save_file", "write", "file_write", "new_file", "overwrite_file", "put_file",
                   "write_to_file", "create", "save"],
    "edit_file": ["replace_in_file", "str_replace", "str_replace_editor", "modify_file", "patch_file", "edit",
                  "replace", "update_file", "search_replace", "apply_edit", "file_edit", "str_replace_based_edit_tool"],
    "search_code": ["grep", "search", "find", "find_in_files", "code_search", "search_files", "ripgrep", "rg",
                    "search_text", "grep_search", "find_text"],
    "run_command": ["bash", "shell", "exec", "execute", "execute_command", "terminal", "cmd", "run", "run_shell",
                    "powershell", "run_terminal_cmd", "command", "system", "run_cmd", "execute_shell"],
    "compile_cpp": ["compile", "build", "build_cpp", "compile_code", "cpp_compile", "gcc", "msvc", "make"],
    "remember": ["save_memory", "memorize", "add_memory", "store_memory", "memory_add", "note", "save_fact"],
    "recall": ["search_memory", "memory_search", "retrieve_memory", "get_memory", "query_memory", "memories"],
    "update_project_notes": ["project_notes", "update_notes", "write_notes", "set_notes", "save_notes"],
    "analyze_binary": ["analyze_pe", "pe_info", "binary_info", "analyze", "inspect_binary", "analyze_elf", "peinfo"],
    "extract_strings": ["strings", "get_strings", "find_strings", "dump_strings"],
    "disassemble": ["disasm", "disassembly", "objdump", "decompile_asm", "capstone"],
    "hexdump": ["hex", "hex_dump", "xxd", "dump_hex", "read_bytes"],
    "update_plan": ["plan", "set_plan", "todo", "todo_write", "todowrite", "create_plan", "update_todos",
                    "make_plan", "task_list", "update_todo"],
    "ask_user": ["ask", "ask_question", "question", "ask_human", "clarify", "request_input", "ask_followup_question"],
    "run_python": ["python", "execute_python", "code_interpreter", "run_code", "python_exec", "exec_python",
                   "ipython", "jupyter", "run_script"],
    "take_screenshot": ["screenshot", "capture_screen", "screen_capture", "take_screen_shot", "grab_screen"],
    "web_search": ["search_web", "google", "internet_search", "websearch", "bing", "duckduckgo", "search_internet",
                   "brave_search", "browser_search"],
    "fetch_url": ["fetch", "open_url", "browse", "browse_url", "get_url", "http_get", "read_url", "visit",
                  "fetch_page", "web_fetch", "get_webpage", "curl", "download_page"],
}
_ALIAS = {a: t for t, al in TOOL_ALIASES.items() for a in al}

# Modelin "son cevap" niyetiyle uydurduğu araçlar → cevap metni olarak kabul edilir
FINAL_TOOLS = {"final_answer", "answer", "respond", "reply", "finish", "final", "send_message", "message_user",
               "attempt_completion", "complete", "done", "return_answer", "final_response", "user_message"}
FINAL_KEYS = ("answer", "text", "message", "content", "response", "result", "output", "final_answer")

PARAM_ALIASES = {
    "path": ["file", "file_path", "filepath", "filename", "file_name", "target_file", "target", "fname", "src_path",
             "dir", "directory", "folder", "dir_path", "dirpath", "folder_path", "relative_path", "abs_path",
             "absolute_path", "location", "binary", "binary_path", "exe", "module"],
    "content": ["contents", "text", "data", "body", "file_content", "file_text", "code", "source", "new_content",
                "value", "memory", "fact", "info", "information"],
    "old_text": ["old", "old_str", "old_string", "search", "find", "original", "old_code", "target_text", "before",
                 "from", "search_text", "pattern"],
    "new_text": ["new", "new_str", "new_string", "replace", "replacement", "new_code", "after", "to", "replace_with",
                 "replace_text", "with"],
    "command": ["cmd", "shell", "script", "command_line", "commandline", "cmdline", "bash", "exec", "run", "line"],
    "query": ["q", "search", "pattern", "keyword", "keywords", "term", "search_term", "text", "regex_pattern",
              "search_query", "question", "topic"],
    "code": ["source", "script", "python", "program", "python_code", "src", "snippet", "content"],
    "url": ["link", "href", "uri", "address", "page", "website", "web_url"],
    "notes": ["content", "text", "markdown", "note", "body", "project_notes"],
    "items": ["plan", "steps", "todos", "tasks", "todo", "list", "entries", "plan_items"],
    "question": ["text", "prompt", "q", "query", "message", "ask"],
    "options": ["choices", "answers", "alternatives", "option_list", "selections"],
    "sources": ["files", "source", "file", "src", "paths", "path", "source_files", "inputs", "input_files"],
    "cwd": ["working_dir", "workdir", "dir", "directory", "cd", "working_directory", "folder"],
    "depth": ["level", "levels", "max_depth", "recursion", "recursive_depth"],
    "start_line": ["start", "from_line", "line_start", "begin", "first_line", "offset_line", "line"],
    "end_line": ["end", "to_line", "line_end", "last_line", "stop"],
    "timeout": ["time_limit", "timeout_sec", "timeout_seconds", "seconds", "max_time"],
    "glob": ["file_pattern", "include", "files_glob", "filter_glob", "extension", "ext", "file_glob", "file_type"],
    "regex": ["is_regex", "use_regex", "regexp"],
    "max_results": ["limit", "count", "n", "num_results", "top_k", "max", "results"],
    "scope": ["type", "kind", "category"],
    "address": ["addr", "va", "rva", "offset_hex", "location", "func_address"],
    "symbol": ["function", "export", "name", "func", "function_name", "export_name"],
    "count": ["n", "num", "instructions", "num_instructions", "length", "lines"],
    "offset": ["start", "pos", "position", "from", "file_offset"],
    "length": ["size", "len", "bytes", "count", "n"],
    "min_len": ["min_length", "minimum", "min", "minlen"],
    "filter": ["contains", "grep", "match", "query", "search"],
    "output": ["out", "output_file", "outfile", "exe_name", "target", "o"],
    "std": ["standard", "cpp_std", "cxx_std", "version", "language_standard"],
    "optimize": ["optimization", "opt", "opt_level", "o_level"],
    "extra_flags": ["flags", "args", "cflags", "cxxflags", "compiler_flags", "options"],
    "run": ["execute", "run_after", "and_run"],
    "run_args": ["arguments", "argv", "program_args"],
    "allow_free_text": ["free_text", "allow_free", "allow_other", "allow_custom"],
    "max_chars": ["max_length", "limit", "chars", "max_len"],
}
_STATUS = {"done": "done", "completed": "done", "complete": "done", "finished": "done", "ok": "done", "tamam": "done",
           "bitti": "done", "yapıldı": "done", "success": "done", "closed": "done", "x": "done",
           "in_progress": "in_progress", "inprogress": "in_progress", "in-progress": "in_progress",
           "active": "in_progress", "doing": "in_progress", "running": "in_progress", "current": "in_progress",
           "started": "in_progress", "working": "in_progress", "devam": "in_progress", "wip": "in_progress",
           "pending": "pending", "todo": "pending", "to_do": "pending", "open": "pending", "not_started": "pending",
           "planned": "pending", "waiting": "pending", "bekliyor": "pending", "queued": "pending", "": "pending"}
_STEP_KEYS = ("step", "title", "task", "name", "content", "description", "text", "item", "label", "summary")
_TEXTY = {"content", "code", "notes", "new_text", "old_text", "question"}
_SRC_EXT = re.compile(r"\.(c|cc|cpp|cxx|c\+\+|h|hh|hpp|hxx|ixx|cppm|rc|def|obj|lib|o)$", re.I)


def _specs_index(specs):
    out = {}
    for sp in specs or []:
        f = sp.get("function", sp)
        out[f.get("name")] = f.get("parameters", {}) or {}
    return out


def signature(name, params):
    props, req = params.get("properties", {}) or {}, set(params.get("required") or [])
    parts = [f"{k}{'' if k in req else '?'}: {v.get('type', 'string')}" for k, v in props.items()]
    return f"{name}({', '.join(parts)})"


def resolve_name(raw, names, all_names=None, fuzzy=True):
    """Ham araç adını bilinen bir araca eşle. Dönüş: (ad|None, not|None)."""
    if not raw:
        return None, None
    s = str(raw).strip().strip("`'\"").strip()
    s = re.sub(r"\(.*\)\s*$", "", s)                       # read_file() → read_file
    s = re.split(r"[.:/]", s)[-1] if re.search(r"[.:/]", s) else s   # functions.read_file, default_api:read_file
    if s in names:
        return s, (None if s == raw else f"araç adı '{raw}' → '{s}'")
    sn = snake(s)
    if sn in names:
        return sn, f"araç adı '{raw}' → '{sn}'"
    if all_names and (s in all_names or sn in all_names):   # var olan ama bu turda kapatılmış araç
        return None, f"'{s if s in all_names else sn}' aracı bu turda kapalı (kullanıcı istemedi)"
    tgt = _ALIAS.get(sn) or _ALIAS.get(sn.replace("_", ""))
    if tgt and tgt in names:
        return tgt, f"araç adı '{raw}' → '{tgt}'"
    if tgt and all_names and tgt in all_names:
        return None, f"'{tgt}' aracı şu an kapalı"
    if fuzzy:
        m = difflib.get_close_matches(sn, list(names), n=1, cutoff=0.72)
        if m:
            return m[0], f"araç adı '{raw}' → '{m[0]}' (en yakın eşleşme)"
    return None, None


def _map_key(k, props, taken):
    if k in props:
        return k
    sk = snake(k)
    if sk in props:
        return sk
    for target, al in PARAM_ALIASES.items():
        if target in props and target not in taken and (sk in al or sk.replace("_", "") in al):
            return target
    m = difflib.get_close_matches(sk, [p for p in props if p not in taken], n=1, cutoff=0.8)
    return m[0] if m else None


def _to_bool(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "y", "evet", "on", "doğru", "dogru"):
        return True
    if s in ("false", "0", "no", "n", "hayır", "hayir", "off", "yanlış", "yanlis", "", "none", "null"):
        return False
    raise ValueError(v)


def _to_int(v):
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v)
    s = str(v).strip().replace("_", "")
    if re.fullmatch(r"[-+]?0[xX][0-9a-fA-F]+", s):
        return int(s, 16)
    m = re.search(r"[-+]?\d+(\.\d+)?", s)
    if not m:
        raise ValueError(v)
    return int(float(m.group()))


def _coerce(key, v, sch, notes):
    t = (sch or {}).get("type")
    try:
        if t == "string":
            if isinstance(v, str):
                out = v
            elif isinstance(v, list) and all(isinstance(x, str) for x in v):
                out = ("\n" if key in _TEXTY else " ").join(v)
            elif isinstance(v, (dict, list)):
                out = json.dumps(v, ensure_ascii=False, indent=2 if key in _TEXTY else None)
            elif isinstance(v, bool):
                out = "true" if v else "false"
            else:
                out = str(v)
            if sch.get("enum") and out not in sch["enum"]:
                low = {e.lower(): e for e in sch["enum"]}
                out = low.get(out.lower(), out)
            if out is not v and not isinstance(v, str):
                notes.append(f"'{key}' metne çevrildi")
            return out
        if t == "integer":
            out = _to_int(v)
            if not isinstance(v, int) or isinstance(v, bool):
                notes.append(f"'{key}' tamsayıya çevrildi")
            return out
        if t == "number":
            out = float(v) if not isinstance(v, (int, float)) or isinstance(v, bool) else v
            return out
        if t == "boolean":
            out = _to_bool(v)
            if not isinstance(v, bool):
                notes.append(f"'{key}' mantıksal değere çevrildi")
            return out
        if t == "array":
            if isinstance(v, list):
                return v
            if isinstance(v, str):
                s = v.strip()
                if s[:1] == "[":
                    try:
                        out, _ = loads_lenient(s)
                        if isinstance(out, list):
                            notes.append(f"'{key}' metinden diziye çevrildi")
                            return out
                    except ValueError:
                        pass
                item_t = (sch.get("items") or {}).get("type")
                if item_t in (None, "string"):
                    parts = [p.strip() for p in re.split(r"[\n,;|]+", s) if p.strip()]
                    if key == "sources" and len(parts) == 1 and " " in parts[0]:
                        sp = parts[0].split()
                        if all(_SRC_EXT.search(x) for x in sp):
                            parts = sp
                    notes.append(f"'{key}' diziye çevrildi")
                    return parts
            if isinstance(v, dict):
                notes.append(f"'{key}' diziye sarıldı")
                return list(v.values()) if all(isinstance(x, dict) for x in v.values()) and len(v) > 1 else [v]
            notes.append(f"'{key}' diziye sarıldı")
            return [v]
        if t == "object":
            if isinstance(v, str):
                out, _ = loads_lenient(v)
                return out
            return v
    except (ValueError, TypeError):
        raise ValueError(f"'{key}' parametresi {t} olmalı (gelen: {str(v)[:60]!r})")
    return v


def _fix_plan(items, notes):
    if isinstance(items, dict):
        items = [items]
    out, fixed = [], False
    for it in items or []:
        if isinstance(it, str):
            m = re.match(r"^\s*(?:[-*]\s*)?\[(x| |~|>)\]\s*(.+)$", it, re.I)
            if m:
                st = {"x": "done", "~": "in_progress", ">": "in_progress"}.get(m.group(1).lower(), "pending")
                out.append({"step": m.group(2).strip(), "status": st})
            else:
                out.append({"step": re.sub(r"^\s*(?:[-*]|\d+[.)])\s*", "", it).strip(), "status": "pending"})
            fixed = True
            continue
        if not isinstance(it, dict):
            out.append({"step": str(it), "status": "pending"})
            fixed = True
            continue
        step = it.get("step")
        if not isinstance(step, str) or not step.strip():
            step = next((str(it[k]) for k in _STEP_KEYS if it.get(k)), "")
            fixed = True
        st = it.get("status", it.get("state", ""))
        if isinstance(it.get("done"), bool) or isinstance(it.get("completed"), bool):
            st = "done" if it.get("done") or it.get("completed") else (st or "pending")
        if isinstance(st, bool):
            st = "done" if st else "pending"
        norm = _STATUS.get(str(st).strip().lower().replace(" ", "_"), None)
        if norm is None:
            norm, fixed = "pending", True
        elif norm != st:
            fixed = True
        if step:
            out.append({"step": step.strip(), "status": norm})
    if fixed:
        notes.append("plan maddeleri normalleştirildi")
    return out


def _unwrap_args(args, notes):
    for _ in range(3):
        if isinstance(args, dict) and len(args) == 1:
            (k, v), = args.items()
            if snake(k) in ("arguments", "parameters", "args", "input", "params", "kwargs", "tool_input",
                            "action_input", "inputs"):
                if isinstance(v, str):
                    try:
                        v, _ = loads_lenient(v)
                    except ValueError:
                        return args
                if isinstance(v, dict):
                    notes.append(f"'{k}' sarmalayıcısı açıldı")
                    args = v
                    continue
        break
    return args


def repair_call(name, args, specs, all_specs=None, enabled=True):
    """Tek bir araç çağrısını onarır.
    Dönüş: {"name", "args", "notes": [...], "error": str|None, "final": str|None}
      final → model "final_answer" benzeri bir araçla cevap vermiş; metni cevap olarak kullan."""
    idx = _specs_index(specs)
    all_idx = _specs_index(all_specs) if all_specs else idx
    notes = []
    res = {"name": name, "args": args, "notes": notes, "error": None, "final": None, "truncated": False}

    # --- argümanlar: metin → nesne
    if isinstance(args, str):
        s = args.strip()
        if not s:
            args = {}
        else:
            try:
                args = json.loads(s)
            except Exception:
                if not enabled:
                    res["error"] = "argümanlar geçerli JSON değil"
                    return res
                try:
                    args, res["truncated"] = loads_lenient(s, notes)
                except ValueError:
                    args = {"__raw__": s}
    if args is None:
        args = {}

    # --- ad yoksa argümanların içinde olabilir: {"name": "...", "arguments": {...}}
    if (not name or name in ("tool", "function", "call")) and isinstance(args, dict):
        inner = args.get("name") or args.get("tool") or args.get("tool_name") or args.get("function")
        if isinstance(inner, dict):
            args = inner.get("arguments", inner.get("parameters", {}))
            inner = inner.get("name")
        elif isinstance(inner, str):
            args = args.get("arguments", args.get("parameters", args.get("args", args.get("input", {}))))
        if inner:
            notes.append("araç adı argümanların içinden alındı")
            name = inner
            if isinstance(args, str):
                try:
                    args, _ = loads_lenient(args, notes)
                except ValueError:
                    args = {"__raw__": args}

    raw_name = name
    if not enabled:
        if name not in idx:
            res["error"] = f"bilinmeyen araç '{name}'. Mevcut: {', '.join(sorted(idx))}"
        res["args"] = args if isinstance(args, dict) else {}
        return res

    # --- "son cevap" araçları
    sn = snake(str(name or "")).split(".")[-1]
    if sn in FINAL_TOOLS and sn not in idx:
        text = ""
        if isinstance(args, dict):
            text = next((args[k] for k in FINAL_KEYS if isinstance(args.get(k), str)), "")
            if not text and len(args) == 1:
                text = str(next(iter(args.values())))
        elif isinstance(args, str):
            text = args
        res["final"] = text or ""
        notes.append(f"'{name}' çağrısı son cevap olarak yorumlandı")
        return res

    # --- ad
    real, note = resolve_name(name, set(idx), set(all_idx))
    if note:
        notes.append(note)
    if not real:
        avail = ", ".join(sorted(idx))
        res["error"] = (note + ". " if note else f"bilinmeyen araç '{raw_name}'. ") + f"Kullanılabilir araçlar: {avail}"
        return res
    res["name"] = name = real
    params = idx[name]
    props = params.get("properties", {}) or {}
    required = list(params.get("required") or [])

    # --- argüman kabı
    args = _unwrap_args(args, notes)
    if isinstance(args, list):
        if len(args) == 1 and isinstance(args[0], dict):
            args = args[0]
            notes.append("tek elemanlı dizi açıldı")
        else:
            arr_keys = [k for k, v in props.items() if v.get("type") == "array"]
            primary = (required or arr_keys or list(props) or [None])[0]
            if primary and props.get(primary, {}).get("type") == "array":
                args = {primary: args}
                notes.append(f"dizi '{primary}' parametresine atandı")
            else:
                res["error"] = "argümanlar bir nesne olmalı ({\"parametre\": değer})"
                return res
    if not isinstance(args, dict):
        primary = (required or list(props) or [None])[0]
        if primary is None:
            args = {}
        else:
            args = {primary: args}
            notes.append(f"tek değer '{primary}' parametresine atandı")
    if "__raw__" in args:  # JSON olmayan düz metin → tek zorunlu parametreye ver
        raw = args.pop("__raw__")
        primary = (required or list(props) or [None])[0]
        if primary and not args:
            args = {primary: raw}
            notes.append(f"düz metin '{primary}' parametresine atandı")
        else:
            res["error"] = "argümanlar çözülemedi (geçerli JSON nesnesi gönder)"
            return res

    # --- anahtarlar
    fixed, dropped = {}, []
    for k, v in args.items():
        tk = _map_key(str(k), props, fixed)
        if tk is None:
            dropped.append(str(k))
            continue
        if tk != k:
            notes.append(f"'{k}' → '{tk}'")
        if tk in fixed and fixed[tk] not in (None, ""):
            continue
        fixed[tk] = v
    # eksik zorunlu tek parametre + atılmış tek anahtar → eşle
    missing = [r for r in required if fixed.get(r) in (None, "")]
    if len(missing) == 1 and len(dropped) == 1 and isinstance(args.get(dropped[0]), str):
        fixed[missing[0]] = args[dropped[0]]
        notes.append(f"'{dropped[0]}' → '{missing[0]}'")
        dropped = []
    if dropped:
        notes.append("bilinmeyen parametre yok sayıldı: " + ", ".join(dropped))

    # --- None değerli isteğe bağlı parametreleri at
    for k in [k for k, v in fixed.items() if v is None and k not in required]:
        fixed.pop(k)

    # --- tipler
    errors = []
    for k in list(fixed):
        try:
            fixed[k] = _coerce(k, fixed[k], props.get(k, {}), notes)
        except ValueError as e:
            if k in required:
                errors.append(str(e))
            else:
                fixed.pop(k)
                notes.append(f"geçersiz '{k}' yok sayıldı")
    if name == "update_plan" and "items" in fixed:
        fixed["items"] = _fix_plan(fixed["items"], notes)
    if name == "ask_user" and isinstance(fixed.get("options"), list):
        fixed["options"] = [str(o) if not isinstance(o, dict) else str(o.get("label") or o.get("text") or
                            next(iter(o.values()), "")) for o in fixed["options"]][:8]

    missing = [r for r in required if fixed.get(r) in (None, "") and not (r == "new_text" and "new_text" in fixed)]
    if missing:
        errors.append("eksik zorunlu parametre: " + ", ".join(missing))
    if errors:
        got = ", ".join(f"{k}={str(v)[:40]!r}" for k, v in list(args.items())[:6]) or "boş"
        res["error"] = "; ".join(errors) + f". Gelen: {got}. Beklenen: {signature(name, params)}"
    res["args"] = fixed
    return res


# ====================================================================== metin içindeki çağrılar
_BLOCK_RE = re.compile(
    r"<(?:\|)?(tool_call|tool_calls|function_call|functioncall|tool_use|toolcall)(?:\|)?>(.*?)"
    r"(?:</(?:\|)?(?:tool_call|tool_calls|function_call|functioncall|tool_use|toolcall)(?:\|)?>|(?=<(?:\|)?(?:tool_call|function_call|tool_use)(?:\|)?>)|\Z)",
    re.S | re.I)
_FN_RE = re.compile(r"<function\s*=\s*[\"']?([\w\-.:]+)[\"']?\s*>(.*?)(?:</function>|(?=<function\s*=)|(?=</tool_call>)|\Z)",
                    re.S)
_FN_NAME_RE = re.compile(r"<function\s+name\s*=\s*[\"']([\w\-.:]+)[\"']\s*>(.*?)(?:</function>|\Z)", re.S)
_INVOKE_RE = re.compile(r"<invoke\s+name\s*=\s*[\"']([\w\-.:]+)[\"']\s*>(.*?)(?:</invoke>|\Z)", re.S)
_PARAM_RE = re.compile(r"<parameter\s*=\s*[\"']?([\w\-]+)[\"']?\s*>\n?(.*?)\n?(?:</parameter>|(?=<parameter\s*=)|(?=</function>)|\Z)",
                       re.S)
_PARAM_NAME_RE = re.compile(r"<parameter\s+name\s*=\s*[\"']([\w\-]+)[\"']\s*>\n?(.*?)\n?(?:</parameter>|(?=<parameter\s)|\Z)",
                            re.S)
_FENCE_RE = re.compile(r"```(?:json|tool_call|tool|function|javascript|js)?\s*\n(\{.*?\}|\[.*?\])\s*\n?```", re.S)
_NAME_KEYS = ("name", "tool", "tool_name", "function", "action", "function_name", "recipient_name", "command_name")
_ARG_KEYS = ("arguments", "parameters", "args", "input", "params", "action_input", "tool_input", "kwargs", "inputs")


def _value_from_xml(v):
    v = v.strip("\n")
    return v


def _xml_params(body, props, rx):
    args, unclosed = {}, False
    for pm in rx.finditer(body):
        key, v = pm.group(1), _value_from_xml(pm.group(2))
        args[key] = v
        if not pm.group(0).rstrip().endswith("</parameter>"):
            unclosed = True
    return args, unclosed


def _call_from_obj(obj, names):
    """{"name":..,"arguments":..} / {"tool":..,"input":..} / {"read_file": {...}} → (ad, args) | None"""
    if not isinstance(obj, dict):
        return None
    nm = None
    for k in _NAME_KEYS:
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            nm = v
            break
        if isinstance(v, dict) and isinstance(v.get("name"), str):  # OpenAI: {"function": {"name", "arguments"}}
            return v["name"], v.get("arguments", v.get("parameters", {}))
    if nm:
        a = next((obj[k] for k in _ARG_KEYS if k in obj), None)
        if a is None:
            a = {k: v for k, v in obj.items() if k not in _NAME_KEYS and k not in ("type", "id")}
        return nm, a
    if len(obj) == 1:
        (k, v), = obj.items()
        if isinstance(v, dict) and resolve_name(k, names, fuzzy=False)[0]:
            return k, v
    return None


def extract_text_calls(content, specs, done_reason=None):
    """Metin olarak yazılmış araç çağrılarını bulur.
    Dönüş: (calls, temizlenmiş_metin). calls: [{"function": {"name", "arguments"}, "truncated": bool, "source": str}]"""
    if not content:
        return [], content or ""
    idx = _specs_index(specs)
    names = set(idx)
    calls, spans = [], []
    length_cut = done_reason == "length"

    def add(name, args, span, src, unclosed=False):
        trunc = False
        if isinstance(args, str):
            s = args.strip()
            if s[:1] in "{[":
                try:
                    args, trunc = loads_lenient(s)
                except ValueError:
                    pass
        calls.append({"function": {"name": name, "arguments": args},
                      "truncated": bool(length_cut and (unclosed or trunc)), "source": src})
        spans.append(span)

    def parse_fn_body(name, body, span, src, block_unclosed):
        props = (idx.get(resolve_name(name, names)[0] or name) or {}).get("properties", {})
        b = body.strip()
        if "<parameter" in b:
            rx = _PARAM_NAME_RE if re.search(r"<parameter\s+name\s*=", b) else _PARAM_RE
            args, unclosed = _xml_params(b, props, rx)
            add(name, args, span, src, unclosed or block_unclosed)
        elif b[:1] in "{[":
            add(name, b, span, src, block_unclosed)
        else:  # <function=read_file><path>a.cpp</path></function>
            args = {}
            for m in re.finditer(r"<([\w\-]+)>\n?(.*?)\n?</\1>", b, re.S):
                args[m.group(1)] = m.group(2)
            if not args and b and props:
                req = (idx.get(resolve_name(name, names)[0] or name) or {}).get("required") or list(props)
                args = {req[0]: b}
            add(name, args, span, src, block_unclosed)

    # 1) <tool_call> … </tool_call> blokları (ve benzerleri)
    for m in _BLOCK_RE.finditer(content):
        body, span = m.group(2), m.span()
        unclosed = not re.search(r"</\|?\w+\|?>\s*$", m.group(0))
        fm = _FN_RE.search(body) or _FN_NAME_RE.search(body)
        im = _INVOKE_RE.search(body)
        n_before = len(calls)
        if fm:
            for f in list(_FN_RE.finditer(body)) or list(_FN_NAME_RE.finditer(body)):
                parse_fn_body(f.group(1), f.group(2), span, "xml", unclosed or not f.group(0).rstrip().endswith("</function>"))
        elif im:
            for f in _INVOKE_RE.finditer(body):
                args, unc = _xml_params(f.group(2), {}, _PARAM_NAME_RE)
                add(f.group(1), args, span, "invoke", unc or unclosed)
        else:
            b = strip_fences(body)
            try:
                obj, trunc = loads_lenient(b)
            except ValueError:
                obj, trunc = None, False
            for o in (obj if isinstance(obj, list) else [obj]):
                c = _call_from_obj(o, names)
                if c:
                    calls.append({"function": {"name": c[0], "arguments": c[1]},
                                  "truncated": bool(length_cut and (unclosed or trunc)), "source": "json"})
                    spans.append(span)
        if len(calls) == n_before:
            spans.append(span)  # boş/çözülemeyen blok da metinden silinsin

    # 2) blok dışında kalan <function=…> / <function name=…> / <invoke>
    def outside(pos):
        return not any(a <= pos < b for a, b in spans)
    for rx in (_FN_RE, _FN_NAME_RE):
        for f in rx.finditer(content):
            if outside(f.start()):
                parse_fn_body(f.group(1), f.group(2), f.span(), "xml", not f.group(0).rstrip().endswith("</function>"))
    for f in _INVOKE_RE.finditer(content):
        if outside(f.start()):
            args, unc = _xml_params(f.group(2), {}, _PARAM_NAME_RE)
            add(f.group(1), args, f.span(), "invoke", unc)

    # 3) yalnızca başka çağrı yoksa: ```json {"name": ...}``` çitleri, düz JSON, fonksiyon-çağrısı satırları
    if not calls:
        for f in _FENCE_RE.finditer(content):
            try:
                obj, trunc = loads_lenient(f.group(1))
            except ValueError:
                continue
            for o in (obj if isinstance(obj, list) else [obj]):
                c = _call_from_obj(o, names)
                if c and resolve_name(c[0], names, fuzzy=False)[0] and isinstance(c[1], (dict, str)):
                    calls.append({"function": {"name": c[0], "arguments": c[1]}, "truncated": False, "source": "fence"})
                    spans.append(f.span())
    if not calls:
        s = content.strip()
        if s[:1] in "{[" and s[-1:] in "}]":
            try:
                obj, _ = loads_lenient(s)
                for o in (obj if isinstance(obj, list) else [obj]):
                    c = _call_from_obj(o, names)
                    if c and resolve_name(c[0], names, fuzzy=False)[0]:
                        calls.append({"function": {"name": c[0], "arguments": c[1]}, "truncated": False,
                                      "source": "json"})
                if calls:
                    spans.append((0, len(content)))
            except ValueError:
                pass
    if not calls:
        # metnin SONUNDAKİ, kod çiti dışındaki  read_file({"path": "a.cpp"})  /  read_file(path="a.cpp")  satırları
        fence_spans = [m.span() for m in re.finditer(r"```.*?(```|\Z)", content, re.S)]
        lines = list(re.finditer(r"^[ \t]*`?([A-Za-z_][\w.]*)\((.*)\)`?[ \t]*;?[ \t]*$", content, re.M))
        tail = []
        end = len(content.rstrip())
        for m in reversed(lines):
            if any(a <= m.start() < b for a, b in fence_spans):
                break
            if content[m.end():end].strip():
                break
            nm = resolve_name(m.group(1), names, fuzzy=False)[0]
            if not nm:
                break
            inner = m.group(2).strip()
            try:
                if not inner:
                    args = {}
                elif inner[:1] in "{[":
                    args, _ = loads_lenient(inner)
                elif re.match(r"[\w\-]+\s*=", inner):
                    args, _ = loads_lenient("{" + inner + "}")
                else:
                    args, _ = loads_lenient("[" + inner + "]")
                    req = idx[nm].get("required") or list(idx[nm].get("properties", {}))
                    args = dict(zip(req, args)) if isinstance(args, list) else args
            except ValueError:
                break
            tail.append((m.group(1), args, m.span()))
            end = m.start()
        for nm, args, span in reversed(tail):
            calls.append({"function": {"name": nm, "arguments": args}, "truncated": False, "source": "pycall"})
            spans.append(span)

    if not calls and not spans:
        return [], content
    out, last = [], 0
    for a, b in sorted(spans):
        if a >= last:
            out.append(content[last:a])
            last = b
    out.append(content[last:])
    cleaned = "".join(out)
    cleaned = re.sub(r"</?(?:\|)?(?:tool_call|tool_calls|function_call|tool_use)(?:\|)?>|</function>|</invoke>", "",
                     cleaned)
    return calls, re.sub(r"\n{3,}", "\n\n", cleaned).strip()


TEXT_MARKERS = ("<tool_call", "<|tool_call", "<function=", "<function ", "<function_call", "<tool_use", "<invoke",
                "<functioncall", "<toolcall")


def looks_like_call(text):
    if not text:
        return False
    if any(m in text for m in TEXT_MARKERS):
        return True
    return bool(re.search(r"[\"'](name|tool|function)[\"']\s*:", text)) or bool(
        re.search(r"^[ \t]*[a-z_]+\(.*\)[ \t]*$", text, re.M))


def parse_ollama_tool_error(body):
    """Ollama 'error parsing tool call: raw='…', err=…' hatasından ham çağrıyı çıkarır."""
    m = re.search(r"raw='(.*)'\s*,\s*err=", body, re.S) or re.search(r"raw=\"(.*)\"\s*,\s*err=", body, re.S)
    return m.group(1) if m else None


def format_hint(name, params, prompted):
    """Model kendini düzeltebilsin diye doğru çağrı örneği."""
    props = params.get("properties", {}) or {}
    req = params.get("required") or list(props)[:1]
    if prompted:
        inner = "".join(f"<parameter={k}>\n…\n</parameter>\n" for k in req)
        return f"<tool_call>\n<function={name}>\n{inner}</function>\n</tool_call>"
    return json.dumps({"name": name, "arguments": {k: "…" for k in req}}, ensure_ascii=False)
