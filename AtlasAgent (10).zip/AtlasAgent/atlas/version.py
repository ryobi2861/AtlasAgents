"""Single source of truth for the ATLAS application version."""

APP_VERSION = "0.3.2"
