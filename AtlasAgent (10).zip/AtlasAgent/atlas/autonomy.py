"""Opt-in, bounded autonomous task mode and command-safety policy."""
import json
import re
from pathlib import Path

from . import cmdguard

AUTONOMOUS_MAX_SECONDS = 4 * 60 * 60
MAX_AUTONOMOUS_ROUNDS = 24

_PERSISTENCE = re.compile(
    r"(?:çöz(?:ene|ene kadar|ülene) kadar|çözülene dek|başarılı olana kadar|sonuç alana kadar|"
    r"bitene kadar durma|durmadan devam et|çözene kadar durma|until (?:it|the issue) is (?:fixed|solved)|"
    r"keep (?:testing|working) until|don't stop until)", re.I)
_ACTION = re.compile(r"(?:test|den[eey]|çöz|düzelt|fix|solve|debug|onar)", re.I)
_COMPUTER_USE = re.compile(r"(?:computer[- ]?use|computeuse|bilgisayar(?:ı|ımı) kullan|fare|mouse|klavye|tıkla|tıklay|click|type into|(?:arayüz|ui).{0,24}(?:test|tıkla|mouse|klavye))", re.I)
_FORBIDDEN = re.compile(
    r"(?:\b(?:del|erase|format|rmdir|shutdown|restart|taskkill|reg\s+delete|diskpart|mkfs)\b|"
    r"\b(?:rm\s+-rf|git\s+(?:reset|clean|checkout)|(?:pip|npm|pnpm|yarn)\s+install)\b|"
    r"(?:https?://|\b(?:curl|wget|invoke-webrequest)\b|\b(?:powershell|pwsh)\b|"
    r"[;&|<>]))", re.I)
_TEST_COMMAND = re.compile(
    r"^(?:\s*(?:\.venv[\\/]scripts[\\/]python(?:\.exe)?|python(?:3(?:\.\d+)?)?|py(?:\s+-\d(?:\.\d+)?)?)\s+-m\s+(?:pytest|unittest)\b|"
    r"\s*(?:pytest|ctest|cargo\s+test|dotnet\s+test|go\s+test|npm\s+test|pnpm\s+test|yarn\s+test)\b)", re.I)


def requests_until_success(text):
    text = str(text or "")
    return bool(_PERSISTENCE.search(text) and _ACTION.search(text))


def requests_computer_use(text):
    return bool(_COMPUTER_USE.search(str(text or "")))


def _batch_launches_executable(command, workdir):
    """A build-named batch file is not allowed to launch its output during unattended work."""
    refs = re.findall(r"(?:\"([^\"]+\.(?:bat|cmd))\"|(?<![\w.])([\w./\\:-]+\.(?:bat|cmd)))",
                      str(command or ""), re.I)
    for quoted, bare in refs:
        script = Path(quoted or bare)
        if not script.is_absolute():
            script = workdir / script
        try:
            body = script.read_text(encoding="utf-8", errors="replace")[:65536]
        except OSError:
            continue
        for line in body.splitlines():
            s = re.sub(r"^\s*@?", "", line).strip()
            if not s or s.lower().startswith(("rem ", "::", "echo ", "set ", "title ", "chcp ", "pause", "exit ")):
                continue
            if re.match(r"(?i)(?:start\b|start-process\b|call\s+[^ ]+\.exe\b|(?:\.?\\)?[^\s\"]+\.exe(?:\s|$))", s):
                return True
    return False


def safe_autonomous_command(command, cwd, project_root):
    """Only auto-approve clearly local test/build commands inside the active project."""
    if not project_root:
        return False
    try:
        root = Path(project_root).resolve()
        workdir = Path(cwd).resolve()
        workdir.relative_to(root)
    except (OSError, ValueError, TypeError):
        return False
    command = str(command or "").strip()
    if not command or _FORBIDDEN.search(command):
        return False
    if _batch_launches_executable(command, workdir):
        return False
    if _TEST_COMMAND.search(command):
        return True
    try:
        return cmdguard.is_build(command, workdir)
    except Exception:
        return False


def classify_verification(raw):
    """Parse only an explicit leading/verdict token; fail closed on prose mentions."""
    text = str(raw or "").strip()
    try:
        value = json.loads(text).get("decision", "")
        if str(value).upper() in {"PASS", "CONTINUE", "BLOCKED"}:
            return str(value).upper()
    except (ValueError, TypeError, AttributeError):
        pass
    first = text.splitlines()[0].strip().upper() if text else ""
    match = re.match(r"^(PASS|CONTINUE|BLOCKED)(?:\b|\s*[:—-])", first)
    return match.group(1) if match else "CONTINUE"
