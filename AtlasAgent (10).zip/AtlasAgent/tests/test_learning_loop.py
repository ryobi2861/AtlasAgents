import json
import tempfile
import unittest
from pathlib import Path

from atlas.agent import Agent, learning_failure_context
from atlas.store import Store


class LearningLoopTests(unittest.TestCase):
    def test_feedback_labels_latest_episode_and_recent_events_persist(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "memory.sqlite")
            conv_id = store.add_conv(project_id=4)
            first = store.add_learning_event(100, conv_id, 4, "Fix parser", "Tried old parser", [], "attempted")
            second = store.add_learning_event(101, conv_id, 4, "Fix build", "Built after fix", [], "build_verified")
            self.assertNotEqual(first, second)
            marked = store.confirm_latest_learning_event(
                conv_id, "confirmed_failure", "Hâlâ çalışmıyor", assistant_message_id=101)
            events = store.recent_learning_events(4)
            self.assertEqual(marked, second)
            self.assertEqual(events[0]["outcome"], "confirmed_failure")
            self.assertEqual(events[1]["outcome"], "attempted")
            store.conn.close()

    def test_only_relevant_or_same_conversation_failure_is_recalled(self):
        events = [
            {"conv_id": 5, "outcome": "confirmed_failure", "request": "Parser fails on UTF-8 input",
             "actions": json.dumps([{"name": "edit_file", "result": "The fallback parser still failed."}]),
             "created": 2},
            {"conv_id": 8, "outcome": "confirmed_failure", "request": "Update an unrelated settings panel",
             "actions": "[]", "created": 3},
            {"conv_id": 5, "outcome": "confirmed_success", "request": "Not a failure", "actions": "[]", "created": 4},
        ]
        relevant = learning_failure_context(events, "Parser still fails on UTF-8", conversation_id=5)
        self.assertIn("Parser fails on UTF-8", relevant)
        self.assertNotIn("unrelated settings", relevant)
        unrelated = learning_failure_context(events, "Optimize the renderer", conversation_id=5)
        self.assertEqual(unrelated, "")
        forced = learning_failure_context(events, "devam et", conversation_id=5, force_latest=True)
        self.assertIn("Parser fails on UTF-8", forced)

    def test_episode_recording_omits_payloads_and_redacts_secrets(self):
        class CaptureStore:
            event = None

            def add_learning_event(self, *args):
                self.event = args
                return 9

        agent = Agent.__new__(Agent)
        agent.store = CaptureStore()
        agent._record_learning_event(
            3, 20, "Inspect source", "Done", {"id": 2},
            [{"name": "read_file", "args": {"path": "src/main.cpp", "content": "PRIVATE SOURCE", "api_key": "api_key=secret123"},
              "result": "PRIVATE SOURCE BODY"}])
        actions = agent.store.event[5]
        self.assertEqual(actions[0]["result"], "completed")
        self.assertNotIn("PRIVATE SOURCE", json.dumps(actions))
        self.assertNotIn("secret123", json.dumps(actions))

    def test_verified_build_outcome_is_distinguished_from_attempt(self):
        agent = Agent.__new__(Agent)
        trace = [{"name": "compile_cpp", "args": {}, "result": "[g++ | çıkış: 0]\\n✔ Derleme başarılı → build/a.out"}]
        self.assertEqual(agent._learning_outcome(trace, {"path": "/project"}), "build_verified")
        self.assertEqual(agent._learning_outcome([{"name": "read_file", "args": {}, "result": "read ok"}], None),
                         "attempted")
        recovered = [
            {"name": "compile_cpp", "args": {}, "result": "HATA: undefined reference"},
            {"name": "compile_cpp", "args": {}, "result": "[g++ | çıkış: 0]\\n✔ Derleme başarılı → build/a.out"},
        ]
        self.assertEqual(agent._learning_outcome(recovered, {"path": "/project"}), "recovered")


if __name__ == "__main__":
    unittest.main()
