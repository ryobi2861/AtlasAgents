import unittest
import xml.etree.ElementTree as ET

from atlas.agent import tools_prompt
from atlas.tools import tool_specs


class ToolXmlSchemaTests(unittest.TestCase):
    def _tools_xml(self, prompt):
        start = prompt.index("<tools>")
        end = prompt.index("</tools>", start) + len("</tools>")
        return prompt[start:end]

    def test_all_current_tool_schema_descriptions_are_xml_well_formed(self):
        specs = tool_specs()
        prompt = tools_prompt(specs)
        ET.fromstring(self._tools_xml(prompt))
        self.assertNotIn("<600 kelime", prompt)
        # Native Ollama tool templates may serialize descriptions as XML too.
        for spec in specs:
            desc = spec["function"].get("description", "")
            self.assertNotRegex(desc, r"[<&]")
            for prop in spec["function"].get("parameters", {}).get("properties", {}).values():
                self.assertNotRegex(prop.get("description", ""), r"[<&]")

    def test_xml_sensitive_schema_text_is_escaped(self):
        specs = [{
            "function": {
                "name": "test_tool",
                "description": "Use <path> & keep \"quoted\" text",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "A <literal> & value"},
                        "kind": {"type": "string", "enum": ["a&b", "<tag>"]},
                    },
                    "required": ["path"],
                },
            }
        }]
        prompt = tools_prompt(specs)
        ET.fromstring(self._tools_xml(prompt))
        self.assertIn("&lt;path&gt; &amp;", prompt)
        self.assertIn("&lt;literal&gt; &amp; value", prompt)
        self.assertIn("&lt;tag&gt;", prompt)


if __name__ == "__main__":
    unittest.main()
