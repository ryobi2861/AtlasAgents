import tempfile
import unittest
from pathlib import Path

from atlas.project_rules import append_confirmed_instruction, read_agent_files, sync_project_rules
from atlas.store import Store


class FakeStore:
    def __init__(self):
        self.updates = []

    def update_project(self, project_id, **values):
        self.updates.append((project_id, values))


class ProjectRulesTests(unittest.TestCase):
    def test_reads_root_and_scoped_nested_agents_files_but_skips_dependencies(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "AGENTS.md").write_text("Use C++20.", encoding="utf-8")
            (root / "src").mkdir()
            (root / "src" / "agents.md").write_text("For src files: use RAII.", encoding="utf-8")
            (root / "docs").mkdir()
            (root / "docs" / "agenst.md").write_text("Document in Markdown.", encoding="utf-8")
            (root / "node_modules" / "package").mkdir(parents=True)
            (root / "node_modules" / "package" / "AGENTS.md").write_text("Ignore tests.", encoding="utf-8")
            (root / ".git").mkdir()
            (root / ".git" / "AGENTS.md").write_text("Ignore system.", encoding="utf-8")

            text = read_agent_files(root)
            self.assertIn("### AGENTS.md", text)
            self.assertIn("Use C++20.", text)
            self.assertIn("### src/agents.md", text)
            self.assertIn("For src files: use RAII.", text)
            self.assertIn("### docs/agenst.md", text)
            self.assertIn("Document in Markdown.", text)
            self.assertNotIn("Ignore tests", text)
            self.assertNotIn("Ignore system", text)

    def test_snapshot_is_persisted_and_refreshed_after_file_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "AGENTS.md"
            path.write_text("Rule one.", encoding="utf-8")
            project = {"id": 42, "path": str(root), "agent_instructions": ""}
            store = FakeStore()

            first = sync_project_rules(store, project)
            self.assertIn("Rule one.", first)
            self.assertEqual(len(store.updates), 1)
            self.assertEqual(store.updates[0][0], 42)

            self.assertEqual(sync_project_rules(store, project), first)
            self.assertEqual(len(store.updates), 1)

            path.write_text("Rule two.", encoding="utf-8")
            second = sync_project_rules(store, project)
            self.assertIn("Rule two.", second)
            self.assertNotIn("Rule one.", second)
            self.assertEqual(len(store.updates), 2)

    def test_removed_agents_file_clears_stale_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "AGENTS.md"
            path.write_text("Old rule.", encoding="utf-8")
            project = {"id": 7, "path": str(root), "agent_instructions": ""}
            store = FakeStore()
            old = sync_project_rules(store, project)
            path.unlink()
            self.assertEqual(sync_project_rules(store, project), "")
            self.assertEqual(project["agent_instructions"], "")

    def test_unavailable_project_root_keeps_last_persisted_snapshot(self):
        project = {"id": 8, "path": "/path/that/does/not/exist", "agent_instructions": "Cached rule."}
        store = FakeStore()
        self.assertEqual(sync_project_rules(store, project), "Cached rule.")
        self.assertEqual(store.updates, [])

    def test_project_without_folder_does_not_apply_stale_snapshot(self):
        project = {"id": 9, "path": "", "agent_instructions": "Old repository rule."}
        self.assertEqual(sync_project_rules(FakeStore(), project), "")

    def test_agents_md_changes_are_blocked_without_explicit_success_confirmation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "AGENTS.md").write_text("Keep the existing project instructions.\n", encoding="utf-8")
            self.assertFalse(append_confirmed_instruction(
                root, "Use the verified project build script before changing compiler settings.", confirmed=False))
            self.assertEqual((root / "AGENTS.md").read_text(encoding="utf-8"),
                             "Keep the existing project instructions.\n")

    def test_confirmed_agents_update_appends_without_overwriting_and_deduplicates(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "agents.md"
            path.write_text("# Project\n\nUse the existing code style.\n", encoding="utf-8")
            rule = "Run the focused regression test after changing the parser, then verify its full output."
            self.assertTrue(append_confirmed_instruction(root, rule, confirmed=True))
            updated = path.read_text(encoding="utf-8")
            self.assertIn("Use the existing code style.", updated)
            self.assertIn(rule, updated)
            self.assertFalse(append_confirmed_instruction(root, rule, confirmed=True))
            self.assertEqual(path.read_text(encoding="utf-8").count(rule), 1)

    def test_rules_are_persisted_in_project_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            root.mkdir()
            (root / "AGENTS.md").write_text("Use the project formatter.", encoding="utf-8")
            db = Path(tmp) / "atlas.sqlite"
            store = Store(db)
            pid = store.add_project("Test", str(root))
            project = store.project(pid)
            sync_project_rules(store, project)
            self.assertIn("Use the project formatter.", store.project(pid)["agent_instructions"])
            store.conn.close()


if __name__ == "__main__":
    unittest.main()
