import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from atlas.tools import _append_commit_log, _is_git_commit_command, _read_and_record_git_commit


class CommitLogTests(unittest.TestCase):
    def test_commit_command_detection_is_specific(self):
        self.assertTrue(_is_git_commit_command("git commit -m 'Fix parser'"))
        self.assertTrue(_is_git_commit_command('git -C "C:/work/project" commit --amend -m "Fix"'))
        self.assertTrue(_is_git_commit_command("call git.exe commit -m test"))
        self.assertFalse(_is_git_commit_command("git status --short"))
        self.assertFalse(_is_git_commit_command("git log --oneline"))
        self.assertFalse(_is_git_commit_command("echo git commit -m no"))

    def test_commit_log_is_created_in_project_metadata_and_deduplicated(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            record = {
                "hash": "abc123def4567890",
                "subject": "Fix parser crash",
                "author": "Atlas User",
                "timestamp": "2026-10-24T11:30:00+03:00",
                "branch": "main",
                "files": ["M\tsrc/parser.cpp", "A\ttests/parser_test.cpp"],
            }
            log_path = _append_commit_log(root, record)
            self.assertEqual(log_path, root / ".atlas" / "commit-log.md")
            data = log_path.read_text(encoding="utf-8")
            self.assertIn("ATLAS commit kayıtları", data)
            self.assertIn("Fix parser crash", data)
            self.assertIn("src/parser.cpp", data)
            self.assertEqual(_append_commit_log(root, record), log_path)
            self.assertEqual(log_path.read_text(encoding="utf-8").count(record["hash"]), 1)

    @unittest.skipUnless(shutil.which("git"), "git is not installed")
    def test_successful_commit_metadata_is_written_to_project_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True)
            subprocess.run(["git", "config", "user.name", "ATLAS Test"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "atlas-test@example.invalid"], cwd=root, check=True)
            (root / "sample.txt").write_text("committed\n", encoding="utf-8")
            subprocess.run(["git", "add", "sample.txt"], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "Test commit log"], cwd=root, check=True, capture_output=True)
            log_path = _read_and_record_git_commit(root)
            self.assertEqual(log_path, root / ".atlas" / "commit-log.md")
            log_text = log_path.read_text(encoding="utf-8")
            self.assertIn("Test commit log", log_text)
            self.assertIn("sample.txt", log_text)

    def test_log_writer_requires_commit_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(_append_commit_log(tmp, {"subject": "Missing hash"}))
            self.assertFalse((Path(tmp) / ".atlas").exists())


if __name__ == "__main__":
    unittest.main()
