import asyncio
import json
import unittest
from unittest.mock import AsyncMock

from atlas.agent import Agent, STUCK_RESPONSE_RE, _redact_memory_secrets, _short_args, is_success_confirmation


class MessageStore:
    def messages(self, _conversation_id):
        return [
            {"role": "user", "content": "Build fails because the project setting is wrong."},
            {"role": "assistant", "content": "I corrected the setting and rebuilt successfully.", "trace": [
                {"name": "edit_file", "args": {"path": "src/config.cpp", "new_text": "hidden source"},
                 "result": "Updated src/config.cpp with the corrected setting."},
                {"name": "compile_cpp", "args": {"command": "build.bat"},
                 "result": "Build succeeded. API_KEY=secret-value"},
            ]},
            {"role": "user", "content": "Oldu, başarılı çözdük."},
        ]


class MemoryStore:
    def __init__(self):
        self.saved = []

    def max_similarity(self, _embedding, _project_id):
        return 0.0

    def add_memory(self, content, scope, project_id, embedding, source):
        self.saved.append((content, scope, project_id, embedding, source))
        return len(self.saved)


class SuccessMemoryTests(unittest.TestCase):
    def test_detects_success_feedback_but_not_failure_feedback(self):
        self.assertTrue(is_success_confirmation("Oldu, başarılı çözdük!"))
        self.assertTrue(is_success_confirmation("Çalıştı, sorun kalmadı."))
        self.assertFalse(is_success_confirmation("Olmadı, hâlâ çalışmıyor."))
        self.assertFalse(is_success_confirmation("Başarılı olmadı."))
        self.assertFalse(is_success_confirmation(
            "Ben test etmeden onay vermeden sorunu çözdüm diye AGENTS.md güncelleme; başarılı demeden commit atma."))
        self.assertFalse(is_success_confirmation("Başarılı olana kadar test et, durma."))
        self.assertFalse(is_success_confirmation("Sorun çözüldü mü?"))

    def test_detects_explicit_model_failure_for_handoff(self):
        self.assertRegex("Bu sorunu çözemedim; başka türlü deneyebilir misin?", STUCK_RESPONSE_RE)
        self.assertRegex("I cannot solve this with the current approach.", STUCK_RESPONSE_RE)
        self.assertNotRegex("The fix is complete and verified.", STUCK_RESPONSE_RE)

    def test_previous_task_context_includes_request_actions_results_and_redacts_secrets(self):
        agent = Agent.__new__(Agent)
        agent.store = MessageStore()
        context = agent._lesson_context(1, None)
        self.assertIn("ÖNCEKİ KULLANICI İSTEĞİ", context)
        self.assertIn("Build fails", context)
        self.assertIn("edit_file", context)
        self.assertIn("src/config.cpp", context)
        self.assertIn("Build succeeded", context)
        self.assertNotIn("secret-value", context)
        self.assertNotIn("hidden source", context)

    def test_successful_solution_is_saved_as_project_memory(self):
        agent = Agent.__new__(Agent)
        agent.store = MemoryStore()
        agent._quick = AsyncMock(return_value=json.dumps({
            "memory": "Build failure was fixed by correcting the project setting in src/config.cpp; then build.bat was run and reported success."
        }))
        agent.embed = AsyncMock(return_value=None)
        asyncio.run(agent.learn_successful_solution(
            "main", "Oldu, başarılı çözdük.", {"id": 23},
            "User requested a fix. edit_file updated src/config.cpp; build.bat completed successfully."
        ))
        self.assertEqual(len(agent.store.saved), 1)
        memory, scope, project_id, embedding, source = agent.store.saved[0]
        self.assertEqual(scope, "project")
        self.assertEqual(project_id, 23)
        self.assertIn("build.bat", memory)
        self.assertEqual(source, "auto_success")

    def test_secret_redaction_handles_assignments_and_bearer_tokens(self):
        redacted = _redact_memory_secrets("API_KEY=secret123 Authorization: Bearer abcdefghijklmnop")
        self.assertNotIn("secret123", redacted)
        self.assertNotIn("abcdefghijklmnop", redacted)

    def test_tool_trace_args_redact_secrets_recursively(self):
        args = _short_args({"headers": {"Authorization": "Bearer secret-token"}, "nested": [{"api_key": "hidden"}], "text": "fine"})
        self.assertEqual(args["headers"]["Authorization"], "[REDACTED]")
        self.assertEqual(args["nested"][0]["api_key"], "[REDACTED]")
        self.assertEqual(args["text"], "fine")


if __name__ == "__main__":
    unittest.main()
