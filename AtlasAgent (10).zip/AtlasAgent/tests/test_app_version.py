import unittest

from atlas import __version__


class AppVersionTests(unittest.TestCase):
    def test_semver_is_exposed_from_package(self):
        self.assertRegex(__version__, r"^\d+\.\d+\.\d+$")
        self.assertEqual(__version__, "0.3.2")


if __name__ == "__main__":
    unittest.main()
