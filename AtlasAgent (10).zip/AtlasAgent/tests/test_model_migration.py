import unittest

from atlas import config


class ModelMigrationTests(unittest.TestCase):
    def test_legacy_qwen3_roles_migrate_to_current_team(self):
        legacy = {
            "config_version": 7,
            "models": {
                "main": {"name": "huihui_ai/qwen3.5-abliterated:9b"},
                "coder": {"name": "huihui_ai/qwen3-coder-abliterated:30b"},
                "vision": {"name": "huihui_ai/qwen3-vl-abliterated:8b"},
            },
        }
        cfg = config._merge(config.DEFAULTS, legacy)
        config._migrate(legacy, cfg)
        for role in ("main", "coder", "vision", "reviewer"):
            self.assertEqual(cfg["models"][role]["name"], config.DEFAULTS["models"][role]["name"])
        self.assertEqual(cfg["config_version"], 8)

    def test_only_obsolete_families_are_retired_when_replacements_are_installed(self):
        old = {
            "huihui_ai/qwen3.5-abliterated:9b": 1,
            "huihui_ai/qwen3-coder-abliterated:30b": 2,
            "huihui_ai/qwen3-vl-abliterated:8b": 3,
            "llama3:8b": 4,
            config.DEFAULTS["models"]["main"]["name"]: 24,
        }
        plan = config.retire_plan(old, config.DEFAULTS["models"])
        names = {name for name, _ in plan}
        self.assertEqual(names, {
            "huihui_ai/qwen3.5-abliterated:9b",
            "huihui_ai/qwen3-coder-abliterated:30b",
            "huihui_ai/qwen3-vl-abliterated:8b",
        })
        self.assertNotIn("llama3:8b", names)

    def test_old_model_is_not_retired_if_still_assigned(self):
        old_name = "huihui_ai/qwen3.5-abliterated:9b"
        installed = {old_name: 1, config.DEFAULTS["models"]["main"]["name"]: 24}
        models = config._merge(config.DEFAULTS["models"], {"models": {}})
        models["coder"] = {"name": old_name}
        self.assertNotIn(old_name, {name for name, _ in config.retire_plan(installed, models)})


if __name__ == "__main__":
    unittest.main()
