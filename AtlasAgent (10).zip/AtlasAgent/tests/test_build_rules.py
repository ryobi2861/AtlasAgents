import tempfile
import unittest
from pathlib import Path

from atlas.agent import BINARY_ACTION_RE, PROJECT_REVIEW_RE, build_status
from atlas.cmdguard import analyze, script_kind
from atlas.tools import _build_log_scan


class BuildSafetyTests(unittest.TestCase):
    def test_plain_project_review_is_not_binary_analysis_intent(self):
        text = "Projeyi incele, ne olduğunu öğren"
        self.assertIsNotNone(PROJECT_REVIEW_RE.search(text))
        self.assertIsNone(BINARY_ACTION_RE.search(text))

    def test_explicit_binary_analysis_remains_distinct(self):
        self.assertIsNotNone(BINARY_ACTION_RE.search("projeyi incele ve game.exe dosyasını analiz et"))

    def test_start_bat_is_never_classified_as_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "start.bat"
            path.write_text("@echo off\ncl.exe source.cpp\nstart game.exe\n", encoding="utf-8")
            kind, _ = script_kind(path)
            self.assertEqual(kind, "launch")
            self.assertEqual(analyze("start.bat", Path(tmp))[0][0], "launch")

    def test_build_bat_is_classified_as_build_even_when_it_launches_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "build.bat"
            path.write_text("@echo off\ncl.exe source.cpp\nstart game.exe\n", encoding="utf-8")
            kind, _ = script_kind(path)
            self.assertEqual(kind, "build")

    def test_full_log_scan_preserves_errors_beyond_display_excerpt(self):
        hidden_error = "src/main.cpp:8:4: error: expected ';'"
        scan = _build_log_scan("ordinary build output\\n" * 2000 + hidden_error)
        self.assertIn(hidden_error, scan)
        self.assertIn("hata-işaretli=1", scan)

    def test_zero_exit_with_gcc_error_is_failure(self):
        result = "[çıkış kodu: 0 | süre: 1s]\nsrc/main.cpp:8:4: error: expected ';'\n"
        self.assertEqual(build_status(result), "failed")

    def test_zero_exit_with_msvc_linker_error_is_failure(self):
        result = "[çıkış kodu: 0 | süre: 1s]\nLINK : fatal error LNK1104: cannot open file\n"
        self.assertEqual(build_status(result), "failed")

    def test_nonzero_exit_is_failure(self):
        self.assertEqual(build_status("[çıkış kodu: 2 | süre: 1s]\n"), "failed")

    def test_timeout_is_failure(self):
        self.assertEqual(build_status("[çıkış kodu: TIMEOUT | süre: 120s]\n"), "failed")

    def test_zero_failure_count_is_not_misread_as_failure(self):
        self.assertEqual(build_status("[çıkış kodu: 0 | süre: 1s]\n0 tests failed\n"), "success")

    def test_zero_exit_clean_output_is_success(self):
        self.assertEqual(build_status("[çıkış kodu: 0 | süre: 1s]\nBuild succeeded\n"), "success")

    def test_missing_exit_code_is_unknown(self):
        self.assertEqual(build_status("build output only"), "unknown")


if __name__ == "__main__":
    unittest.main()
