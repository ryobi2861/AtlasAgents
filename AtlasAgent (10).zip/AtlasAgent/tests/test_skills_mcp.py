import asyncio
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from atlas.skills import discover_skills, read_resource
from atlas.mcp_client import MCPError, validate_server_config
from atlas.tools import Tools, tool_specs
from atlas.config import CFG


class SkillTests(unittest.TestCase):
    def test_discovers_valid_standard_skill_and_loads_reference(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            skill = root / ".agents" / "skills" / "hello-world"
            skill.mkdir(parents=True)
            (skill / "SKILL.md").write_text(
                '---\nname: hello-world\ndescription: "A useful skill"\n---\nDo the work carefully.\n', encoding="utf-8")
            (skill / "REFERENCE.md").write_text("reference data", encoding="utf-8")
            found = discover_skills(root)
            self.assertEqual([x["name"] for x in found], ["hello-world"])
            self.assertIn("Do the work carefully", found[0]["body"])
            self.assertEqual(read_resource(found[0], "REFERENCE.md"), "reference data")
            with self.assertRaises(ValueError):
                read_resource(found[0], "../../outside.txt")

    def test_skill_discovery_falls_back_when_pyyaml_is_not_installed(self):
        with tempfile.TemporaryDirectory() as td:
            skill = Path(td) / ".agents" / "skills" / "fallback-skill"
            skill.mkdir(parents=True)
            (skill / "SKILL.md").write_text(
                '---\nname: fallback-skill\ndescription: |\n  Multi-line skill description.\n  Still one metadata value.\n---\nInstructions.\n',
                encoding="utf-8")
            with patch("atlas.skills.yaml", None):
                found = discover_skills(td)
            self.assertEqual(len(found), 1)
            self.assertIn("Multi-line skill description", found[0]["description"])

    def test_rejects_invalid_skill_metadata_and_oversized_file(self):
        with tempfile.TemporaryDirectory() as td:
            skill = Path(td) / ".agents" / "skills" / "Bad_Name"
            skill.mkdir(parents=True)
            (skill / "SKILL.md").write_text('---\nname: Bad_Name\ndescription: bad\n---\nbody', encoding="utf-8")
            self.assertEqual(discover_skills(td), [])


class MCPTests(unittest.TestCase):
    def test_transport_and_safe_config_validation(self):
        configs = [
            {"id": "local", "name": "Local", "transport": "stdio", "command": "python", "args": ["server.py"]},
            {"id": "http", "name": "HTTP", "transport": "streamable_http", "url": "http://127.0.0.1:8000/mcp"},
            {"id": "old", "name": "Legacy", "transport": "sse", "url": "https://example.test/sse"},
        ]
        self.assertEqual([x["transport"] for x in validate_server_config(configs)], ["stdio", "streamable_http", "sse"])
        with self.assertRaises(ValueError):
            validate_server_config([{**configs[0], "id": "bad id"}])
        with self.assertRaises(ValueError):
            validate_server_config([{**configs[0], "id": "x"}, {**configs[0], "id": "x"}])
        with self.assertRaises(ValueError):
            validate_server_config([{**configs[0], "env": {"API_TOKEN": "plaintext-secret"}}])
        safe = validate_server_config([{"id": "remote", "name": "Remote", "transport": "streamable_http",
                                       "url": "https://example.test/mcp",
                                       "headers": {"Authorization": "Bearer ${MCP_TOKEN}"}}])
        self.assertEqual(safe[0]["headers"]["Authorization"], "Bearer ${MCP_TOKEN}")

    def test_mcp_calls_require_per_call_confirmation_unless_server_trusted(self):
        async def run(trusted):
            calls, approvals = [], []
            async def confirm(kind, detail):
                approvals.append((kind, detail))
                return True
            class Manager:
                async def call_tool(self, server, name, args):
                    calls.append((server["id"], name, args))
                    return "done"
            cfg = {**CFG, "mcp": {"enabled": True, "servers": [
                {"id": "srv", "name": "Server", "transport": "stdio", "command": "python", "args": [], "enabled": True, "trusted": trusted}
            ]}}
            tools = Tools(None, cfg, None, confirm, mcp_manager=Manager(), mcp_tools={
                "mcp__srv__write": {"server_id": "srv", "server_name": "Server", "tool_name": "write", "description": "write file", "trusted": trusted}
            })
            tools.allowed = {"mcp__srv__write"}
            result = await tools.execute("mcp__srv__write", {"path": "a.txt"})
            return result, calls, approvals
        result, calls, approvals = asyncio.run(run(False))
        self.assertEqual(result, "done")
        self.assertEqual(len(calls), 1)
        self.assertEqual(approvals[0][0], "mcp")
        result, calls, approvals = asyncio.run(run(True))
        self.assertEqual(result, "done")
        self.assertEqual(approvals, [])

    @unittest.skipUnless(importlib.util.find_spec("mcp"), "MCP SDK dependency not installed")
    def test_stdio_sdk_integration_list_and_call(self):
        async def run():
            from atlas.mcp_client import MCPManager
            with tempfile.TemporaryDirectory() as td:
                script = Path(td) / "mcp_server.py"
                script.write_text(
                    'from mcp.server import MCPServer\n'
                    'server = MCPServer("ATLAS test")\n'
                    '@server.tool()\n'
                    'def echo(text: str) -> str:\n'
                    '    """Return the supplied text."""\n'
                    '    return text\n'
                    'server.run()\n', encoding="utf-8")
                server = {"id": "stdio", "name": "Test", "transport": "stdio",
                          "command": sys.executable, "args": [str(script)], "env": {},
                          "enabled": True, "trusted": False}
                manager = MCPManager()
                try:
                    specs, mapping = await manager.list_tools([server])
                    self.assertEqual(specs[0]["function"]["name"], "mcp__stdio__echo")
                    self.assertIn("mcp__stdio__echo", mapping)
                    self.assertIn("hello", await manager.call_tool(server, "echo", {"text": "hello"}))
                finally:
                    await manager.close()
        asyncio.run(run())

    def test_skill_tools_are_exposed(self):
        names = {x["function"]["name"] for x in tool_specs()}
        self.assertIn("load_skill", names)
        self.assertIn("read_skill_resource", names)


if __name__ == "__main__":
    unittest.main()
