import tempfile
import unittest
from pathlib import Path

from atlas.autonomy import (
    AUTONOMOUS_MAX_SECONDS,
    classify_verification,
    requests_computer_use,
    requests_until_success,
    safe_autonomous_command,
)


class AutonomyTests(unittest.TestCase):
    def test_until_success_mode_requires_explicit_persistence_and_action(self):
        self.assertTrue(requests_until_success("Şu sorunu sürekli test ederek çöz, çözene kadar durma."))
        self.assertTrue(requests_until_success("Keep testing until the issue is fixed."))
        self.assertFalse(requests_until_success("Bu hatayı düzelt."))
        self.assertFalse(requests_until_success("Uygulamada test et."))

    def test_computer_use_is_explicitly_task_scoped(self):
        self.assertTrue(requests_computer_use("Pencere başlığı ATLAS Test olan uygulamada fareyle test et."))
        self.assertFalse(requests_computer_use("Testleri çalıştır ve hataları düzelt."))

    def test_only_local_project_tests_and_builds_can_be_auto_approved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            inside = root / "tests"
            outside = root.parent
            self.assertTrue(safe_autonomous_command("python -m unittest discover -s tests", inside, root))
            self.assertFalse(safe_autonomous_command("python -m unittest discover", outside, root))
            self.assertFalse(safe_autonomous_command("python -m pip install package", root, root))
            self.assertFalse(safe_autonomous_command("python -m unittest; del important.txt", root, root))
            self.assertFalse(safe_autonomous_command("pytest", root, None))
            build = root / "build.bat"
            build.write_text("@echo off\ncmake --build .\nstart game.exe\n", encoding="utf-8")
            self.assertFalse(safe_autonomous_command("build.bat", root, root))
            build.write_text("@echo off\ncmake --build .\n", encoding="utf-8")
            self.assertTrue(safe_autonomous_command("build.bat", root, root))

    def test_completion_verifier_fails_closed_and_session_has_four_hour_cap(self):
        self.assertEqual(classify_verification('{"decision":"PASS"}'), "PASS")
        self.assertEqual(classify_verification("unclear response"), "CONTINUE")
        self.assertEqual(classify_verification("This is not a PASS."), "CONTINUE")
        self.assertEqual(AUTONOMOUS_MAX_SECONDS, 4 * 60 * 60)


if __name__ == "__main__":
    unittest.main()
