import unittest

from atlas.agent import custom_model_from_mode


class CustomModelSelectionTests(unittest.TestCase):
    def test_custom_mode_preserves_full_ollama_model_name_and_tag(self):
        self.assertEqual(custom_model_from_mode("model:qwen3.5:14b-instruct-q4_K_M"),
                         "qwen3.5:14b-instruct-q4_K_M")
        self.assertEqual(custom_model_from_mode("model:org/model:latest"), "org/model:latest")

    def test_team_modes_are_not_misread_as_custom_models(self):
        for mode in ("auto", "main", "coder", "vision", None, "model:"):
            self.assertEqual(custom_model_from_mode(mode), "")


if __name__ == "__main__":
    unittest.main()
