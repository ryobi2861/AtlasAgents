import asyncio
import json
import unittest
from unittest.mock import AsyncMock

from atlas.agent import Agent
from atlas.brief import parse_brief


class FakePlanTools:
    def __init__(self):
        self.plan = [
            {"step": "Inspect the relevant files", "status": "done"},
            {"step": "Fix the parsing bug", "status": "in_progress"},
            {"step": "Run focused tests", "status": "pending"},
        ]
        self.saved = []
        self.events = []

    async def t_update_plan(self, items):
        self.plan = [{"step": item["step"], "status": item["status"]} for item in items]
        self.saved.append(json.loads(json.dumps(self.plan)))
        self.events.append({"type": "plan", "items": self.plan})


class PlanTrackingTests(unittest.TestCase):
    def test_brief_parser_keeps_ordered_actionable_steps(self):
        brief = parse_brief({"amac": "Fix and verify the parser", "adimlar": ["Inspect source", "Fix parser", "Run tests"]})
        self.assertEqual(brief["adimlar"], ["Inspect source", "Fix parser", "Run tests"])

    def test_successful_tool_action_updates_and_persists_todo_statuses(self):
        agent = Agent.__new__(Agent)
        agent._quick = AsyncMock(return_value=json.dumps({"statuses": ["done", "done", "in_progress"]}))
        tools = FakePlanTools()
        asyncio.run(agent._track_plan_progress(
            "main", tools, "Fix parser", "edit_file", {"path": "src/parser.py"}, "Updated src/parser.py successfully."
        ))
        self.assertEqual([p["status"] for p in tools.plan], ["done", "done", "in_progress"])
        self.assertEqual(len(tools.saved), 1)
        self.assertEqual(tools.events[-1]["type"], "plan")

    def test_failed_action_does_not_mark_plan_steps_done(self):
        agent = Agent.__new__(Agent)
        agent._quick = AsyncMock()
        tools = FakePlanTools()
        before = json.dumps(tools.plan)
        asyncio.run(agent._track_plan_progress("main", tools, "Fix parser", "compile_cpp", {}, "HATA: compile failed"))
        self.assertEqual(json.dumps(tools.plan), before)
        agent._quick.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
