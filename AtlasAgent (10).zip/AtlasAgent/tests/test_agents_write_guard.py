import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from atlas.tools import ToolError, Tools


class AgentsWriteGuardTests(unittest.TestCase):
    def test_generic_write_and_edit_tools_cannot_bypass_success_confirmation_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "AGENTS.md").write_text("Existing rule.\n", encoding="utf-8")
            tools = Tools(None, {"agent": {"tool_result_chars": 9000}}, {"id": 1, "path": str(root)},
                          confirm=lambda *_args: True)
            with self.assertRaises(ToolError):
                asyncio.run(tools.t_write_file("AGENTS.md", "overwrite"))
            with self.assertRaises(ToolError):
                asyncio.run(tools.t_edit_file("AGENTS.md", "Existing rule.", "Changed rule."))
            self.assertEqual((root / "AGENTS.md").read_text(encoding="utf-8"), "Existing rule.\n")

    def test_command_and_python_routes_cannot_bypass_agents_or_commit_gates(self):
        cfg = {"agent": {"tool_result_chars": 9000, "command_guard": False, "auto_approve_commands": True}}
        tools = Tools(None, cfg, None, confirm=lambda *_args: True, success_confirmed=False)
        with self.assertRaisesRegex(ToolError, "başarılı diye onaylamadı"):
            asyncio.run(tools.t_run_command("git commit -m 'unverified'"))
        with self.assertRaisesRegex(ToolError, "AGENTS.md"):
            asyncio.run(tools.t_run_command("echo unsafe > AGENTS.md"))
        with self.assertRaisesRegex(ToolError, "commit"):
            asyncio.run(tools.t_run_python("import subprocess; subprocess.run(['git', 'commit'])"))
        with self.assertRaisesRegex(ToolError, "AGENTS.md"):
            asyncio.run(tools.t_run_python("open('AGENTS.md', 'w').write('unsafe')"))

    def test_mcp_cannot_bypass_agents_or_commit_gates_even_when_server_is_trusted(self):
        cfg = {"agent": {"tool_result_chars": 9000}, "mcp": {"enabled": True, "servers": [
            {"id": "srv", "name": "Trusted", "transport": "stdio", "command": "server",
             "enabled": True, "trusted": True}
        ]}}
        class Manager:
            def __init__(self):
                self.calls = []
            async def call_tool(self, server, tool_name, args):
                self.calls.append((tool_name, args))
                return "called"
        manager = Manager()
        tools = Tools(None, cfg, None, confirm=lambda *_args: True, mcp_manager=manager, mcp_tools={
            "mcp__srv__write_file": {"server_id": "srv", "server_name": "Trusted", "tool_name": "write_file",
                                      "description": "Write a file", "trusted": True},
            "mcp__srv__run_command": {"server_id": "srv", "server_name": "Trusted", "tool_name": "run_command",
                                       "description": "Run a command", "trusted": True},
        })
        agents = asyncio.run(tools.execute("mcp__srv__write_file", {"path": "AGENTS.md", "content": "rule"}))
        commit = asyncio.run(tools.execute("mcp__srv__run_command", {"command": "git commit -am done"}))
        self.assertIn("engellendi", agents)
        self.assertIn("engellendi", commit)
        self.assertEqual(manager.calls, [])

    def test_commit_is_permitted_only_with_explicit_success_confirmation(self):
        cfg = {"agent": {"tool_result_chars": 9000, "command_guard": False, "auto_approve_commands": True}}
        tools = Tools(None, cfg, None, confirm=lambda *_args: True, success_confirmed=True)
        with patch("atlas.tools.run_process", return_value=(1, "not a repository", 0.01)) as process:
            result = asyncio.run(tools.t_run_command("git commit -m 'confirmed'"))
        process.assert_called_once()
        self.assertIn("çıkış kodu: 1", result)


if __name__ == "__main__":
    unittest.main()
