import tempfile
import unittest
from pathlib import Path

from atlas.agent import change_signature, is_build_tool_call, prebuild_gate, prebuild_review_passed


class PrebuildReviewTests(unittest.TestCase):
    def test_all_compile_commands_are_gated_but_start_script_is_not_a_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "build.bat").write_text("@echo off\ncl.exe main.cpp\n", encoding="utf-8")
            (root / "start.bat").write_text("@echo off\nstart game.exe\n", encoding="utf-8")
            self.assertTrue(is_build_tool_call("compile_cpp", {"sources": ["main.cpp"]}, root))
            self.assertTrue(is_build_tool_call("run_command", {"command": "build.bat"}, root))
            self.assertFalse(is_build_tool_call("run_command", {"command": "start.bat"}, root))
            self.assertFalse(is_build_tool_call("read_file", {"path": "build.bat"}, root))

    def test_review_signature_changes_when_diff_changes_and_ignores_reverted_rows(self):
        first = [{"path": "src/a.cpp", "diff": "+return 1", "reverted": False}]
        revised = [{"path": "src/a.cpp", "diff": "+return 2", "reverted": False}]
        self.assertTrue(change_signature(first))
        self.assertNotEqual(change_signature(first), change_signature(revised))
        self.assertEqual(change_signature(first + [{"path": "old.cpp", "diff": "+bad", "reverted": True}]),
                         change_signature(first))

    def test_only_explicit_reviewer_pass_allows_build(self):
        self.assertTrue(prebuild_review_passed({"result": "PASS", "issues": []}))
        self.assertFalse(prebuild_review_passed({"result": "ISSUES", "issues": [{"severity": "major"}]}))
        self.assertFalse(prebuild_review_passed({"result": "UNAVAILABLE", "issues": []}))
        self.assertFalse(prebuild_review_passed(None))

    def test_new_diff_requires_review_and_cached_pass_allows_same_diff(self):
        rows = [{"path": "main.cpp", "diff": "+return 42", "reverted": False}]
        pending = prebuild_gate("compile_cpp", {}, Path.cwd(), rows)
        self.assertTrue(pending["review_required"])
        self.assertFalse(pending["allow"])
        passed = {"result": "PASS", "issues": []}
        cached = prebuild_gate("compile_cpp", {}, Path.cwd(), rows, pending["signature"], passed)
        self.assertFalse(cached["review_required"])
        self.assertTrue(cached["allow"])

    def test_changed_diff_invalidates_cached_pass_and_review_failures_block(self):
        first = [{"path": "main.cpp", "diff": "+return 1", "reverted": False}]
        changed = [{"path": "main.cpp", "diff": "+return 2", "reverted": False}]
        sig = change_signature(first)
        stale_pass = prebuild_gate("compile_cpp", {}, Path.cwd(), changed, sig, {"result": "PASS"})
        self.assertTrue(stale_pass["review_required"])
        blocked = prebuild_gate("compile_cpp", {}, Path.cwd(), first, sig,
                                {"result": "ISSUES", "issues": [{"severity": "major"}]})
        self.assertFalse(blocked["allow"])

    def test_non_build_never_needs_a_reviewer_gate(self):
        rows = [{"path": "main.cpp", "diff": "+return 1", "reverted": False}]
        gate = prebuild_gate("read_file", {"path": "main.cpp"}, Path.cwd(), rows)
        self.assertFalse(gate["is_build"])
        self.assertFalse(gate["review_required"])
        self.assertTrue(gate["allow"])


if __name__ == "__main__":
    unittest.main()
