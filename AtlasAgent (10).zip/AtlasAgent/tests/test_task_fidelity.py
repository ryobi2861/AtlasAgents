import unittest

from atlas import brief
from atlas.agent import SYSTEM_PROMPT


class TaskFidelityPromptTests(unittest.TestCase):
    def test_brief_preserves_named_targets_and_does_not_invent_failure_cause(self):
        prompt = brief.BRIEF_PROMPT.casefold()
        self.assertIn("hedef nesne/sembol ve semptomu aynen koru", prompt)
        self.assertIn("input/klavye/fare sorunu", prompt)
        self.assertIn("kanıtlanmamış neden", prompt)
        self.assertIn("kritik=true yap ve sor", prompt)

    def test_core_prompt_requires_evidence_first_and_scope_lock(self):
        prompt = SYSTEM_PROMPT.casefold()
        self.assertIn("kullanıcının açık hedefini", prompt)
        self.assertIn("kanıt görmeden tahmine dayalı düzeltme yapma", prompt)
        self.assertIn("bu eylem kullanıcının açık hedefiyle doğrudan ilgili mi", prompt)

    def test_correction_discards_previous_wrong_assumption(self):
        note = brief.CORRECTION_NOTE.casefold()
        self.assertIn("yanlış varsayımı açıkça terk et", note)
        self.assertIn("ilgili kaynak/log/araç kanıtını yeniden incele", note)
        self.assertIn("hiçbir dosyayı değiştirme", note)

    def test_original_request_is_carried_verbatim_as_primary_source(self):
        request = "LoginDlg bulunamıyor.\nOffset ve pointer zincirini bul; dosyayı henüz değiştirme."
        message = brief.original_request_message(request)
        self.assertIn(request, message)
        self.assertIn("AYNEN, EKSİKSİZ VE TEK YETKİLİ KAYNAK", message)
        self.assertIn("görev özeti, planı, hafızası veya varsayımı bu isteği değiştiremez", message)

    def test_brief_is_labeled_secondary_not_authoritative(self):
        rendered = brief.render({"amac": "Yardımcı özet"}).casefold()
        self.assertIn("ikincil_atlas_gorev_ozeti", rendered)
        self.assertIn("orijinal kullanıcı mesajı tek yetkili kaynaktır", rendered)
        self.assertIn("özet orijinal mesajla çelişirse özeti yok say", rendered)

    def test_anchor_repeats_original_request_and_limits_scope(self):
        anchor = brief.anchor(
            "LoginDlg bulunamıyor; offset ve pointer'ları incele",
            {"amac": "LoginDlg tespitini teşhis et", "kisitlar": ["önce kanıt topla"],
             "bitti_kriteri": ["ilgili arama ve pointer zinciri kanıtla"]},
            [],
        ).casefold()
        self.assertIn("logindlg bulunamıyor", anchor)
        self.assertIn("hedeften sapma", anchor)
        self.assertIn("offset ve pointer", anchor)


if __name__ == "__main__":
    unittest.main()
